import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const root = path.resolve(new URL('../..', import.meta.url).pathname);
const packageJson = JSON.parse(fs.readFileSync(path.join(root, 'backend', 'package.json'), 'utf8'));
const flutterPubspec = fs.readFileSync(path.join(root, 'pubspec.yaml'), 'utf8');
const versionMatch = flutterPubspec.match(/^version:\s*([^\r\n]+)/m);
const gitSha = process.env.GITHUB_SHA || process.env.GIT_COMMIT || 'unknown';
const apk = process.env.APK_PATH || '';
const isProduction = process.env.BUILD_PROFILE === 'production';
const certificationStatus = process.env.STAGING_CERTIFICATION_STATUS || '';
const certificationRunId = process.env.STAGING_CERTIFICATION_RUN_ID || '';
const certificationSha = process.env.STAGING_CERTIFICATION_SHA || '';
const certificationAttempt = process.env.STAGING_CERTIFICATION_ATTEMPT || '';

if (isProduction) {
  if (certificationStatus !== 'PASS') throw new Error('Production release manifest requires PASS staging certification.');
  if (!certificationRunId) throw new Error('Production release manifest requires staging certification run id.');
  if (!certificationSha) throw new Error('Production release manifest requires staging certification SHA.');
  if (certificationSha !== gitSha) throw new Error('Production release manifest certification SHA must match the release SHA.');
  if (!/^\d+$/.test(certificationAttempt)) throw new Error('Production release manifest requires a numeric staging certification attempt.');
}

const manifest = {
  generatedAt: new Date().toISOString(),
  gitSha,
  backendVersion: packageJson.version || null,
  flutterVersion: versionMatch?.[1]?.trim() || null,
  nodeVersion: process.version,
  apk: null,
  certification: {
    externalChecksRequired: true,
    source: 'production-release workflow',
    stagingCertificationStatus: certificationStatus || null,
    stagingCertificationRunId: certificationRunId || null,
    stagingCertificationSha: certificationSha || null,
    stagingCertificationAttempt: certificationAttempt ? Number(certificationAttempt) : null,
  },
};

if (apk) {
  const apkPath = path.isAbsolute(apk) ? apk : path.resolve(root, apk);
  const buf = fs.readFileSync(apkPath);
  manifest.apk = {
    path: path.relative(root, apkPath),
    sha256: crypto.createHash('sha256').update(buf).digest('hex'),
    bytes: buf.length,
  };
}

const out = process.env.RELEASE_MANIFEST_PATH || path.join(root, 'release-manifest.json');
fs.writeFileSync(out, JSON.stringify(manifest, null, 2) + '\n', { mode: 0o644 });
console.log(`Release manifest written: ${out}`);
