import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(new URL('..', import.meta.url).pathname, '..');

test('CI never contains the placeholder API host and requires a real secret', () => {
  const workflow = fs.readFileSync(path.join(root, '.github/workflows/main.yml'), 'utf8');
  assert.doesNotMatch(workflow, /api\.hope\.example\.invalid/);
  assert.match(workflow, /secrets\.API_BASE_URL/);
  assert.match(workflow, /API_BASE_URL secret is required/);
});

test('SBOM reports the current application version', () => {
  const sbom = JSON.parse(fs.readFileSync(path.join(root, 'backend/sbom.json'), 'utf8'));
  assert.equal(sbom.metadata.component.version, '3.8.0');
});


test('production payment adapter is real-provider-capable and compose injects its contract', () => {
  const provider = fs.readFileSync(path.join(root, 'backend/src/payment_provider.js'), 'utf8');
  const config = fs.readFileSync(path.join(root, 'backend/src/config.js'), 'utf8');
  const compose = fs.readFileSync(path.join(root, 'backend/docker-compose.yml'), 'utf8');
  assert.match(provider, /name === 'webhook'/);
  assert.match(provider, /PAYMENT_PROVIDER_CREATE_URL/);
  assert.match(provider, /PAYMENT_PROVIDER_RELEASE_URL/);
  assert.match(provider, /PAYMENT_PROVIDER_REFUND_URL/);
  assert.match(config, /PAYMENT_PROVIDER=webhook is required in production/);
  for (const name of ['PAYMENT_PROVIDER_TOKEN','PAYMENT_PROVIDER_CREATE_URL','PAYMENT_PROVIDER_RELEASE_URL','PAYMENT_PROVIDER_REFUND_URL','NOTIFICATION_PUSH_URL','NOTIFICATION_EMAIL_URL','NOTIFICATION_PROVIDER_TOKEN']) {
    assert.match(compose, new RegExp(name));
  }
});

test('production compose uses loopback binding and non-privileged readonly container', () => {
  const compose = fs.readFileSync(path.join(root, 'backend/docker-compose.yml'), 'utf8');
  assert.match(compose, /127\.0\.0\.1:3000:3000/);
  assert.match(compose, /no-new-privileges:true/);
  assert.match(compose, /read_only: true/);
});


test('production env validator exists and Docker image carries it', () => {
  const validator = fs.readFileSync(path.join(root, 'backend/scripts/validate-production-env.sh'), 'utf8');
  const dockerfile = fs.readFileSync(path.join(root, 'backend/Dockerfile'), 'utf8');
  assert.match(validator, /Production environment contract PASS/);
  assert.match(validator, /PAYMENT_PROVIDER_CREATE_URL/);
  assert.match(dockerfile, /validate-production-env\.sh/);
  assert.match(dockerfile, /ENTRYPOINT \["\/app\/entrypoint\.sh"\]/);
  assert.match(dockerfile, /HEALTHCHECK/);
});

test('production CI blocks on high-severity npm audit findings', () => {
  const workflow = fs.readFileSync(path.join(root, '.github/workflows/production-release.yml'), 'utf8');
  assert.match(workflow, /npm audit --audit-level=high/);
});

test('main CI blocks on high-severity npm audit findings', () => {
  const workflow = fs.readFileSync(path.join(root, '.github/workflows/main.yml'), 'utf8');
  assert.match(workflow, /npm audit --audit-level=high/);
});

test('SBOM covers the locked dependency tree, not only direct dependencies', () => {
  const sbom = JSON.parse(fs.readFileSync(path.join(root, 'backend/sbom.json'), 'utf8'));
  const lock = JSON.parse(fs.readFileSync(path.join(root, 'backend/package-lock.json'), 'utf8'));
  const lockedCount = Object.keys(lock.packages || {}).filter((k) => k).length;
  assert.ok(sbom.components.length >= lockedCount);
});


test('production release builds the backend Docker image as a production-only concern after staging certification', () => {
  const workflow = fs.readFileSync(path.join(root, '.github/workflows/production-release.yml'), 'utf8');
  assert.match(workflow, /needs: staging-certification/);
  assert.match(workflow, /name: Build production backend image/);
  assert.match(workflow, /docker build --pull --file Dockerfile --tag hope-api:\$\{GITHUB_SHA\} \./);
  assert.doesNotMatch(workflow, /name: External integration gate/);
});

test('production release is protected and must originate from an immutable version tag', () => {
  const workflow = fs.readFileSync(path.join(root, '.github/workflows/production-release.yml'), 'utf8');
  assert.match(workflow, /environment:\s+production/);
  assert.match(workflow, /Enforce immutable release tag/);
  assert.match(workflow, /refs\/tags\/v/);
  assert.match(workflow, /Release tag \$TAG does not match application version v\$VERSION/);
});


test('production release delegates staging certification and does not consume staging secrets in the production job', () => {
  const workflow = fs.readFileSync(path.join(root, '.github/workflows/production-release.yml'), 'utf8');
  assert.match(workflow, /staging-certification:/);
  assert.match(workflow, /uses: \.\/\.github\/workflows\/staging-certification\.yml/);
  assert.match(workflow, /needs: staging-certification/);
  assert.doesNotMatch(workflow, /API_BASE_URL_STAGING/);
  assert.doesNotMatch(workflow, /STAGING_DATABASE_URL/);
  assert.doesNotMatch(workflow, /STAGING_S3_ENDPOINT/);
});

test('staging certification is reusable and contains the external, DR, and device gates', () => {
  const workflow = fs.readFileSync(path.join(root, '.github/workflows/staging-certification.yml'), 'utf8');
  assert.match(workflow, /workflow_call:/);
  for (const marker of ['Staging external integration gate','Staging product workflow','Staging operational gate','DR restore drill','Android emulator certification']) {
    assert.match(workflow, new RegExp(marker));
  }
  assert.match(workflow, /S3_REQUIRE_HTTPS: '1'/);
  assert.match(workflow, /STAGING_S3_ENDPOINT/);
  assert.match(workflow, /DRILL_DATABASE_URL/);
});
