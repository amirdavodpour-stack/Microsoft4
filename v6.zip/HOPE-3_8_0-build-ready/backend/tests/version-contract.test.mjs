import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(new URL('..', import.meta.url).pathname);

test('all release/version surfaces are aligned to 3.8.0', () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
  const lock = JSON.parse(fs.readFileSync(path.join(root, 'package-lock.json'), 'utf8'));
  const gradle = fs.readFileSync(path.join(root, '..', 'android/app/build.gradle.kts'), 'utf8');
  const build = fs.readFileSync(path.join(root, '..', 'tools/build_apk_release.sh'), 'utf8');
  const config = fs.readFileSync(path.join(root, 'src/config.js'), 'utf8');
  assert.equal(pkg.version, '3.8.0');
  assert.equal(lock.packages[''].version, '3.8.0');
  assert.match(gradle, /versionName = "3\.8\.0"/);
  assert.match(build, /versionName='3\.8\.0'/);
  assert.match(config, /HOPE_VERSION = '3\.8\.0'/);
});
