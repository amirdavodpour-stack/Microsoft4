import crypto from 'node:crypto';
import { withSqlTransaction } from '../db.js';
import { requirePool } from './context.js';
import { config } from '../config.js';
import { fundingJournal, releaseJournal, payoutJournal, refundJournal, calculatePaymentBreakdown } from '../financial.js';
import { jobFromRow, offerFromRow, paymentFromRow } from './mappers.js';
export async function findPaymentById(paymentId, client=requirePool()) {
  const {rows}=await client.query(`SELECT * FROM payments WHERE id=$1`,[paymentId]); return rows[0]?paymentFromRow(rows[0]):null;
}
export async function updateJobSimple(id,expectedStatuses,patch) {
  return withSqlTransaction(async(client)=>{
    const {rows}=await client.query(`SELECT * FROM jobs WHERE id=$1 FOR UPDATE`,[id]); if(!rows[0]) return null; const job=jobFromRow(rows[0]);
    if(!expectedStatuses.includes(job.status)){const e=new Error('INVALID_STATE');e.code='INVALID_STATE';throw e;}
    const allowed={providerId:'provider_id',status:'status',updatedAt:'updated_at',publishedAt:'published_at'}; const fields=Object.keys(patch).filter(k=>allowed[k]);
    if(!fields.length) return job;
    const values=[id,...fields.map(k=>patch[k])]; const sets=fields.map((k,i)=>`${allowed[k]}=$${i+2}`);
    const {rows:updated}=await client.query(`UPDATE jobs SET ${sets.join(',')} WHERE id=$1 RETURNING *`,values); return jobFromRow(updated[0]);
  });
}
export async function transitionJobWithPayment(id,expectedStatuses,jobPatch,paymentStatus) {
  return withSqlTransaction(async(client)=>{
    const {rows}=await client.query(`SELECT * FROM jobs WHERE id=$1 FOR UPDATE`,[id]); if(!rows[0]) return null; const job=jobFromRow(rows[0]);
    if(!expectedStatuses.includes(job.status)){const e=new Error('INVALID_STATE');e.code='INVALID_STATE';throw e;}
    const {rows:p}=await client.query(`SELECT * FROM payments WHERE job_id=$1 FOR UPDATE`,[id]); const payment=p[0]?paymentFromRow(p[0]):null;
    if(!payment || (paymentStatus && payment.status!==paymentStatus)){const e=new Error('INVALID_PAYMENT_STATE');e.code='INVALID_PAYMENT_STATE';throw e;}
    const allowed={status:'status',updatedAt:'updated_at'}; const fields=Object.keys(jobPatch).filter(k=>allowed[k]); const vals=[id,...fields.map(k=>jobPatch[k])]; const sets=fields.map((k,i)=>`${allowed[k]}=$${i+2}`);
    const {rows:uj}=await client.query(`UPDATE jobs SET ${sets.join(',')} WHERE id=$1 RETURNING *`,vals);
    const {rows:up}=await client.query(`UPDATE payments SET status=$2,updated_at=NOW() WHERE id=$1 RETURNING *`,[payment.id,paymentStatus==='HELD'?'RELEASE_PENDING':paymentStatus]);
    return {job:jobFromRow(uj[0]),payment:paymentFromRow(up[0])};
  });
}

export async function acceptOffer(offerId, ownerId) {
  return withSqlTransaction(async (client) => {
    const offer = await findOfferById(offerId, client);
    if (!offer) return null;
    // BUG FIX: the job row must be locked (SELECT ... FOR UPDATE) BEFORE
    // its status is checked, not after. The previous version read job.status
    // via a plain, non-locking findJobById(), decided PUBLISHED was fine,
    // and only then acquired the lock -- so two concurrent "accept a
    // different offer on the same job" transactions could both pass the
    // PUBLISHED check before either committed, then both proceed to assign
    // the job (to two different offers/providers) once the lock freed up
    // in turn. This mirrors the correct lock-then-check order already used
    // by fundJobAtomic()/enqueuePaymentRelease() below.
    const { rows: jobRows } = await client.query(`SELECT * FROM jobs WHERE id=$1 FOR UPDATE`, [offer.jobId]);
    if (!jobRows[0]) return null;
    const job = jobFromRow(jobRows[0]);
    if (job.ownerId !== ownerId) { const e = new Error('FORBIDDEN'); e.code='FORBIDDEN'; throw e; }
    if (job.status !== 'PUBLISHED') { const e = new Error('INVALID_STATE'); e.code='INVALID_STATE'; throw e; }
    // Re-check the offer itself under the same lock: another request could
    // have accepted/withdrawn it while this one waited for the job lock.
    const { rows: offerRows } = await client.query(`SELECT * FROM offers WHERE id=$1 FOR UPDATE`, [offer.id]);
    const current = offerRows[0] ? offerFromRow(offerRows[0]) : null;
    if (!current || current.status !== 'PENDING') { const e = new Error('INVALID_STATE'); e.code='INVALID_STATE'; throw e; }
    // PERF: the offer's post-update row used to come from a third SELECT
    // (findOfferById) after the UPDATE below discarded its own result.
    // RETURNING * on the UPDATE gives the identical row for free, in the
    // same round trip, and is strictly more correct: it's guaranteed
    // atomic with the write instead of a separate read issued after it.
    const { rows: acceptedRows } = await client.query(`UPDATE offers SET status='ACCEPTED',updated_at=NOW() WHERE id=$1 RETURNING *`, [offer.id]);
    await client.query(`UPDATE offers SET status='REJECTED',updated_at=NOW() WHERE job_id=$1 AND id<>$2 AND status='PENDING'`, [job.id,offer.id]);
    const {rows}=await client.query(`UPDATE jobs SET provider_id=$2,status='ASSIGNED',updated_at=NOW() WHERE id=$1 RETURNING *`, [job.id,offer.providerId]);
    return { offer: offerFromRow(acceptedRows[0]), job: jobFromRow(rows[0]) };
  });
}
export async function findPaymentByJob(jobId, client = requirePool()) {
  const { rows } = await client.query(`SELECT * FROM payments WHERE job_id=$1`, [jobId]);
  return rows[0] ? paymentFromRow(rows[0]) : null;
}
export async function findPaymentByIdempotency(payerId, key, client = requirePool()) {
  const { rows } = await client.query(`SELECT * FROM payments WHERE payer_id=$1 AND idempotency_key=$2`, [payerId,key]);
  return rows[0] ? paymentFromRow(rows[0]) : null;
}
export async function fundJobAtomic({jobId,payerId,payeeId,offerId=null,amount,id,idempotencyKey,createdAt,breakdown}) {
  return withSqlTransaction(async (client) => {
    if (idempotencyKey) {
      await client.query(`SELECT pg_advisory_xact_lock(hashtextextended($1, 918273645))`, [`payment:${payerId}:${idempotencyKey}`]);
    }
    const {rows:jobRows}=await client.query(`SELECT * FROM jobs WHERE id=$1 FOR UPDATE`, [jobId]);
    const job=jobRows[0] ? jobFromRow(jobRows[0]) : null;
    if (!job) return null;
    if (job.ownerId !== payerId) { const e=new Error('FORBIDDEN');e.code='FORBIDDEN';throw e; }
    if (!['PUBLISHED','ASSIGNED','FUNDED'].includes(job.status)) { const e=new Error('INVALID_STATE');e.code='INVALID_STATE';throw e; }
    const existingRow = await client.query(`SELECT * FROM payments WHERE job_id=$1 FOR UPDATE`, [jobId]);
    if (existingRow.rows[0]) {
      const existing=paymentFromRow(existingRow.rows[0]);
      if (existing.idempotencyKey && idempotencyKey && existing.idempotencyKey !== idempotencyKey) { const e=new Error('PAYMENT_ALREADY_EXISTS');e.code='PAYMENT_ALREADY_EXISTS';throw e; }
      if (existing.status === 'HOLD_FAILED') {
        await client.query(`UPDATE payments SET status='HOLD_PENDING',idempotency_key=COALESCE(NULLIF(idempotency_key,''),NULLIF($3,'')),updated_at=$2 WHERE id=$1`, [existing.id,createdAt,idempotencyKey || null]);
        const {rows:ev}=await client.query(`
          INSERT INTO outbox_events(id,event_type,aggregate_type,aggregate_id,dedupe_key,payload,status,attempts,available_at,created_at)
          VALUES(gen_random_uuid(),'PAYMENT_CREATE_HOLD','payment',$1,$2,$3::jsonb,'PENDING',0,NOW(),NOW())
          ON CONFLICT(dedupe_key) DO UPDATE SET status='PENDING',available_at=NOW(),locked_at=NULL,last_error=NULL,processed_at=NULL
          RETURNING *`,
          [existing.id, `PAYMENT_CREATE_HOLD:${existing.id}`, JSON.stringify({ jobId, ownerId:payerId, paymentId:existing.id, amount:Number(existing.employer_charge || existing.amount), baseAmount:Number(existing.base_amount || existing.amount), currency:config.paymentCurrency, idempotencyKey:existing.idempotencyKey || idempotencyKey || `payment:${existing.id}` })]);
        return { payment:{...existing,status:'HOLD_PENDING',updatedAt:createdAt.toISOString?.() ?? createdAt}, job, outboxEvent:{id:ev[0].id,status:ev[0].status}, retry:true };
      }
      return {payment:existing,job,outboxEvent:null,created:false};
    }
    if (idempotencyKey) {
      const prior=await findPaymentByIdempotency(payerId,idempotencyKey,client);
      if (prior) {
        if (prior.jobId !== jobId || Number(prior.amount) !== Number(amount)) { const e=new Error('IDEMPOTENCY_CONFLICT'); e.code='IDEMPOTENCY_CONFLICT'; throw e; }
        return {payment:prior,job,outboxEvent:null,created:false};
      }
    }
    if (offerId) {
      const {rows:offerRows}=await client.query(`SELECT * FROM offers WHERE id=$1 AND job_id=$2 FOR UPDATE`, [offerId,jobId]);
      const selected=offerRows[0];
      if (!selected || selected.status !== 'PENDING' || selected.provider_id !== payeeId) { const e=new Error('INVALID_OFFER_STATE');e.code='INVALID_OFFER_STATE';throw e; }
      await client.query(`UPDATE offers SET status='ACCEPTED',updated_at=NOW() WHERE id=$1`, [offerId]);
      await client.query(`UPDATE offers SET status='REJECTED',updated_at=NOW() WHERE job_id=$1 AND id<>$2 AND status='PENDING'`, [jobId,offerId]);
    }
    const fees = breakdown || calculatePaymentBreakdown(job.kind || (job.jobType === 'FIXED' ? 'MISSION' : 'JOB'), amount);
    const placeholderRef = `PENDING:${id}`;
    const {rows}=await client.query(`INSERT INTO payments(id,job_id,payer_id,payee_id,amount,status,provider_ref,idempotency_key,base_amount,employer_fee,worker_fee,platform_fee,employer_charge,provider_payout,fee_policy_version,currency,created_at,updated_at) VALUES($1,$2,$3,$4,$5,'HOLD_PENDING',$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$16) RETURNING *`, [id,jobId,payerId,payeeId,amount,placeholderRef,idempotencyKey || null,fees.baseAmount,fees.employerFee,fees.workerFee,fees.platformFee,fees.employerCharge,fees.providerPayout,fees.policyVersion,fees.currency,createdAt]);
    const {rows:job2}=await client.query(`UPDATE jobs SET status='FUNDED',updated_at=$2,provider_id=COALESCE(provider_id,$3) WHERE id=$1 RETURNING *`, [jobId,createdAt,payeeId]);
    const journalId = crypto.randomUUID();
    for (const entry of fundingJournal(fees)) await client.query(`INSERT INTO ledger_entries(id,journal_id,reference_type,reference_id,account,debit,credit,currency,created_at) VALUES($1,$2,'PAYMENT_FUND',$3,$4,$5,$6,$7,$8)`, [crypto.randomUUID(),journalId,id,entry.account,entry.debit,entry.credit,fees.currency,createdAt]);
    const {rows:ev}=await client.query(`
      INSERT INTO outbox_events(id,event_type,aggregate_type,aggregate_id,dedupe_key,payload,status,attempts,available_at,created_at)
      VALUES(gen_random_uuid(),'PAYMENT_CREATE_HOLD','payment',$1,$2,$3::jsonb,'PENDING',0,NOW(),NOW())
      RETURNING *`,
      [id, `PAYMENT_CREATE_HOLD:${id}`, JSON.stringify({ jobId, ownerId:payerId, paymentId:id, amount:Number(fees.employerCharge), baseAmount:Number(fees.baseAmount), currency:fees.currency, idempotencyKey:idempotencyKey || `payment:${id}` })]);
    await client.query(`INSERT INTO audit_logs(id,action,actor_id,entity_type,entity_id,meta,created_at) VALUES($1,'PAYMENT_FUND',$2,'payment',$3,$4::jsonb,$5)`, [crypto.randomUUID(), payerId, id, JSON.stringify({jobId,outboxEventId:ev[0].id}), createdAt]);
    return {payment:paymentFromRow(rows[0]),job:jobFromRow(job2[0]),outboxEvent:{id:ev[0].id,status:ev[0].status},created:true};
  });
}

export async function createRefundAtomic({jobId,paymentId,ownerId,amount,id,idempotencyKey,createdAt}) {
  return withSqlTransaction(async(client)=>{
    if (idempotencyKey) {
      await client.query(`SELECT pg_advisory_xact_lock(hashtextextended($1, 918273645))`, [`refund:${paymentId}:${idempotencyKey}`]);
    }
    const {rows:jr}=await client.query(`SELECT * FROM jobs WHERE id=$1 FOR UPDATE`,[jobId]);
    if(!jr[0]) return null;
    if(jr[0].owner_id!==ownerId){const e=new Error('FORBIDDEN');e.code='FORBIDDEN';throw e;}
    const {rows:pr}=await client.query(`SELECT * FROM payments WHERE id=$1 AND job_id=$2 FOR UPDATE`,[paymentId,jobId]);
    const payment=pr[0]; if(!payment){const e=new Error('PAYMENT_NOT_FOUND');e.code='PAYMENT_NOT_FOUND';throw e;}
    if(payment.status!=='HELD'){const e=new Error('INVALID_PAYMENT_STATE');e.code='INVALID_PAYMENT_STATE';throw e;}
    const refundAmount=Number(amount || payment.amount); if(refundAmount!==Number(payment.amount)){const e=new Error('PARTIAL_REFUND_UNSUPPORTED');e.code='PARTIAL_REFUND_UNSUPPORTED';throw e;}
    if(idempotencyKey){const prior=await client.query(`SELECT * FROM refunds WHERE payment_id=$1 AND idempotency_key=$2`,[paymentId,idempotencyKey]); if(prior.rows[0]) return {refund:prior.rows[0],payment:payment};}
    const {rows:rr}=await client.query(`INSERT INTO refunds(id,payment_id,amount,status,provider_ref,idempotency_key,created_at,updated_at) VALUES($1,$2,$3,'PENDING',NULL,$4,$5,$5) RETURNING *`,[id,paymentId,refundAmount,idempotencyKey||null,createdAt]);
    await client.query(`UPDATE payments SET status='REFUND_PENDING',updated_at=$2 WHERE id=$1`,[paymentId,createdAt]);
    const dedupe=`PAYMENT_REFUND:${paymentId}`;
    const {rows:ev}=await client.query(`INSERT INTO outbox_events(id,event_type,aggregate_type,aggregate_id,dedupe_key,payload,status,attempts,available_at,created_at) VALUES(gen_random_uuid(),'PAYMENT_REFUND','payment',$1,$2,$3::jsonb,'PENDING',0,NOW(),NOW()) ON CONFLICT(dedupe_key) DO UPDATE SET status=CASE WHEN outbox_events.status='DONE' THEN outbox_events.status ELSE 'PENDING' END,available_at=CASE WHEN outbox_events.status='DONE' THEN outbox_events.available_at ELSE NOW() END RETURNING *`,[paymentId,dedupe,JSON.stringify({jobId,ownerId,paymentId,refundId:id,providerRef:payment.provider_ref,idempotencyKey:idempotencyKey||`refund:${id}`})]);
    return {refund:rr[0],payment:{...payment,status:'REFUND_PENDING'},outboxEvent:{id:ev[0].id}};
  });
}

export async function completePaymentRefundOutbox({eventId,jobId,paymentId,refundId,providerRef,actorId,leaseToken}) {
  return withSqlTransaction(async(client)=>{
    const {rows:er}=await client.query(`SELECT lease_token FROM outbox_events WHERE id=$1 FOR UPDATE`,[eventId]);
    if(!er[0])return {completed:false,reason:'OUTBOX_NOT_FOUND'};
    if(leaseToken && String(er[0].lease_token)!==String(leaseToken))return {completed:false,reason:'STALE_LEASE'};
    const {rows:pr}=await client.query(`SELECT p.*,j.provider_id,j.status AS job_status FROM payments p JOIN jobs j ON j.id=p.job_id WHERE p.id=$1 AND p.job_id=$2 FOR UPDATE`,[paymentId,jobId]);
    const payment=pr[0]; if(!payment)return {completed:false,reason:'PAYMENT_NOT_FOUND'};
    const {rows:rr}=await client.query(`SELECT * FROM refunds WHERE id=$1 AND payment_id=$2 FOR UPDATE`,[refundId,paymentId]); const refund=rr[0]; if(!refund)return {completed:false,reason:'REFUND_NOT_FOUND'};
    if(payment.status==='REFUNDED' && refund.status==='REFUNDED'){await client.query(`UPDATE outbox_events SET status='DONE',processed_at=COALESCE(processed_at,NOW()),locked_at=NULL,last_error=NULL WHERE id=$1`,[eventId]);return {completed:true,alreadyDone:true};}
    if(payment.status!=='REFUND_PENDING' || refund.status!=='PENDING'){return {completed:false,reason:'INVALID_REFUND_STATE'};}
    const breakdown={baseAmount:Number(payment.base_amount||payment.amount),employerFee:Number(payment.employer_fee||0),workerFee:Number(payment.worker_fee||0),platformFee:Number(payment.platform_fee||0),employerCharge:Number(payment.employer_charge||payment.amount),providerPayout:Number(payment.provider_payout||payment.amount),currency:payment.currency||'USD',policyVersion:payment.fee_policy_version||'legacy',kind:'JOB'};
    await client.query(`UPDATE refunds SET status='REFUNDED',provider_ref=$2,updated_at=NOW() WHERE id=$1`,[refundId,providerRef]);
    await client.query(`UPDATE payments SET status='REFUNDED',provider_ref=$2,updated_at=NOW() WHERE id=$1`,[paymentId,payment.provider_ref]);
    await client.query(`UPDATE jobs SET status=CASE WHEN provider_id IS NULL THEN 'PUBLISHED' ELSE 'ASSIGNED' END,updated_at=NOW() WHERE id=$1`,[jobId]);
    const journalId=crypto.randomUUID(); for(const entry of refundJournal(breakdown)) await client.query(`INSERT INTO ledger_entries(id,journal_id,reference_type,reference_id,account,debit,credit,currency,created_at) VALUES($1,$2,'PAYMENT_REFUND',$3,$4,$5,$6,$7,NOW())`,[crypto.randomUUID(),journalId,paymentId,entry.account,entry.debit,entry.credit,breakdown.currency]);
    await client.query(`INSERT INTO audit_logs(id,action,actor_id,entity_type,entity_id,meta,created_at) VALUES($1,'PAYMENT_REFUND',$2,'payment',$3,$4::jsonb,NOW())`,[crypto.randomUUID(),actorId,paymentId,JSON.stringify({jobId,refundId,eventId,providerRef})]);
    await client.query(`UPDATE outbox_events SET status='DONE',processed_at=NOW(),locked_at=NULL,last_error=NULL WHERE id=$1`,[eventId]);
    return {completed:true,alreadyDone:false};
  });
}

export async function applyPaymentWebhookAtomic({eventId,eventType,paymentId,providerRef,payload}) {
  return withSqlTransaction(async(client)=>{
    const prior=await client.query(`SELECT * FROM payment_webhook_events WHERE event_id=$1`,[eventId]);
    if(prior.rows[0]) return {processed:true,duplicate:true,paymentId:prior.rows[0].payment_id};
    const {rows:insertedEvents}=await client.query(`INSERT INTO payment_webhook_events(id,event_id,event_type,payment_id,provider_ref,payload,processed_at,created_at) VALUES($1,$2,$3,$4,$5,$6::jsonb,NOW(),NOW()) ON CONFLICT(event_id) DO NOTHING RETURNING payment_id`,[crypto.randomUUID(),eventId,eventType,paymentId || null,providerRef || null,JSON.stringify(payload||{})]);
    if (!insertedEvents.length) {
      const duplicate = await client.query(`SELECT payment_id FROM payment_webhook_events WHERE event_id=$1`,[eventId]);
      return {processed:true,duplicate:true,paymentId:duplicate.rows[0]?.payment_id || null};
    }
    const {rows:pr}=await client.query(`SELECT * FROM payments WHERE id=$1 FOR UPDATE`,[paymentId]);
    if(!pr[0]) return {processed:true,duplicate:false,paymentId:null};
    const p=pr[0];
    if(eventType==='PAYMENT_HELD' && p.status==='HOLD_PENDING') await client.query(`UPDATE payments SET status='HELD',provider_ref=$2,updated_at=NOW() WHERE id=$1`,[paymentId,providerRef]);
    else if(eventType==='PAYMENT_RELEASED' && p.status==='RELEASE_PENDING') { await client.query(`UPDATE payments SET status='RELEASED',updated_at=NOW() WHERE id=$1`,[paymentId]); await client.query(`UPDATE jobs SET status='SETTLED',updated_at=NOW() WHERE id=$1`,[p.job_id]); const b={baseAmount:Number(p.base_amount||p.amount),employerFee:Number(p.employer_fee||0),workerFee:Number(p.worker_fee||0),platformFee:Number(p.platform_fee||0),employerCharge:Number(p.employer_charge||p.amount),providerPayout:Number(p.provider_payout||p.amount),currency:p.currency||'USD'}; for(const journal of [releaseJournal(b),payoutJournal(b)]){const jid=crypto.randomUUID();for(const e of journal)await client.query(`INSERT INTO ledger_entries(id,journal_id,reference_type,reference_id,account,debit,credit,currency,created_at) VALUES($1,$2,'PAYMENT_WEBHOOK',$3,$4,$5,$6,$7,NOW())`,[crypto.randomUUID(),jid,paymentId,e.account,e.debit,e.credit,b.currency]);} await client.query(`INSERT INTO settlements(id,payment_id,provider_ref,amount,currency,status,created_at,updated_at) VALUES($1,$2,$3,$4,$5,'RELEASED',NOW(),NOW()) ON CONFLICT(payment_id) DO UPDATE SET status='RELEASED',provider_ref=EXCLUDED.provider_ref,updated_at=NOW()`,[crypto.randomUUID(),paymentId,providerRef, b.providerPayout,b.currency]); }
    else if(eventType==='PAYMENT_REFUNDED' && p.status==='REFUND_PENDING'){
      const {rows:rr}=await client.query(`SELECT * FROM refunds WHERE payment_id=$1 AND status='PENDING' ORDER BY created_at DESC LIMIT 1 FOR UPDATE`,[paymentId]);
      const refund=rr[0];
      if(refund){
        const b={baseAmount:Number(p.base_amount||p.amount),employerFee:Number(p.employer_fee||0),workerFee:Number(p.worker_fee||0),platformFee:Number(p.platform_fee||0),employerCharge:Number(p.employer_charge||p.amount),providerPayout:Number(p.provider_payout||p.amount),currency:p.currency||'USD'};
        await client.query(`UPDATE refunds SET status='REFUNDED',provider_ref=COALESCE($2,provider_ref),updated_at=NOW() WHERE id=$1`,[refund.id,providerRef||null]);
        await client.query(`UPDATE payments SET status='REFUNDED',updated_at=NOW() WHERE id=$1`,[paymentId]);
        await client.query(`UPDATE jobs SET status=CASE WHEN provider_id IS NULL THEN 'PUBLISHED' ELSE 'ASSIGNED' END,updated_at=NOW() WHERE id=$1`,[p.job_id]);
        const jid=crypto.randomUUID();for(const e of refundJournal(b))await client.query(`INSERT INTO ledger_entries(id,journal_id,reference_type,reference_id,account,debit,credit,currency,created_at) VALUES($1,$2,'PAYMENT_WEBHOOK',$3,$4,$5,$6,$7,NOW())`,[crypto.randomUUID(),jid,paymentId,e.account,e.debit,e.credit,b.currency]);
      }
    }
    return {processed:true,duplicate:false,paymentId};
  });
}


export async function getAdminFinancialSummary() {
  const { rows } = await requirePool().query(`SELECT COUNT(*)::int AS payments, COUNT(*) FILTER (WHERE status IN ('HOLD_PENDING','REFUND_PENDING','RELEASE_PENDING'))::int AS pending, COUNT(*) FILTER (WHERE status='HELD')::int AS held, COUNT(*) FILTER (WHERE status='RELEASED')::int AS released, COUNT(*) FILTER (WHERE status='REFUNDED')::int AS refunded, COALESCE(SUM(platform_fee),0) AS platform_fees, COALESCE(SUM(employer_charge),0) AS employer_charges, COALESCE(SUM(provider_payout),0) AS provider_payouts FROM payments`);
  const counts = rows[0];
  const [{rows:rr},{rows:sr},{rows:lr}] = await Promise.all([requirePool().query(`SELECT COUNT(*)::int AS count FROM refunds`),requirePool().query(`SELECT COUNT(*)::int AS count FROM settlements`),requirePool().query(`SELECT COUNT(*)::int AS count FROM ledger_entries`)]);
  return {payments:counts.payments,pending:counts.pending,held:counts.held,released:counts.released,refunded:counts.refunded,platformFees:Number(counts.platform_fees||0),employerCharges:Number(counts.employer_charges||0),providerPayouts:Number(counts.provider_payouts||0),refunds:Number(rr[0].count||0),settlements:Number(sr[0].count||0),ledgerEntries:Number(lr[0].count||0),currency:config.paymentCurrency};
}
