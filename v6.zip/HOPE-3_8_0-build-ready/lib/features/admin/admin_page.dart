import 'package:flutter/material.dart';
import '../../core/ui/hope_l10n.dart';
import '../../core/network/api_client.dart';
import '../../core/ui/components.dart';
import '../../theme/app_theme.dart';

class AdminPage extends StatefulWidget {
  const AdminPage({super.key, required this.api});
  final ApiClient api;
  @override State<AdminPage> createState() => _AdminPageState();
}

// Route contracts: /admin/applications/$id/shortlist | /admin/applications/$id/select | /admin/applications/$id/reject
class _AdminPageState extends State<AdminPage> with SingleTickerProviderStateMixin {
  late Future<dynamic> _summary;
  late Future<dynamic> _jobs;
  late Future<dynamic> _applications;
  late Future<dynamic> _users;
  late Future<dynamic> _audit;
  late TabController _tabs;

  @override void initState() { super.initState(); _tabs = TabController(length: 4, vsync: this); _reload(); }
  @override void dispose() { _tabs.dispose(); super.dispose(); }
  void _reload() {
    _summary = widget.api.request('GET', '/admin/summary', auth: true);
    _jobs = widget.api.request('GET', '/admin/jobs', auth: true);
    _applications = widget.api.request('GET', '/admin/applications', auth: true);
    _users = widget.api.request('GET', '/admin/users', auth: true);
    _audit = widget.api.request('GET', '/admin/audit', auth: true);
    if (mounted) setState(() {});
  }

  @override Widget build(BuildContext context) => Directionality(
    textDirection: Localizations.localeOf(context).languageCode == 'en' ? TextDirection.ltr : TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: Text(HopeCopy.of(context).copy_hope_admin_center_912aa06)),
      body: RefreshIndicator(onRefresh: () async => _reload(), child: ListView(padding: const EdgeInsets.fromLTRB(20, 8, 20, 40), children: [
        GradientHero(eyebrow: HopeCopy.of(context).copy_control_center_15e20c8, title: HopeCopy.of(context).copy_monitor_and_manage_hope_in_one_place_bea3b7d, message: HopeCopy.of(context).copy_review_users_opportunities_applications_an_e30b9d2, icon: Icons.admin_panel_settings_rounded),
        const SizedBox(height: 18),
        FutureBuilder<dynamic>(future: _summary, builder: (context, s) => _summaryGrid(context, s.data)),
        const SizedBox(height: 18),
        TabBar(controller: _tabs, isScrollable: true, tabs: [Tab(text: HopeCopy.of(context).copy_opportunities_015066e), Tab(text: HopeCopy.of(context).copy_applications_6655869), Tab(text: HopeCopy.of(context).copy_users_200338b), Tab(text: HopeCopy.of(context).copy_audit_log_ff87181)]),
        SizedBox(height: 620, child: TabBarView(controller: _tabs, children: [_jobsTab(context), _applicationsTab(context), _usersTab(context), _auditTab(context)])),
      ])),
    ),
  );

  Widget _summaryGrid(BuildContext context, dynamic raw) {
    final m = raw is Map ? raw : const {};
    final items = [
      ['users', HopeCopy.of(context).copy_users_200338b, Icons.people_alt_outlined],
      ['published_opportunities', HopeCopy.of(context).copy_published_1a00f35, Icons.public_rounded],
      ['missions', HopeCopy.of(context).copy_missions_a833d13, Icons.task_alt_rounded],
      ['jobs', HopeCopy.of(context).copy_jobs_ebf9a80, Icons.work_outline_rounded],
      ['pending_applications', HopeCopy.of(context).copy_pending_86ad26d, Icons.hourglass_top_rounded],
      ['audit_events', HopeCopy.of(context).copy_audit_events_7f47fd5, Icons.fact_check_outlined],
    ];
    return GridView.count(crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), childAspectRatio: 2.25,
      children: items.map((e) => HopeSurface(padding: const EdgeInsets.all(13), child: Row(children: [HopeIconTile(e[2] as IconData, filled: true, size: 40), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [Text('${m[e[0]] ?? 0}', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)), Text('${e[1]}', style: Theme.of(context).textTheme.bodySmall)]))]))).toList());
  }

  Widget _jobsTab(BuildContext context) {
    return FutureBuilder<dynamic>(
      future: _jobs,
      builder: (context, snapshot) {
        final list = snapshot.data is List ? snapshot.data as List : const [];

        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (list.isEmpty) {
          return EmptyState(
            icon: Icons.work_outline,
            title: HopeCopy.of(context).copy_no_opportunities_a112400,
            message: HopeCopy.of(context)
                .copy_opportunities_appear_here_d85bef9,
          );
        }

        return ListView(
          padding: const EdgeInsets.only(top: 14),
          children: list.take(50).map<Widget>((raw) {
            final job = raw is Map ? raw : const {};
            final status = '${job['status'] ?? '—'}';

            return Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: HopeSurface(
                padding: const EdgeInsets.all(14),
                child: Row(
                  children: [
                    HopeIconTile(
                      job['kind'] == 'JOB'
                          ? Icons.work_outline_rounded
                          : Icons.task_alt_rounded,
                      filled: true,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${job['title'] ?? '—'}',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 3),
                          Text(
                            '${job['kind'] ?? '—'} • ${job['city'] ?? HopeCopy.of(context).copy_remote_dcbb625} • $status',
                          ),
                        ],
                      ),
                    ),
                    if (status == 'DRAFT')
                      IconButton(
                        onPressed: () =>
                            _moderateJob('${job['id']}', 'PUBLISHED'),
                        tooltip: HopeCopy.of(context).copy_publish_5cfd26b,
                        icon: const Icon(Icons.publish_rounded),
                      ),
                    if (status == 'PUBLISHED')
                      IconButton(
                        onPressed: () =>
                            _moderateJob('${job['id']}', 'CANCELLED'),
                        tooltip: HopeCopy.of(context).copy_disable_73bea34,
                        icon: const Icon(Icons.block_outlined),
                      ),
                    IconButton(
                      onPressed: () => _removeJob('${job['id']}'),
                      tooltip: HopeCopy.of(context).copy_delete_b17eb9d,
                      icon: const Icon(
                        Icons.delete_outline_rounded,
                        color: AppColors.danger,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }).toList(),
        );
      },
    );
  }

  Widget _applicationsTab(BuildContext context) => FutureBuilder<dynamic>(future: _applications, builder: (context, snapshot) { final list=snapshot.data is List?snapshot.data as List:const []; if(snapshot.connectionState==ConnectionState.waiting)return const Center(child:CircularProgressIndicator()); if(list.isEmpty)return EmptyState(icon:Icons.inbox_outlined,title:HopeCopy.of(context).copy_no_applications_0917e11,message:HopeCopy.of(context).copy_job_applications_are_managed_here_1b21e96); return ListView(padding: const EdgeInsets.only(top:14), children:list.take(50).map<Widget>((raw){final a=raw is Map?raw:const {}; final status='${a['status']??'PENDING'}'; return Padding(padding:const EdgeInsets.only(bottom:10),child:HopeSurface(padding:const EdgeInsets.all(14),child:Column(children:[ListTile(contentPadding:EdgeInsets.zero,leading:const HopeIconTile(Icons.description_outlined,filled:true),title:Text('${a['candidateName']??HopeCopy.of(context).copy_candidate_c67d7bf}'),subtitle:Text('${a['jobTitle']??HopeCopy.of(context).copy_job_ce2feba} • $status')),if(status=='PENDING')Row(children:[Expanded(child:OutlinedButton.icon(onPressed:()=>_applicationAction('${a['id']}','shortlist'),icon:const Icon(Icons.star_border_rounded),label:Text(HopeCopy.of(context).copy_shortlist_8a78995))),const SizedBox(width:8),Expanded(child:FilledButton.icon(onPressed:()=>_applicationAction('${a['id']}','select'),icon:const Icon(Icons.send_rounded),label:Text(HopeCopy.of(context).copy_forward_5ec70ea))),const SizedBox(width:8),IconButton(onPressed:()=>_applicationAction('${a['id']}','reject'),tooltip:HopeCopy.of(context).copy_reject_application_9682e01,icon:const Icon(Icons.close_rounded,color:AppColors.danger))]),if(status=='SHORTLISTED')Row(children:[Expanded(child:FilledButton.icon(onPressed:()=>_applicationAction('${a['id']}','select'),icon:const Icon(Icons.send_rounded),label:Text(HopeCopy.of(context).copy_forward_to_employer_0baa2e1))),IconButton(onPressed:()=>_applicationAction('${a['id']}','reject'),tooltip:HopeCopy.of(context).copy_reject_application_9682e01,icon:const Icon(Icons.close_rounded,color:AppColors.danger))])])));}).toList()); });

  Widget _usersTab(BuildContext context) => FutureBuilder<dynamic>(future:_users,builder:(context,snapshot){final list=snapshot.data is List?snapshot.data as List:const [];if(snapshot.connectionState==ConnectionState.waiting)return const Center(child:CircularProgressIndicator());return ListView(padding:const EdgeInsets.only(top:14),children:list.take(100).map<Widget>((raw){final u=raw is Map?raw:const {};final status='${u['status']??'ACTIVE'}';return Padding(padding:const EdgeInsets.only(bottom:10),child:HopeSurface(padding:const EdgeInsets.all(12),child:ListTile(contentPadding:EdgeInsets.zero,leading:CircleAvatar(child:Text('${u['displayName']??'?'}'.characters.first)),title:Text('${u['displayName']??'—'}'),subtitle:Text('${u['email']??'—'} • ${u['role']??'USER'} • $status'),trailing:u['role']=='ADMIN'?null:IconButton(onPressed:()=>_setUserStatus('${u['id']}',status=='ACTIVE'?'SUSPENDED':'ACTIVE'),tooltip:status=='ACTIVE'?HopeCopy.of(context).copy_suspend_44bded8:HopeCopy.of(context).copy_activate_2215693,icon:Icon(status=='ACTIVE'?Icons.pause_circle_outline:Icons.play_circle_outline)))));}).toList());});

  Widget _auditTab(BuildContext context) => FutureBuilder<dynamic>(future:_audit,builder:(context,snapshot){final list=snapshot.data is List?snapshot.data as List:const [];if(snapshot.connectionState==ConnectionState.waiting)return const Center(child:CircularProgressIndicator());return ListView(padding:const EdgeInsets.only(top:14),children:list.take(100).map<Widget>((raw){final a=raw is Map?raw:const {};return Padding(padding:const EdgeInsets.only(bottom:8),child:HopeSurface(padding:const EdgeInsets.all(12),child:ListTile(contentPadding:EdgeInsets.zero,leading:const HopeIconTile(Icons.history_rounded),title:Text('${a['action']??'—'}'),subtitle:Text('${a['actorName']??HopeCopy.of(context).copy_system_bf4e081} • ${a['entityType']??'—'} • ${a['createdAt']??'—'}'))));}).toList());});

  Future<void> _applicationAction(String id,String action) async { await widget.api.request('POST','/admin/applications/$id/$action',auth:true); _reload(); }
  Future<void> _moderateJob(String id,String status) async { await widget.api.request('POST','/admin/jobs/$id/moderate',body:{'status':status},auth:true); _reload(); }
  Future<void> _setUserStatus(String id,String status) async { await widget.api.request('POST','/admin/users/$id/status',body:{'status':status},auth:true); _reload(); }
  Future<void> _removeJob(String id) async { await widget.api.request('DELETE','/admin/jobs/$id',auth:true); _reload(); }
}
