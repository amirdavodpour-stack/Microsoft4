import 'package:flutter/material.dart';
import '../../core/ui/hope_l10n.dart';
import 'package:provider/provider.dart';
import '../../core/network/api_client.dart';
import '../../core/network/api_error_presenter.dart';
import '../../core/settings/settings_controller.dart';
import '../../core/marketplace/category.dart';
import '../../core/marketplace/job.dart';
import '../../core/ui/components.dart';
import '../../core/ui/copy.dart';
import '../../theme/app_theme.dart';
import '../marketplace/job_detail_page.dart';

class JobsPage extends StatefulWidget {
  const JobsPage({super.key, required this.api});
  final ApiClient api;
  @override State<JobsPage> createState() => _JobsPageState();
}

class _JobsPageState extends State<JobsPage> {
  late Future<dynamic> _future;
  String _query = '';
  String _kind = 'ALL';
  String _visibility = 'ALL';
  String _city = 'AUTO';
  String _category = 'ALL';
  List<HopeCategory> _categories = const [];
  String? _categoryError;
  @override void didChangeDependencies() { super.didChangeDependencies(); if (_categoriesFutureInitialized) return; _categoriesFutureInitialized = true; _loadCategories(); }
  bool _categoriesFutureInitialized = false;
  Future<List<HopeCategory>> _loadCategories() async { try { final raw=await widget.api.request('GET','/categories'); final list=raw is List?raw:raw is Map&&raw['data'] is List?raw['data']:const []; final parsed=flattenCategories(list.whereType<Map>().map((m)=>HopeCategory.fromMap(Map<String,dynamic>.from(m))).toList()); if(mounted){setState(()=>_categories=parsed);} return parsed; } catch (error) { if(mounted){setState(()=>_categoryError=apiErrorMessage(error, fallback:'دسته‌بندی‌ها بارگذاری نشدند.'));} return const []; } }
  @override void initState() { super.initState(); _future = _loadOpportunities(); }
  Future<void> _refresh() async { setState(() => _future = _loadOpportunities()); await _future.catchError((_) {}); }
  Future<dynamic> _loadOpportunities() {
    final settings = context.read<HopeSettingsController>();
    final selectedCity = _city == 'AUTO' ? settings.city : _city;
    if (!settings.personalizedRecommendations) return widget.api.request('GET', '/jobs?city=${Uri.encodeQueryComponent(selectedCity)}');
    final query = <String>['city=${Uri.encodeQueryComponent(selectedCity)}'];
    if (settings.locationEnabled && settings.latitude != null && settings.longitude != null) {
      query.add('lat=${settings.latitude}');
      query.add('lng=${settings.longitude}');
    }
    return widget.api.request('GET', '/jobs/recommended?${query.join('&')}');
  }

  List<HopeJob> _normalize(dynamic raw) => (raw is List ? raw : raw is Map && raw['data'] is List ? raw['data'] : const []).whereType<Map>().map((m) => HopeJob.fromMap(Map<String, dynamic>.from(m))).toList();
  // Arabic-range letters (ي ك ة ؤ إ أ آ) are visually near-identical to their
  // Persian counterparts and appear interchangeably in real data, but plain
  // toLowerCase() never unifies them — a Persian keyboard's "ی"/"ک" would
  // silently fail to match server text typed with the Arabic "ي"/"ك". This
  // also strips Arabic diacritics and normalizes Persian/Arabic digits so
  // "۱۴۰۳" and "1403" match the same query.
  static String _normalizePersian(String input) {
    var s = input.toLowerCase();
    const letterMap = {'ي':'ی','ك':'ک','ة':'ه','ؤ':'و','إ':'ا','أ':'ا','آ':'ا','ۀ':'ه'};
    letterMap.forEach((from, to) => s = s.replaceAll(from, to));
    s = s.replaceAll(RegExp(r'[\u064B-\u065F\u0670\u200c\u200f]'), ' ');
    const digitMap = {'۰':'0','۱':'1','۲':'2','۳':'3','۴':'4','۵':'5','۶':'6','۷':'7','۸':'8','۹':'9','٠':'0','١':'1','٢':'2','٣':'3','٤':'4','٥':'5','٦':'6','٧':'7','٨':'8','٩':'9'};
    digitMap.forEach((from, to) => s = s.replaceAll(from, to));
    return s.replaceAll(RegExp(r'\s+'), ' ').trim();
  }
  List<HopeJob> _filter(List<HopeJob> jobs) {
    final settings = context.read<HopeSettingsController>(); final activeCity = _city == 'AUTO' ? settings.city : _city; final q = _normalizePersian(_query.trim());
    return jobs.where((j) {
      final kind = j.kind;
      final vis = j.visibility;
      final city = j.city ?? 'آنلاین';
      final category = j.category ?? j.categoryId ?? '';
      final text = _normalizePersian([j.title, j.description, j.city, j.category].map((e)=>'$e').join(' '));
      final kindOk = _kind == 'ALL' || kind == _kind; final visOk = _visibility == 'ALL' || vis == _visibility; final cityOk = activeCity == 'همه' || city == activeCity || city == 'آنلاین'; final catOk = _category == 'ALL' || category == _category; final qOk = q.isEmpty || text.contains(q);
      return kindOk && visOk && cityOk && catOk && qOk;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<HopeSettingsController>();
    return RefreshIndicator(onRefresh: _refresh, child: FutureBuilder<dynamic>(future: _future, builder: (context, snapshot) {
      final jobs = _filter(_normalize(snapshot.data));
      return CustomScrollView(physics: const AlwaysScrollableScrollPhysics(), slivers: [
        SliverPadding(padding: const EdgeInsets.fromLTRB(20, 16, 20, 12), sliver: SliverToBoxAdapter(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(HopeCopy.of(context).copy_explore_115e9fd, style: Theme.of(context).textTheme.displaySmall), const SizedBox(height: 5), Text(HopeCopy.of(context).copy_see_missions_and_jobs_together_then_narrow_7e573a3, style: Theme.of(context).textTheme.bodyLarge)]),), const HopeIconTile(Icons.explore_rounded, size: 52, filled: true)]),
          const SizedBox(height: 17),
          SearchField(onChanged: (v)=>setState(()=>_query=v), hint: HopeCopy.of(context).copy_title_city_or_skill_bccb024),
          const SizedBox(height: 11),
          SizedBox(height: 44, child: ListView(scrollDirection: Axis.horizontal, children: [
            _chip(context, HopeCopy.of(context).copy_all_ba7d5b6, _kind == 'ALL', ()=>setState(()=>_kind='ALL')),
            _chip(context, HopeCopy.of(context).copy_missions_a833d13, _kind == 'MISSION', ()=>setState(()=>_kind='MISSION'), icon: Icons.bolt_rounded),
            _chip(context, HopeCopy.of(context).copy_jobs_ebf9a80, _kind == 'JOB', ()=>setState(()=>_kind='JOB'), icon: Icons.business_center_rounded),
            const SizedBox(width: 8), _chip(context, HopeCopy.of(context).copy_public_21e97be, _visibility == 'PUBLIC', ()=>setState(()=>_visibility='PUBLIC')),
            _chip(context, HopeCopy.of(context).copy_specialized_5d1ca04, _visibility == 'SPECIALIZED', ()=>setState(()=>_visibility='SPECIALIZED')),
          ])),
          const SizedBox(height: 10),
          if (_categoryError != null) Padding(padding: const EdgeInsets.only(bottom: 8), child: Row(children: [Expanded(child: Text(_categoryError!, style: Theme.of(context).textTheme.bodySmall)), TextButton(onPressed: () { setState(() { _categoryError = null; _loadCategories(); }); }, child: Text(HopeCopy.of(context).copy_retry_49f3eba))])),
          Wrap(spacing: 7, runSpacing: 7, children: [
            ActionChip(avatar: const Icon(Icons.location_on_outlined, size: 17), label: Text(_city == 'AUTO' ? '${HopeCopy.of(context).copy_near_1df6db0} ${settings.city}' : _city), onPressed: ()=>_pickCity(context, settings)),
            ActionChip(avatar: const Icon(Icons.category_outlined, size: 17), label: Text(_category == 'ALL' ? HopeCopy.of(context).copy_all_fields_4f77401 : _category), onPressed: ()=>_pickCategory(context)),
            Semantics(liveRegion: true, label: '${jobs.length} ${HopeCopy.of(context).copy_results_2d120a3}', child: StatusPill('${jobs.length} ${HopeCopy.of(context).copy_results_2d120a3}', icon: Icons.grid_view_rounded)),
          ]),
        ]))),
        if (snapshot.connectionState == ConnectionState.waiting) SliverPadding(padding: const EdgeInsets.fromLTRB(20, 0, 20, 122), sliver: SliverList(delegate: SliverChildListDelegate([const OpportunitySkeletonCard(), SizedBox(height: 12), const OpportunitySkeletonCard()])))
        else if (snapshot.hasError) SliverFillRemaining(hasScrollBody: false, child: EmptyState(icon: Icons.cloud_off_rounded, title: HopeCopy.of(context).copy_connection_failed_1b34bc9, message: HopeCopy.of(context).copy_the_server_did_not_return_data_try_again_bccfbb3))
        else if (jobs.isEmpty) SliverFillRemaining(hasScrollBody: false, child: EmptyState(icon: Icons.search_off_rounded, title: HopeCopy.of(context).copy_no_matching_opportunity_d85e775, message: HopeCopy.of(context).copy_broaden_your_filters_or_try_another_city_e8e32cb))
        else SliverPadding(padding: const EdgeInsets.fromLTRB(20, 0, 20, 122), sliver: SliverList(delegate: SliverChildBuilderDelegate((context,index)=>Padding(padding: const EdgeInsets.only(bottom: 12), child: _JobCard(api: widget.api, job: jobs[index])), childCount: jobs.length))),
      ]);
    }));
  }

  Widget _chip(BuildContext context, String text, bool selected, VoidCallback onTap, {IconData? icon}) => Padding(padding: const EdgeInsets.only(right: 7), child: ChoiceChip(selected: selected, label: Text(text), avatar: icon == null ? null : Icon(icon, size: 17), onSelected: (_) => onTap()));
  Future<void> _pickCity(BuildContext context, HopeSettingsController settings) async { final c = await showModalBottomSheet<String>(context: context, showDragHandle: true, builder: (_) => ListView(padding: const EdgeInsets.all(20), shrinkWrap: true, children: [Text(HopeCopy.of(context).copy_choose_a_city_a93b334, style: Theme.of(context).textTheme.headlineSmall), ...[...HopeSettingsController.cities,'همه'].map((city)=>ListTile(title: Text(city), trailing: (_city == city || (_city=='AUTO' && city==settings.city)) ? const Icon(Icons.check_rounded) : null, onTap: ()=>Navigator.pop(context,city)))])); if (c != null) { final next = c == settings.city ? 'AUTO' : c; setState(()=>_city=next); setState(()=>_future=_loadOpportunities()); await _future.catchError((_) {}); } }
  Future<void> _pickCategory(BuildContext context) async {
    final categories = _categories;
    final c = await showModalBottomSheet<String>(context: context, showDragHandle: true, builder: (_) => ListView(shrinkWrap: true, padding: const EdgeInsets.all(20), children: [Text(HopeCopy.of(context).copy_professional_field_4c6b94e, style: Theme.of(context).textTheme.headlineSmall), ListTile(title: Text(HopeCopy.of(context).copy_all_fields_4f77401), onTap: ()=>Navigator.pop(context,'ALL')), ...categories.map((x)=>ListTile(title: Text(x.label(Localizations.localeOf(context).languageCode=='en')), subtitle: x.description.isEmpty?null:Text(x.description), onTap: ()=>Navigator.pop(context,x.slug))) ]));
    if (c != null) setState(()=>_category=c);
  }
}

class _JobCard extends StatelessWidget {
  const _JobCard({required this.api, required this.job}); final ApiClient api; final HopeJob job;
  @override Widget build(BuildContext context) { final isMission=job.isMission; final vis=job.visibility; final city=job.city ?? 'آنلاین'; final title=job.title.isEmpty ? HopeCopy.of(context).copy_untitled_d89410e : job.title; final amount=isMission?'${job.budgetMin ?? '—'} – ${job.budgetMax ?? '—'}':'${job.monthlySalary ?? job.budgetMin ?? '—'}';
  // PressableScale hides its child subtree from the accessibility tree
  // (excludeSemantics: true) and only exposes a single announced label, so
  // without this the whole card was announced as an unlabeled "button" —
  // title, city and pay were invisible to TalkBack/VoiceOver.
  final cardLabel = '${isMission ? HopeCopy.of(context).copy_mission_fb4c5e1 : HopeCopy.of(context).copy_job_ce2feba}. $title. $city. ${moneyLabel(context, amount)}';
  return PressableScale(onTap: ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>JobDetailPage(api:api,job:job))), semanticLabel: cardLabel, child: HopeSurface(highlight:true, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Stack(children: [ClipRRect(borderRadius: const BorderRadius.vertical(top: Radius.circular(26)), child: SizedBox(height: 110, width: double.infinity, child: Image.asset('assets/images/hope_marketplace_hero.png', fit: BoxFit.cover))), Positioned(top:12, right:12, child: StatusPill(isMission?HopeCopy.of(context).copy_mission_fb4c5e1:HopeCopy.of(context).copy_job_ce2feba, color:isMission?AppColors.primary:AppColors.secondary, icon:isMission?Icons.bolt_rounded:Icons.business_center_rounded)), Positioned(top:12,left:12,child:StatusPill(vis=='SPECIALIZED'?HopeCopy.of(context).copy_specialized_5d1ca04:HopeCopy.of(context).copy_public_21e97be,color:vis=='SPECIALIZED'?AppColors.warning:Colors.white,icon:Icons.visibility_outlined))]), Padding(padding: const EdgeInsets.all(17), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title,maxLines:2,overflow:TextOverflow.ellipsis,style:Theme.of(context).textTheme.titleLarge), const SizedBox(height:5), Wrap(spacing:7,runSpacing:5,children:[Text('${city} • ${job.category ?? ''}',style:Theme.of(context).textTheme.bodyMedium), if(job.distanceKm!=null) StatusPill('${job.distanceKm} km',icon:Icons.near_me_rounded,color:AppColors.secondary)]), const SizedBox(height:12), Text(isMission?HopeCopy.of(context).copy_pay_4121159:HopeCopy.of(context).copy_monthly_pay_d62519b,style:Theme.of(context).textTheme.bodyMedium), const SizedBox(height:2), Text(moneyLabel(context,amount),style:Theme.of(context).textTheme.titleMedium), const SizedBox(height:12), Wrap(spacing:7,children:[if(job.applicationDeadline!=null && !isMission) StatusPill('${HopeCopy.of(context).copy_deadline_ffa13f2}: ${job.applicationDeadline}',color:AppColors.warning,icon:Icons.event_outlined), StatusPill(isMission?HopeCopy.of(context).copy_one_time_1d496d8:HopeCopy.of(context).copy_part_full_time_4d952a9,color:AppColors.secondary,icon:Icons.schedule_rounded)])]))]))); }
}
