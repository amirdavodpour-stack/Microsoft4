import 'package:flutter/material.dart';
import '../../core/ui/hope_l10n.dart';
import 'package:provider/provider.dart';
import '../../core/network/api_client.dart';
import '../../core/auth/auth_controller.dart';
import '../../core/ui/components.dart';
import '../../theme/app_theme.dart';
import '../auth/login_page.dart';

class TransactionsPage extends StatefulWidget {
  const TransactionsPage({super.key, required this.api});
  final ApiClient api;
  @override State<TransactionsPage> createState() => _TransactionsPageState();
}

class _TransactionsPageState extends State<TransactionsPage> {
  Future<dynamic>? future; String? loadedUserId;
  @override void didChangeDependencies() { super.didChangeDependencies(); final id = context.read<AuthController>().user?['id']?.toString(); if (id != loadedUserId) { loadedUserId = id; future = id == null ? null : widget.api.request('GET', '/jobs/mine', auth: true); } }
  Future<void> reload() async { setState(() => future = widget.api.request('GET', '/jobs/mine', auth: true)); await future?.catchError((_) => null); }
  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthController>();
    if (auth.isGuest) return Center(child: EmptyState(icon: Icons.lock_outline_rounded, title: HopeCopy.of(context).copy_your_activity_is_private_1363766, message: HopeCopy.of(context).copy_sign_in_to_view_your_projects_and_payments_32a2bc2, action: FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LoginPage(api: widget.api))), icon: const Icon(Icons.login_rounded), label: Text(HopeCopy.of(context).copy_log_in_b4c960b))));
    if (future == null) return const Center(child: CircularProgressIndicator());
    return FutureBuilder<dynamic>(future: future, builder: (context, snap) {
      if (snap.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
      if (snap.hasError) return RefreshIndicator(onRefresh: reload, child: ListView(children: [const SizedBox(height: 220), EmptyState(icon: Icons.cloud_off_rounded, title: HopeCopy.of(context).copy_could_not_load_activity_335b923, message: HopeCopy.of(context).copy_pull_down_to_try_again_c41d215) ]));
      final items = snap.data is List ? (snap.data as List).whereType<Map>().toList() : <Map>[];
      if (items.isEmpty) return RefreshIndicator(onRefresh: reload, child: ListView(children: [const SizedBox(height: 220), EmptyState(icon: Icons.auto_graph_rounded, title: HopeCopy.of(context).copy_no_activity_yet_264ceb0, message: HopeCopy.of(context).copy_your_projects_applications_and_payments_wi_bec5340) ]));
      return RefreshIndicator(onRefresh: reload, child: ListView(padding: const EdgeInsets.fromLTRB(20, 17, 20, 122), children: [
        Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(HopeCopy.of(context).copy_activity_4b38716, style: Theme.of(context).textTheme.displaySmall), const SizedBox(height: 5), Text(HopeCopy.of(context).copy_projects_progress_and_payments_at_a_glance_a0178c8, style: Theme.of(context).textTheme.bodyLarge)])), const HopeIconTile(Icons.swap_horizontal_circle_rounded, size: 50, filled: true)]),
        const SizedBox(height: 18), Row(children: [Expanded(child: MetricTile(label: HopeCopy.of(context).copy_total_projects_78ce548, value: '${items.length}', icon: Icons.work_history_rounded)), const SizedBox(width: 10), Expanded(child: MetricTile(label: HopeCopy.of(context).copy_status_b81f9c7, value: HopeCopy.of(context).copy_active_5726b26, icon: Icons.bolt_rounded, color: AppColors.secondary))]),
        const SizedBox(height: 20), SectionTitle(title: HopeCopy.of(context).copy_latest_activity_a05277b, subtitle: HopeCopy.of(context).copy_the_most_recent_project_updates_5e402d8), const SizedBox(height: 12),
        ...items.map((job) { final transaction = job['transaction'] as Map?; final status = '${transaction?['status'] ?? job['status'] ?? '—'}'; final released = status == 'RELEASED' || status == 'COMPLETED'; return Padding(padding: const EdgeInsets.only(bottom: 12), child: HopeSurface(padding: const EdgeInsets.all(17), child: Row(children: [HopeIconTile(released ? Icons.check_rounded : Icons.hourglass_top_rounded, color: released ? AppColors.success : AppColors.primary, filled: true), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${job['title'] ?? ''}', maxLines: 2, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.titleMedium), const SizedBox(height: 5), Text('${HopeCopy.of(context).copy_work_status_eb2d6f2}: ${job['status'] ?? '—'}', style: Theme.of(context).textTheme.bodyMedium)])), const SizedBox(width: 7), StatusPill(released ? HopeCopy.of(context).copy_completed_4ab501b : HopeCopy.of(context).copy_in_progress_ed61091, color: released ? AppColors.success : AppColors.primary)]))); }),
      ]));
    });
  }
}
