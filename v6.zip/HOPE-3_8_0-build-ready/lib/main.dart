import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:hope_mobile/l10n/generated/app_localizations.dart';
import 'package:provider/provider.dart';

import 'core/auth/auth_controller.dart';
import 'core/network/api_client.dart';
import 'core/settings/settings_controller.dart';
import 'core/storage/secure_store.dart';
import 'core/theme/theme_controller.dart';
import 'core/telemetry/telemetry_service.dart';
import 'core/notifications/notification_service.dart';
import 'dart:ui';
import 'theme/app_theme.dart';
import 'core/router/app_router.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final settings = HopeSettingsController();
  await settings.load();

  final store = SecureStore();
  final api = ApiClient(store);
  final telemetry = TelemetryService(store, baseUrl: api.baseUrl);
  final notifications = NotificationService(api);
  await notifications.initialize();
  final auth = AuthController(api, store);
  auth.telemetry = telemetry;
  FlutterError.onError = (details) {
    FlutterError.presentError(details);
    telemetry.recordError(details.exception, details.stack ?? StackTrace.current, context: {'source': 'flutter_error'});
  };
  PlatformDispatcher.instance.onError = (error, stack) {
    telemetry.recordError(error, stack, context: {'source': 'platform_error'});
    return true;
  };
  await telemetry.track('app_opened');
  await auth.restoreSession();
  api.onUnauthorized = () => auth.logout(notifyServer: false);

  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider.value(value: settings),
      ChangeNotifierProvider(create: (_) => ThemeController(settings)),
      ChangeNotifierProvider.value(value: auth),
    ],
    child: WorkMarketplaceApp(api: api),
  ));
}

class WorkMarketplaceApp extends StatelessWidget {
  const WorkMarketplaceApp({super.key, required this.api});
  final ApiClient api;

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeController>();
    final settings = context.watch<HopeSettingsController>();
    final locale = Locale(settings.language);
    final isEn = locale.languageCode == 'en';
    return MaterialApp(
      title: 'HOPE',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: theme.mode,
      locale: locale,
      supportedLocales: const [Locale('fa'), Locale('en')],
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: Directionality(
        textDirection: isEn ? TextDirection.ltr : TextDirection.rtl,
        child: AppRouter(api: api),
      ),
    );
  }
}
