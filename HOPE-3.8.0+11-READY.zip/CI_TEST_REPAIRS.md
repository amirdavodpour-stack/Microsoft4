# CI Test Repairs

The audit harness may provision deterministic CI-only environment fixtures and an isolated MinIO instance. Production validation remains fail-closed and production release signing remains secret-backed.

The audit also applies deterministic source repairs before verification and persists the repaired source archive back to the repository so subsequent runs test the repaired baseline.
