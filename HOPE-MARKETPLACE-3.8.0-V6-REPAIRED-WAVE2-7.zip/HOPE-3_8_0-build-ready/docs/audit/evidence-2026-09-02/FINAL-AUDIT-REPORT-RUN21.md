# HOPE Marketplace — Definitive Audit Report

Generated: 2026-09-02T08:02:38Z

Repository: amirdavodpour-stack/Microsoft4

Commit: 4666d64fe60d5a1f24ba9bb42456b562a6866205

Run ID: 33606343040

Flutter: 3.47.1

Java: 17

Node: 24

## Final Result Matrix

| Area | Result |
|---|---|
| Source | PASS |
| Flutter root | PASS |
| Backend root | PASS |
| Project structure | PASS |
| pubspec.lock | BLOCKED |
| Flutter dependencies | PASS |
| Flutter format | FAIL |
| Flutter analyze | FAIL |
| Flutter tests | FAIL |
| Backend discovery | PASS |
| Backend install | PASS |
| Backend tests/checks | FAIL |
| Backend security | PASS |
| Android config | PASS |
| Android release | BLOCKED |
| Android debug | FAIL |
| Localization/UX | PASS |
| Security static | REVIEW_REQUIRED |
| CI/CD | PASS |
| Runtime | PASS |

## Backend Test Counts

TOTAL=23
PASSED=21
FAILED=2

## High-Signal Failures

/home/runner/work/Microsoft4/Microsoft4/audit-results/backend-tests-summary.txt:3:FAILED=2
/home/runner/work/Microsoft4/Microsoft4/audit-results/android-debug.log:21:FAILURE: Build failed with an exception.
/home/runner/work/Microsoft4/Microsoft4/audit-results/android-debug.log:35:BUILD FAILED in 1s
/home/runner/work/Microsoft4/Microsoft4/audit-results/FINAL-AUDIT-REPORT.md:46:FAILED=2
/home/runner/work/Microsoft4/Microsoft4/audit-results/backend-cases/test_offline.log:29:✔ duplicate email is rejected without a second account (4.038531ms)
/home/runner/work/Microsoft4/Microsoft4/audit-results/backend-cases/test.log:29:✔ duplicate email is rejected without a second account (4.01753ms)
/home/runner/work/Microsoft4/Microsoft4/audit-results/backend-cases/test_s3.log:23:  Error: connect ECONNREFUSED 127.0.0.1:9000
/home/runner/work/Microsoft4/Microsoft4/audit-results/flutter-analyze.log:12:  error • The name 'copy_value_irr_ed45261' is already defined. Try renaming one of the declarations • lib/core/ui/hope_l10n.dart:284:10 • duplicate_definition
/home/runner/work/Microsoft4/Microsoft4/audit-results/flutter-tests.log:2:lib/core/ui/hope_l10n.dart:284:10: Error: 'copy_value_irr_ed45261' is already declared in this scope.
/home/runner/work/Microsoft4/Microsoft4/audit-results/flutter-tests.log:10:Compilation failed for testPath=/home/runner/work/Microsoft4/Microsoft4/source/HOPE-3_8_0-build-ready/test/ui_components_test.dart: lib/core/ui/hope_l10n.dart:284:10: Error: 'copy_value_irr_ed45261' is already declared in this scope.
/home/runner/work/Microsoft4/Microsoft4/audit-results/flutter-tests.log:20:Error: The Dart compiler exited unexpectedly.
/home/runner/work/Microsoft4/Microsoft4/audit-results/flutter-tests.log:48:lib/core/ui/hope_l10n.dart:284:10: Error: 'copy_value_irr_ed45261' is already declared in this scope.
/home/runner/work/Microsoft4/Microsoft4/audit-results/flutter-tests.log:57:Compilation failed for testPath=/home/runner/work/Microsoft4/Microsoft4/source/HOPE-3_8_0-build-ready/test/smoke_app_test.dart: lib/core/ui/hope_l10n.dart:284:10: Error: 'copy_value_irr_ed45261' is already declared in this scope.
/home/runner/work/Microsoft4/Microsoft4/audit-results/flutter-tests.log:67:Error: The Dart compiler exited unexpectedly.
/home/runner/work/Microsoft4/Microsoft4/audit-results/flutter-tests.log:108:lib/core/ui/hope_l10n.dart:284:10: Error: 'copy_value_irr_ed45261' is already declared in this scope.
/home/runner/work/Microsoft4/Microsoft4/audit-results/flutter-tests.log:117:Compilation failed for testPath=/home/runner/work/Microsoft4/Microsoft4/source/HOPE-3_8_0-build-ready/test/localization_accessibility_contract_test.dart: lib/core/ui/hope_l10n.dart:284:10: Error: 'copy_value_irr_ed45261' is already declared in this scope.
/home/runner/work/Microsoft4/Microsoft4/audit-results/flutter-tests.log:127:Error: The Dart compiler exited unexpectedly.
/home/runner/work/Microsoft4/Microsoft4/audit-results/android-release.log:21:FAILURE: Build failed with an exception.
/home/runner/work/Microsoft4/Microsoft4/audit-results/android-release.log:35:BUILD FAILED in 1m 20s

## Android Evidence



## Source Information

SOURCE_ZIP=HOPE-MARKETPLACE-3.8.0-V6-REPAIRED.zip

Flutter root: /home/runner/work/Microsoft4/Microsoft4/source/HOPE-3_8_0-build-ready

Backend root: /home/runner/work/Microsoft4/Microsoft4/source/HOPE-3_8_0-build-ready/backend

## Evidence Inventory

BACKEND_ROOT.txt
FINAL-AUDIT-REPORT.md
FLUTTER_ROOT.txt
SUMMARY.txt
android-config.log
android-config.status
android-debug.log
android-debug.status
android-release.log
android-release.status
apk-files.log
apk-sha256.log
backend-cases/check.log
backend-cases/check.status
backend-cases/check_all.log
backend-cases/check_all.status
backend-cases/security_audit.log
backend-cases/security_audit.status
backend-cases/test.log
backend-cases/test.status
backend-cases/test_analytics.log
backend-cases/test_analytics.status
backend-cases/test_backup.log
backend-cases/test_backup.status
backend-cases/test_contract.log
backend-cases/test_contract.status
backend-cases/test_e2e.log
backend-cases/test_e2e.status
backend-cases/test_failure-injection.log
backend-cases/test_failure-injection.status
backend-cases/test_fast.log
backend-cases/test_fast.status
backend-cases/test_load_smoke.log
backend-cases/test_load_smoke.status
backend-cases/test_notifications.log
backend-cases/test_notifications.status
backend-cases/test_offline.log
backend-cases/test_offline.status
backend-cases/test_payment-e2e.log
backend-cases/test_payment-e2e.status
backend-cases/test_perf.log
backend-cases/test_perf.status
backend-cases/test_postgres.log
backend-cases/test_postgres.status
backend-cases/test_product.log
backend-cases/test_product.status
backend-cases/test_production-env.log
backend-cases/test_production-env.status
backend-cases/test_provider.log
backend-cases/test_provider.status
backend-cases/test_release-evidence.log
backend-cases/test_release-evidence.status
backend-cases/test_s3.log
backend-cases/test_s3.status
backend-cases/test_staging-contract.log
backend-cases/test_staging-contract.status
backend-cases/test_wave10.log
backend-cases/test_wave10.status
backend-discovery.status
backend-install.log
backend-install.status
backend-root.status
backend-script-list.log
backend-scripts.json
backend-security.log
backend-security.status
backend-tests-summary.txt
backend-tests.status
ci-cd.log
ci-cd.status
flutter-analyze.log
flutter-analyze.status
flutter-dependencies.log
flutter-dependencies.status
flutter-doctor.log
flutter-format.log
flutter-format.status
flutter-root.status
flutter-tests.log
flutter-tests.status
flutter-version.log
java-version.log
localization-ux.log
localization-ux.status
node-version.log
npm-version.log
project-structure.log
project-structure.status
pubspec-lock.status
runtime.log
runtime.status
security-static.log
security-static.status
source.log
source.status
zip-integrity.log

## Interpretation

PASS = test/check executed successfully.

FAIL = test/check executed and found a problem.

BLOCKED = execution could not be meaningfully completed because a prerequisite was unavailable.

REVIEW_REQUIRED = evidence collected; manual security review remains required.

NOT_RUN = no result was produced.

## IMPORTANT

A FAIL result does NOT stop this audit.

The audit is intentionally evidence-first: all subsequent checks continue whenever the GitHub runner remains operational.
