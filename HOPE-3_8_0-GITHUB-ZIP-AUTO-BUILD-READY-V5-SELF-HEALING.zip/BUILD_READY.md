# HOPE build-ready package

This package contains the repaired Flutter source and CI-safe Android signing logic.

Key fixes in this package:
- `trust_panel.dart` imports the generated `HopeCopy` localization facade.
- CI must pass an explicit `BUILD_PROFILE` (`pilot` for test artifacts, `production` for signed production releases); there is no CI/environment fallback.
- The lockfile verifier can run correctly when this project is extracted from a ZIP inside an outer Git repository (`CI_ZIP_BUILD=true`).
- Production builds remain fail-closed and still require an injected production keystore.

For a ZIP-only GitHub repository, the outer GitHub Actions workflow should extract the ZIP, detect `pubspec.yaml`, set `BUILD_PROFILE=pilot`, provide a real HTTPS `API_BASE_URL`, then run the project checks and `tools/build_apk_release.sh`.
