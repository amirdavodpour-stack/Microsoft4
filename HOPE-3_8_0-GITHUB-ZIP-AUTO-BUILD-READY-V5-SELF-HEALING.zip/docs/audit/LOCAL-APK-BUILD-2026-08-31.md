# HOPE 3.8.0 — Local Build & Fix Report — 2026-08-31

## Changes made
- Migrated `lib/features/transactions/trust_panel.dart` away from deprecated/manual `tx()` bilingual strings to generated localization keys exposed through `HopeCopy`.
- Added the trust/resolution UI strings to both Persian and English ARB catalogs.
- Updated the generated localization bridge/classes for the new keys.
- Hardened `backend/tests/trust-mobile-contract.test.mjs` so the contract validates localized keys instead of brittle raw English UI text.

## Validation completed in this sandbox
- `tools/check_localization_wave9.sh`: PASS (305 ARB keys, parity OK, manual `tx()` eliminated).
- `tools/android-release-contract.sh`: PASS.
- `tools/check_ux_wave8.sh`: PASS.
- Backend JavaScript syntax checks: PASS.
- Shell syntax checks: PASS.
- SBOM generation + contract: PASS (41 locked npm components).
- Offline `npm audit --offline --audit-level=high`: PASS (0 vulnerabilities reported by the available local audit data).
- Backend offline test suite: started successfully and exercised the integrated contract/E2E tests; the sandbox command exceeded its 120s execution limit after reaching test #173 without reporting a test failure.

## APK gate
The repository requires Flutter 3.47.0 and Android SDK/NDK tooling for `flutter analyze`, `flutter test`, and `flutter build apk --release`.
This sandbox does not contain Flutter, Dart, Android SDK, adb, or sdkmanager, and outbound package-download DNS is unavailable.
Therefore no APK was falsely claimed as built or certified here.

## Signing
- Production release is intentionally fail-closed and requires an injected production keystore.
- The repository supports a `pilot` release profile using the Android debug signing path for non-production test artifacts.

## Plugin/tooling assessment
- GitHub integration was checked for a possible remote CI route, but the connected account exposes no repositories, so no remote GitHub Actions build could be launched from this project.
- Browser automation is not a substitute for a native Android build toolchain in this repository.
