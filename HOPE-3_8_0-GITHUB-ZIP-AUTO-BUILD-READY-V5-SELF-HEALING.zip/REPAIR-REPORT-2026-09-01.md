# HOPE 3.8.0+11 — Repair / DevSecOps Review Report — 2026-09-01

## 1. Executive summary

A source-level repair and DevSecOps hardening pass was applied to the HOPE 3.8.0+11 repository. The changes preserve production fail-closed behavior, keep the pilot signing path explicitly non-production, remove a CI-dependent signing fallback, enforce production password-reset webhook delivery, tighten OpenAPI coverage, and add regression evidence for key bugs.

The available local environment does not contain Flutter/Android SDK, Docker, or PostgreSQL. Node is 22.16.0 while the project requires Node >=24 <25. Therefore external runtime gates are explicitly reported as BLOCKED/UNPROVEN rather than PASS.

## 2. Findings and repairs

### Critical

**C1 — Release signing profile ambiguity**
- File: `android/app/build.gradle.kts`, `tools/build_apk_release.sh`
- Cause: release profile could fall back to `CI=true` and choose pilot.
- Risk: build intent was implicit and production behavior could diverge between environments.
- Repair: `BUILD_PROFILE` is now mandatory and must be exactly `pilot` or `production`; no CI fallback remains. Production still requires the release keystore variables.
- Regression: `backend/tests/repair-regression.test.mjs`, `backend/tests/production-hardening.test.mjs`.

**C2 — Production password-reset delivery could be configured as console mode**
- Files: `backend/scripts/validate-production-env.sh`, `backend/src/config.js`, `backend/.env.koyeb.neon.r2.example`, `backend/DEPLOY-KOYEB-NEON-R2.md`
- Repair: production requires `RESET_TOKEN_DELIVERY_MODE=webhook` and HTTPS `RESET_TOKEN_DELIVERY_URL`. Console delivery remains development/test only.
- Regression: production environment contract tests and synthetic production-environment validation.

### High

**H1 — Application duplicate detection mismatch between PostgreSQL and file mode**
- File: `backend/src/routes/application_routes.js`
- Repair: file-mode lookup now considers the same active lifecycle states as PostgreSQL: PENDING, SHORTLISTED, FORWARDED, INTERVIEW, OFFERED, ACCEPTED.
- Regression: active-application lifecycle contract test.

**H2 — OpenAPI path parameters were missing for multiple `{id}`/`{applicationId}`/`{jobId}` routes**
- File: `backend/openapi/openapi.yaml`
- Repair: all templated paths now declare required path parameters; high-risk operations also contain security, request schema and responses.
- Regression: OpenAPI path-parameter contract test; YAML parse PASS. Official Swagger Parser is wired into CI and will run there.

**H3 — Multipart storage boundary regression**
- File: `backend/src/http.js`
- Repair already present and verified: extracted bytes are written to the final file, temp multipart body is deleted, and error cleanup removes both temp and extracted files.
- New runtime regression sends an in-memory PDF multipart body and verifies exact bytes and temp cleanup.

**H4 — Repository/payment/outbox correctness contracts**
- Files: `backend/src/repository/core.js`, `backend/src/repository/mappers.js`, `backend/src/repository/outbox.js`
- Repair verified: offer helpers exist, fee fields are mapped, and outbox terminal-failure query selects event type/payload needed for recovery.

### Medium

**M1 — Documentation/build-ready text contained an obsolete CI fallback claim**
- File: `BUILD_READY.md`
- Repair: documentation now states that `BUILD_PROFILE` must be explicit.

**M2 — Repository hygiene**
- Removed `apply_repairs.py` from the source tree because it used a fixed `/mnt/data/hope_repair` path.
- Removed runtime `backend/data/hope.json`; only `backend/data/.gitkeep` remains in the final package.
- Dependency cache `backend/node_modules` is excluded from the final source package.

## 3. Files changed

Key modified files include:
- `android/app/build.gradle.kts`
- `.github/workflows/main.yml`
- `.github/workflows/production-release.yml`
- `.github/workflows/staging-certification.yml`
- `.github/workflows/device-integration.yml`
- `.github/workflows/dr-restore.yml`
- `backend/.env.example`
- `backend/.env.koyeb.neon.r2.example`
- `backend/DEPLOY-KOYEB-NEON-R2.md`
- `backend/openapi/openapi.yaml`
- `backend/package.json`
- `backend/src/routes/application_routes.js`
- `backend/scripts/validate-production-env.sh`
- `backend/tests/repair-regression.test.mjs`
- `backend/tests/production-hardening.test.mjs`
- `backend/tests/openapi-surface-contract.test.mjs`
- `BUILD_READY.md`
- `README.md`
- `RELEASE-VALIDATION.md`

Also added/updated CI validation support for official OpenAPI parsing via `@apidevtools/swagger-parser@12.1.0` in CI.

## 4. Tests actually PASSed

### Local static checks
- `node --check` across backend JS/MJS source, staging, tools and tests — PASS.
- `bash -n` across project shell scripts — PASS.
- JSON/ARB parsing — PASS.
- OpenAPI YAML parse — PASS (61 paths).
- OpenAPI path-parameter consistency contract — PASS.

### Local backend suites
- `npm run check` — PASS.
- `npm run test:fast` — PASS.
- `npm run test:contract` — PASS.
- `npm run test:backup` — PASS.
- `npm run test:provider` — PASS.
- `npm run test:failure-injection` — PASS.
- `npm run test:product` — PASS.
- `npm run test:payment-e2e` — PASS.
- `npm run test:notifications` — PASS.
- `npm run test:analytics` — PASS.
- `npm run test:wave10` — PASS.
- `npm run test:perf` — PASS.
- `npm run test:load:smoke` — PASS.
- `npm run sbom` — PASS; 41 locked npm components reported.
- `npm audit --audit-level=high --offline` — PASS; 0 vulnerabilities reported by the available offline cache.
- `npm run check:all` — PASS overall; PostgreSQL integration test was skipped because PostgreSQL was unavailable (see Blocked section).
- `npm run test:offline` — PASS; 320 passed, 1 skipped, 0 failed.
- `npm run test:postgres` — SKIPPED/BLOCKED because PostgreSQL is not configured.
- Synthetic production environment validation using non-secret ephemeral placeholder values — PASS.
- Repair/OpenAPI regression set — PASS; 19/19.
- Multipart runtime regression — PASS; exact PDF bytes stored and temp input removed.
- Pilot/production signing separation contract — PASS.

## 5. BLOCKED / UNPROVEN

- Flutter 3.47.0: SDK not installed locally. `flutter pub get`, `flutter gen-l10n`, `flutter analyze`, `flutter test`, `flutter build apk --debug`, and `flutter build apk --release` could not be executed here.
- `pubspec.lock`: not generated locally because Flutter is unavailable. It was not fabricated.
- Android emulator/device integration: BLOCKED without Android SDK/emulator.
- Docker: CLI unavailable; Docker build/compose/staging certification not executed.
- PostgreSQL: client/server unavailable; migration and database integration runtime not executed.
- Real S3 lifecycle: UNPROVEN without staging credentials/service.
- Real PSP webhook flow: UNPROVEN without staging credentials/provider.
- Real push/email delivery: UNPROVEN without staging providers.
- Official Swagger Parser validation: configured in CI but BLOCKED locally because the package is not installed and registry access is unavailable.
- Clean `npm ci` with required Node 24: BLOCKED locally because installed Node is 22.16.0 and offline npm cache is incomplete (`xtend-4.0.2.tgz` not cached). GitHub workflows explicitly use Node 24.

## 6. Remaining risks

1. Runtime Flutter/Android validation and real APK build must pass in GitHub Actions or another real Android runner.
2. Real PostgreSQL/S3/PSP/notification staging certification is still required.
3. `node tools/90plus-score.mjs` remains intentionally below the 90 threshold because it records missing runtime evidence. Current minimum score is 78; no score inflation was applied.
4. Production signing remains intentionally blocked until production secrets/keystore and staging certification exist.

## 7. Final status

- Backend: PASS for available static/offline regression evidence; external runtime UNPROVEN.
- Flutter: BLOCKED locally.
- Android: BLOCKED locally.
- Docker: BLOCKED locally.
- PostgreSQL: BLOCKED locally.
- Staging: BLOCKED/UNPROVEN locally.
- Production readiness: NOT CERTIFIED.

Application version remains **3.8.0+11** and Android `versionCode=11`.
