#!/usr/bin/env bash
set -u -o pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"

LOG_FILE="${1:-}"

log() { printf '[SELF-HEAL] %s\n' "$*"; }
run_soft() { "$@" >/tmp/hope-self-heal.out 2>&1; local rc=$?; cat /tmp/hope-self-heal.out; return $rc; }

log "Starting targeted preflight/repair pass."

# 1. Repair executable bits and generated Flutter state before any retry.
if [[ -f android/gradlew ]]; then
  chmod +x android/gradlew || true
fi

# 2. Keep the certified Gradle wrapper and checksum synchronized.
if [[ -f android/gradle/wrapper/gradle-wrapper.properties ]]; then
  python3 - <<'PY'
from pathlib import Path
p = Path('android/gradle/wrapper/gradle-wrapper.properties')
s = p.read_text(encoding='utf-8')
version = '8.14.3'
checksum = 'bd71102213493060956ec229d946beee57158dbd89d0e62b91bca0fa2c5f3531'
lines = []
seen_url = False
seen_sum = False
for line in s.splitlines():
    if line.startswith('distributionUrl='):
        line = f'distributionUrl=https\\://services.gradle.org/distributions/gradle-{version}-bin.zip'
        seen_url = True
    elif line.startswith('distributionSha256Sum='):
        line = f'distributionSha256Sum={checksum}'
        seen_sum = True
    lines.append(line)
if not seen_url:
    lines.append(f'distributionUrl=https\\://services.gradle.org/distributions/gradle-{version}-bin.zip')
if not seen_sum:
    lines.append(f'distributionSha256Sum={checksum}')
p.write_text('\n'.join(lines) + '\n', encoding='utf-8')
PY
fi

# 3. Regenerate deterministic Flutter artifacts.
if command -v flutter >/dev/null 2>&1 && [[ -f pubspec.yaml ]]; then
  run_soft flutter pub get || true
  run_soft flutter gen-l10n || true
fi

# 4. Apply safe Dart automatic fixes. These do not rewrite business logic.
if command -v dart >/dev/null 2>&1; then
  run_soft dart fix --apply || true
  find lib test integration_test -type f -name '*.dart' -print0 2>/dev/null \
    | xargs -0 -r dart format >/tmp/hope-dart-format.out 2>&1 || true
  cat /tmp/hope-dart-format.out 2>/dev/null || true
fi

# 5. Known historical syntax regression guard. Only changes the exact broken
#    call signatures that previously blocked HOPE 3.8.0 compilation.
python3 - <<'PY'
from pathlib import Path

p = Path('lib/features/transactions/transaction_page.dart')
if p.exists():
    s = p.read_text(encoding='utf-8')
    old = """    final message = apiErrorMessage(e,\n        fallback: HopeCopy.of(context).copy_operation_failed_eb38c4c,\n      );"""
    new = """      final message = apiErrorMessage(\n        e,\n        fallback: HopeCopy.of(context).copy_operation_failed_eb38c4c,\n      );"""
    s = s.replace(old, new)
    p.write_text(s, encoding='utf-8')

p = Path('lib/features/transactions/wallet_page.dart')
if p.exists():
    s = p.read_text(encoding='utf-8')
    # Normalize the exact bottom-sheet structure to the parser-safe form.
    start = s.find('  void _showAction(BuildContext context, String action) {')
    if start >= 0:
        end = s.find('\n  }\n}', start)
        if end >= 0:
            block = '''  void _showAction(BuildContext context, String action) {\n    showModalBottomSheet<void>(\n      context: context,\n      showDragHandle: true,\n      builder: (sheetContext) {\n        return SafeArea(\n          child: Padding(\n            padding: const EdgeInsets.fromLTRB(22, 6, 22, 28),\n            child: Column(\n              mainAxisSize: MainAxisSize.min,\n              crossAxisAlignment: CrossAxisAlignment.stretch,\n              children: [\n                Text(\n                  action,\n                  style: Theme.of(context).textTheme.headlineSmall,\n                ),\n                const SizedBox(height: 8),\n                Text(\n                  'این بخش به سرویس پرداخت متصل است و پیش از تأیید، مبلغ، کارمزد و مبلغ نهایی را شفاف نمایش می‌دهد.',\n                  style: Theme.of(context).textTheme.bodyMedium,\n                ),\n                const SizedBox(height: 18),\n                FilledButton(\n                  onPressed: () => Navigator.pop(sheetContext),\n                  child: const Text('متوجه شدم'),\n                ),\n              ],\n            ),\n          ),\n        );\n      },\n    );\n  }'''
            s = s[:start] + block + s[end+4:]
    p.write_text(s, encoding='utf-8')

p = Path('lib/core/telemetry/telemetry_service.dart')
if p.exists():
    s = p.read_text(encoding='utf-8')
    s = s.replace(r"RegExp(r'\\b[+]?") , r"RegExp(r'\b[+]?")
    p.write_text(s, encoding='utf-8')
PY

# 6. Re-run the analyzer after repairs and leave a report for the caller.
if command -v flutter >/dev/null 2>&1; then
  set +e
  flutter analyze > /tmp/hope-analyze.log 2>&1
  rc=$?
  set -e
  cat /tmp/hope-analyze.log
  if [[ "$rc" -ne 0 ]]; then
    log "Analyzer still reports blocking issues after automatic fixes (exit $rc)."
  else
    log "Analyzer PASS."
  fi
fi

log "Targeted repair pass completed."
exit 0
