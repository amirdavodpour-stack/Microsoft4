#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
cd "$ROOT"

archive="${ARCHIVE_INPUT:-}"
if [[ -n "$archive" ]]; then
  archive="${archive#./}"
  test -f "$archive" || { echo "Archive not found: $archive" >&2; exit 1; }
else
  mapfile -t zips < <(find . -maxdepth 1 -type f -iname '*.zip' -printf '%T@ %p\n' | sort -nr | cut -d' ' -f2-)
  if [[ ${#zips[@]} -eq 0 ]]; then
    echo 'No ZIP archive found in repository root.' >&2
    exit 1
  fi
  archive="${zips[0]#./}"
fi

echo "Using archive: $archive"
python3 - "$archive" "$TMP/extracted" <<'PY'
import sys, zipfile
from pathlib import Path
archive = Path(sys.argv[1])
out = Path(sys.argv[2])
out.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(archive) as z:
    for info in z.infolist():
        name = info.filename.replace('\\', '/')
        p = Path(name)
        if p.is_absolute() or '..' in p.parts:
            raise SystemExit(f'Unsafe ZIP path rejected: {name}')
    z.extractall(out)
PY

project_root=""
while IFS= read -r pub; do
  d="$(dirname "$pub")"
  if [[ -f "$d/android/gradlew" && -d "$d/lib" ]]; then
    project_root="$d"
    break
  fi
done < <(find "$TMP/extracted" -type f -name pubspec.yaml -print | sort)

if [[ -z "$project_root" ]]; then
  echo 'Could not locate a Flutter project root inside the ZIP.' >&2
  find "$TMP/extracted" -maxdepth 3 -type f | head -100 >&2
  exit 1
fi

echo "Detected project root: $project_root"

# Preserve Git metadata and this bootstrap process, replace repository payload.
shopt -s dotglob nullglob
for entry in "$ROOT"/* "$ROOT"/.[!.]* "$ROOT"/..?*; do
  [[ "$entry" == "$ROOT/.git" ]] && continue
  [[ "$entry" == "$ROOT/.github/workflows/hope-bootstrap.yml" ]] && continue
  rm -rf "$entry"
done

cp -a "$project_root"/. "$ROOT/"
mkdir -p "$ROOT/.github/workflows"
# Keep the bootstrap workflow permanently available for future ZIP re-bootstrap.


rm -f -- "$archive"
echo 'ZIP extraction/bootstrap completed.'
