import 'dart:async';
import 'dart:io';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../network/api_client.dart';

class PendingUpload {
  PendingUpload(
      {required this.jobId, required this.path, required this.filePath});
  final String jobId;
  final String path;
  final String filePath;
}

/// MVP upload queue with bounded retry/backoff. The queue is intentionally
/// in-memory; a durable local queue can replace this implementation later.
class UploadQueue {
  UploadQueue(this.api, {this.maxAttempts = 3});
  final ApiClient api;
  final int maxAttempts;
  static const _storageKey = 'hope.upload_queue.v2';
  final List<PendingUpload> _queue = [];
  bool _running = false;
  bool _loaded = false;

  Future<void> _ensureLoaded() async {
    if (_loaded) return;
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_storageKey) ?? const <String>[];
    for (final item in raw) {
      try {
        final map = jsonDecode(item);
        if (map is Map && map['jobId'] is String && map['path'] is String && map['filePath'] is String) {
          _queue.add(PendingUpload(jobId: map['jobId'] as String, path: map['path'] as String, filePath: map['filePath'] as String));
        }
      } catch (_) {}
    }
    _loaded = true;
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_storageKey, _queue.map((e) => jsonEncode({'jobId': e.jobId, 'path': e.path, 'filePath': e.filePath})).toList());
  }

  int get pendingCount => _queue.length;

  /// Uploads [file] to [path] immediately, retrying with backoff up to
  /// [maxAttempts] times, and returns the decoded response on success.
  /// Use this when the caller needs the response synchronously (e.g. to
  /// read back a storage key) instead of firing-and-forgetting via
  /// [enqueue]. Throws the last error if every attempt fails.
  Future<dynamic> uploadNowWithRetry(String path, File file) async {
    Object? lastError;
    for (var attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        return await api.uploadFile(path, file);
      } catch (e) {
        lastError = e;
        // Deterministic 4xx (bad file type, validation error, etc.) will
        // never succeed on retry. Real backend errors carry a semantic
        // `code` (e.g. FILE_TOO_LARGE), never "HTTP_<status>", so this must
        // check the actual HTTP status on the exception, not try to parse
        // one out of `code`.
        if (e is ApiException && e.status != null && e.status! >= 400 && e.status! < 500) break;
        if (attempt < maxAttempts) {
          await Future<void>.delayed(Duration(milliseconds: 500 * attempt));
        }
      }
    }
    throw lastError!;
  }

  Future<void> enqueue(PendingUpload item) async {
    await _ensureLoaded();
    _queue.add(item);
    await _persist();
    await drain();
  }

  Future<void> drain() async {
    await _ensureLoaded();
    if (_running) return;
    _running = true;
    try {
      while (_queue.isNotEmpty) {
        final item = _queue.first;
        final file = File(item.filePath);
        if (!await file.exists()) {
          _queue.removeAt(0);
          await _persist();
          continue;
        }

        var sent = false;
        try {
          await uploadNowWithRetry(item.path, file);
          sent = true;
        } catch (_) {
          // Preserve the failed item for a later explicit drain/retry.
        }

        if (sent) {
          _queue.removeAt(0);
          await _persist();
        } else {
          break;
        }
      }
    } finally {
      _running = false;
    }
  }
}
