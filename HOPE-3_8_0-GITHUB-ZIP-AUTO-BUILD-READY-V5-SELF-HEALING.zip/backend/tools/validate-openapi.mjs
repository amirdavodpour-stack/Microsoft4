import SwaggerParser from '@apidevtools/swagger-parser';

const file = new URL('../openapi/openapi.yaml', import.meta.url);
await SwaggerParser.validate(file.pathname);
console.log('OpenAPI validation PASS');
