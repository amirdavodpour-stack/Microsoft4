import crypto from 'node:crypto';
import http from 'node:http';
import { URL } from 'node:url';
import { config, HOPE_VERSION } from './config.js';
import { db, initDatabase, seedBaseData, databaseHealth, withTransaction } from './db.js';
import * as repo from './repository.js';
import { hashPassword, verifyPassword, randomToken, sha256, signAccessToken, DUMMY_PASSWORD_HASH } from './security.js';
import { HttpError, sendJson, sendError, setCors, readBody, readRawBody, readMultipartSingleFile } from './http.js';
import { requestId, recordRequest, rateLimitAuth, rateLimitGeneral, metricsSnapshot, logEvent } from './observability.js';
import { traceContext, makeTraceparent } from './tracing.js';
import { processPaymentCreateHoldNow, processPaymentReleaseNow, processPaymentRefundNow } from './outbox_worker.js';
import { calculatePaymentBreakdown, fundingJournal, releaseJournal, payoutJournal, refundJournal } from './financial.js';
import { notifyUser, NOTIFICATION_TYPES } from './notifications.js';
import { recordAnalyticsEvent, recordCrash, localProductFunnelSummary } from './analytics.js';
import { getProductFunnelSummary } from './repository.js';
import { buildCandidateProfile, scoreRecommendation } from './recommendation.js';
import { JOB_TYPES, JOB_KINDS, JOB_VISIBILITY, JOB_SCHEDULES, BUDGET_TYPES, requireFields, textField, moneyField, dateOnlyField, enumField, requireAdmin, readIdempotencyKey } from './policies/validation.js';
import { createSessionService } from './services/session.js';
import { sanitizeTelemetryProperties, anonymizedEmail, deletionCredential, buildDataExport } from './privacy.js';
import { storage } from './storage.js';
import { createAuthRoutes } from './routes/auth_routes.js';
import { createProviderRoutes } from './routes/provider_routes.js';
import { createPaymentRoutes } from './routes/payment_routes.js';
import { createNotificationRoutes } from './routes/notification_routes.js';
import { createAnalyticsRoutes } from './routes/analytics_routes.js';
import { createStorageRoutes } from './routes/storage_routes.js';
import { createAdminRoutes } from './routes/admin_routes.js';
import { createAccountRoutes } from './routes/account_routes.js';
import { createJobRoutes } from './routes/job_routes.js';
import { createOfferRoutes } from './routes/offer_routes.js';
import { createApplicationRoutes } from './routes/application_routes.js';
import { createTrustRoutes } from './routes/trust_routes.js';
import { createAppViewHelpers } from './application/view_helpers.js';

await initDatabase();
seedBaseData();

const now = () => new Date().toISOString();

const sessionService = createSessionService({ config, db, repo, logEvent, now });
const { getUserById, getUserByEmail, authUser, issueSession, deliverPasswordReset } = sessionService;

const notificationRoutes = createNotificationRoutes({
  authUser,
  db,
  repo,
  readBody,
  sendJson,
  HttpError,
  requireFields,
  enumField,
  textField,
  now,
});
const { analyticsRoutes, analyticsAdminRoutes } = createAnalyticsRoutes({
  authUser, requireAdmin, readBody, sendJson, HttpError, sanitizeTelemetryProperties,
  recordAnalyticsEvent, recordCrash, logEvent, repo, getProductFunnelSummary,
  localProductFunnelSummary, db,
});

async function notifyApplicationCandidate(applicationId, type, title, body) {
  const application = process.env.DATABASE_URL ? await repo.getJobApplicationById(applicationId) : db.collection.jobApplications.find(x=>x.id===applicationId);
  if (!application) return;
  await getJob(application.jobId);
  await notifyUser({userId:application.candidateId,type,title,body,data:{jobId:application.jobId,applicationId},dedupeKey:`application:${applicationId}:${type}`,channels:['IN_APP','PUSH','EMAIL']});
}

const storageRoutes = createStorageRoutes({
  authUser, storage,  config, readBody, readMultipartSingleFile, requireFields,
  sendJson, HttpError, db, repo, now, logEvent,
});

const findUser = (id) => db.collection.users.find((u) => u.id === id);
async function getJob(id) { return process.env.DATABASE_URL ? repo.findJobById(id) : db.collection.jobs.find((j) => j.id === id); }

const adminRoutes = createAdminRoutes({
  authUser, requireAdmin, readBody, sendJson, HttpError, enumField, repo, db, config, now,
  createAudit: (...args) => createAudit(...args), findUser, getJob: (...args) => getJob(...args),
  notifyApplicationCandidate: (...args) => notifyApplicationCandidate(...args), URL,
  processPaymentRefundNow, processPaymentReleaseNow, refundJournal, releaseJournal, payoutJournal,
});

const accountRoutes = createAccountRoutes({
  authUser, readBody, sendJson, HttpError, hashPassword, db, repo, now, findUser, anonymizedEmail, deletionCredential, buildDataExport,
});


const {
  getProvider, categoryBy, publicUser, authUserView, categoryView, buildOfferCountMap,
  offerCountFor, jobView, paymentView, relatedJob, enforceJobState, createAudit,
} = createAppViewHelpers({ db, repo, config, getUserById, now, HttpError, env: process.env });

const authRoutes = createAuthRoutes({
  authUser, authUserView, getUserByEmail, issueSession, deliverPasswordReset, findUser,
  readBody, sendJson, HttpError, requireFields, db, repo, config, now, hashPassword,
  verifyPassword, randomToken, sha256, signAccessToken, withTransaction, createAudit, DUMMY_PASSWORD_HASH, logEvent,
});
const providerRoutes = createProviderRoutes({ authUser, getProvider, publicUser, db, repo, sendJson, HttpError, now, readBody, textField, enumField, createAudit, notifyUser });
const paymentRoutes = createPaymentRoutes({
  authUser, readBody, readRawBody, sendJson, HttpError, config, db, repo, getJob, enforceJobState,
  readIdempotencyKey, requireFields, enumField, paymentView, relatedJob, withTransaction, createAudit, calculatePaymentBreakdown,
  fundingJournal, releaseJournal, payoutJournal, refundJournal, processPaymentCreateHoldNow,
  processPaymentReleaseNow, processPaymentRefundNow, notifyUser, NOTIFICATION_TYPES, logEvent, now, crypto,
});

const jobRoutes = createJobRoutes({ getJob, authUser, db, repo, readBody, sendJson, HttpError, requireFields, textField, moneyField, enumField, JOB_TYPES, JOB_KINDS, JOB_VISIBILITY, JOB_SCHEDULES, BUDGET_TYPES, dateOnlyField, categoryBy, jobView, paymentView, buildOfferCountMap, relatedJob, enforceJobState, createAudit, now, findUser, publicUser, notifyApplicationCandidate, NOTIFICATION_TYPES });
const offerRoutes = createOfferRoutes({ authUser, readBody, sendJson, HttpError, requireFields, textField, moneyField, repo, db, getJob, enforceJobState, createAudit, now, jobView, withTransaction });
const applicationRoutes = createApplicationRoutes({ authUser, readBody, sendJson, HttpError, requireFields, textField, repo, db, getJob, createAudit, now, notifyUser, NOTIFICATION_TYPES });
const trustRoutes = createTrustRoutes({ authUser, getJob, db, repo, readBody, sendJson, HttpError, textField, enumField, now, createAudit, notifyUser });

export async function handle(req, res) {
  const startedAt = process.hrtime.bigint();
  const rid = requestId(req);
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const trace = traceContext(req);
  res.setHeader('X-Request-Id', rid);
  res.setHeader('traceparent', makeTraceparent(trace));
  // Staging-only instance identity lets the local integration gate prove that
  // the gateway actually reaches both replicas without exposing topology in
  // normal production deployments.
  if (process.env.STAGING_INSTANCE_ID) res.setHeader('X-Instance-ID', process.env.STAGING_INSTANCE_ID);
  setCors(res, req);
  const originalEnd = res.end.bind(res);
  let recorded = false;
  const finishRecord = (statusCode) => {
    if (recorded) return;
    recorded = true;
    const durationMs = Number(process.hrtime.bigint() - startedAt) / 1e6;
    recordRequest(statusCode, durationMs, `${req.method} ${url.pathname}`);
  };
  res.end = ((chunk, encoding, callback) => {
    finishRecord(res.statusCode || 200);
    return originalEnd(chunk, encoding, callback);
  });
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  if (url.pathname === '/metrics') {
    if (config.metricsToken && req.headers['x-metrics-token'] !== config.metricsToken) {
      const metricsError = new HttpError(401, 'UNAUTHORIZED', 'Authentication required');
      return sendError(res, metricsError);
    }
    const body = JSON.stringify(metricsSnapshot());
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    return res.end(body);
  }
  if (url.pathname.startsWith('/api/v1/auth/') && !(await rateLimitAuth(req, config.authRateLimitMax, config.rateLimitWindowMs))) {
    const body = JSON.stringify({ error: { code: 'RATE_LIMITED', message: 'Too many authentication requests' } });
    res.writeHead(429, { 'Content-Type': 'application/json; charset=utf-8', 'Retry-After': String(Math.ceil(config.rateLimitWindowMs / 1000)), 'Cache-Control': 'no-store' });
    return res.end(body);
  }
  if (!url.pathname.startsWith('/health') && !url.pathname.startsWith('/live') && !url.pathname.startsWith('/metrics') && !(await rateLimitGeneral(req, config.generalRateLimitMax, config.generalRateLimitWindowMs))) {
    res.writeHead(429, { 'Content-Type': 'application/json; charset=utf-8', 'Retry-After': String(Math.ceil(config.generalRateLimitWindowMs / 1000)), 'Cache-Control': 'no-store' });
    return res.end(JSON.stringify({ error: { code: 'RATE_LIMITED', message: 'Too many requests' } }));
  }
  const parts = url.pathname.replace(/^\/api\/v1\/?/, '').split('/').filter(Boolean);
  try {
    if (url.pathname === '/live' || url.pathname === '/api/v1/live') {
      return sendJson(res, 200, { alive: true, service: 'hope-api', version: process.env.HOPE_VERSION || HOPE_VERSION, time: now() });
    }
    if (url.pathname === '/health' || url.pathname === '/api/v1/health') {
      const database = await databaseHealth();
      const healthy = database.status === 'ok';
      return sendJson(res, healthy ? 200 : 503, { status: healthy ? 'ok' : 'degraded', service: 'hope-api', version: process.env.HOPE_VERSION || HOPE_VERSION, database, time: now() });
    }
    if (url.pathname === '/ready' || url.pathname === '/api/v1/ready') {
      const database = await databaseHealth();
      const ready = database.status === 'ok';
      return sendJson(res, ready ? 200 : 503, { ready, service: 'hope-api', database, time: now() });
    }
    if (parts[0] === 'auth') return await authRoutes(req, res, parts);
    if (parts[0] === 'account') return await accountRoutes(req, res, parts.slice(1));
    if (parts[0] === 'providers') return await providerRoutes(req, res, parts);
    if (parts[0] === 'jobs' && parts[1] === 'recommended') return await recommendedJobs(req, res);
    if (parts[0] === 'jobs') {
      if (parts[2] && ['reviews','dispute','rework','cancel'].includes(parts[2])) {
        const jobForTrust = await getJob(parts[1]);
        if (!jobForTrust) throw new HttpError(404,'JOB_NOT_FOUND','Job not found');
        return await trustRoutes(req,res,parts,jobForTrust);
      }
      return await jobRoutes(req, res, parts);
    }
    if (parts[0] === 'offers') return await offerRoutes(req, res, parts);
    if (parts[0] === 'applications') return await applicationRoutes(req, res, parts);
    if (parts[0] === 'admin') return await adminRoutes(req, res, parts);
    if (parts[0] === 'payments') return await paymentRoutes(req, res, parts);
    if (parts[0] === 'storage') return await storageRoutes(req, res, parts);
    if (parts[0] === 'categories') return await categoryRoutes(req, res, parts);
    if (parts[0] === 'analytics' && parts[1] === 'admin') return await analyticsAdminRoutes(req,res,parts.slice(2));
    if (parts[0] === 'analytics') return await analyticsRoutes(req,res,parts.slice(1));
    if (parts[0] === 'notifications') return await notificationRoutes(req, res, parts);
    throw new HttpError(404, 'NOT_FOUND', 'Route not found');
  } catch (error) {
    const status = error?.status || 500;
    const durationMs = Number(process.hrtime.bigint() - startedAt) / 1e6;
    logEvent({ level: status >= 500 ? 'error' : 'warn', requestId: rid, traceId: trace.traceId, method: req.method, path: url.pathname, status, durationMs: Number(durationMs.toFixed(2)), code: error?.code || 'INTERNAL_ERROR', message: error?.message || 'Internal server error' });
    sendError(res, error);
  } finally {
    try { await db.flush(); } catch (persistError) { console.error('[db] persistence flush failed:', persistError); }
  }
}

async function categoryRoutes(req, res) {
  if (req.method !== 'GET') throw new HttpError(405, 'METHOD_NOT_ALLOWED', 'Method not allowed');
  const toView = (c) => ({ id:c.id, slug:c.slug, name:c.name, nameEn:c.nameEn||'', description:c.description||'', parentId:c.parentId||null, sortOrder:Number(c.sortOrder||0), isActive:c.isActive!==false });
  if (process.env.DATABASE_URL) return sendJson(res, 200, (await repo.listCategories()).map(toView));
  return sendJson(res, 200, db.collection.categories.filter((c)=>c.isActive!==false).sort((a,b)=>(a.sortOrder||0)-(b.sortOrder||0)).map(toView));
}

const CITY_COORDS = {
  'تهران':[35.6892,51.3890], 'مشهد':[36.2605,59.6168], 'اصفهان':[32.6546,51.6680],
  'شیراز':[29.5918,52.5837], 'تبریز':[38.0962,46.2738], 'کرج':[35.8400,50.9391],
  'قم':[34.6416,50.8746], 'اهواز':[31.3183,48.6706], 'رشت':[37.2808,49.5832],
  'کرمانشاه':[34.3142,47.0650], 'ارومیه':[37.5527,45.0761], 'یزد':[31.8974,54.3569],
  'کرمان':[30.2839,57.0834], 'ساری':[36.5659,53.0586], 'بندرعباس':[27.1832,56.2666],
  'همدان':[34.7988,48.5150],
};
function haversineKm(lat1, lon1, lat2, lon2) {
  const rad = Math.PI / 180;
  const a1 = lat1 * rad, a2 = lat2 * rad;
  const dLat = (lat2 - lat1) * rad, dLon = (lon2 - lon1) * rad;
  const h = Math.sin(dLat/2)**2 + Math.cos(a1) * Math.cos(a2) * Math.sin(dLon/2)**2;
  return 6371 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(Math.max(0, 1-h)));
}
function parseCoordinate(value, field) {
  const n = Number(value);
  if (!Number.isFinite(n)) throw new HttpError(400, 'INVALID_COORDINATE', `${field} must be numeric`);
  return n;
}
function recommendationScore(job, context) {
  const profile = context.profile || buildCandidateProfile([]);
  return scoreRecommendation(job, profile, { ...context, cityCoords: CITY_COORDS, distanceFn: haversineKm });
}

async function recommendedJobs(req, res) {
  const user = req.headers.authorization ? await authUser(req) : null;
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const requestedCity = url.searchParams.get('city') ? textField(url.searchParams.get('city'), 'city', {min:1,max:120}) : null;
  const city = requestedCity || null;
  const kind = url.searchParams.get('kind') ? enumField(url.searchParams.get('kind'), JOB_KINDS, 'kind') : null;
  const categoryId = url.searchParams.get('categoryId') ? String(url.searchParams.get('categoryId')).trim() : null;
  const hasLat = url.searchParams.has('lat'), hasLng = url.searchParams.has('lng');
  if (hasLat !== hasLng) throw new HttpError(400, 'INVALID_COORDINATE', 'lat and lng must be provided together');
  let lat = null, lng = null;
  if (hasLat) {
    lat = parseCoordinate(url.searchParams.get('lat'), 'lat');
    lng = parseCoordinate(url.searchParams.get('lng'), 'lng');
    if (lat < -90 || lat > 90 || lng < -180 || lng > 180) throw new HttpError(400, 'INVALID_COORDINATE', 'coordinates are out of range');
  }
  let applications = [];
  if (user) applications = process.env.DATABASE_URL ? await repo.listCandidateApplications(user.id) : db.collection.jobApplications.filter(a => a.candidateId === user.id).map(a => { const j=db.collection.jobs.find(x=>x.id===a.jobId); return {...a,jobCity:j?.city||null,jobKind:j?.kind||'JOB',categoryId:j?.categoryId||null,monthlySalary:j?.monthlySalary||null}; });
  const profile = buildCandidateProfile(applications);
  const rows = process.env.DATABASE_URL
    ? await repo.listJobViews({status:'PUBLISHED', kind, categoryId, city:null, visibility:null, search:null})
    : db.collection.jobs.filter(j => j.status === 'PUBLISHED' && (!kind || (j.kind || (j.jobType==='FIXED'?'MISSION':'JOB')) === kind) && (!categoryId || String(j.categoryId) === categoryId || categoryBy(categoryId)?.id === j.categoryId)).map(job => ({job,category:categoryBy(job.categoryId)?.name,owner:null,provider:null,offerCount:0}));
  const scored = [];
  const seenCategories = new Set();
  for (const {job,category,owner,provider,offerCount} of rows) {
    const view = await jobView(job, user?.id, new Map([[job.id, offerCount]]), {owner,provider,category});
    const match = recommendationScore(view, {lat,lng,city,kind,categoryId,profile,seenCategories});
    scored.push({...view, recommendationScore:match.score, distanceKm:match.distanceKm, recommendationReasons:match.reasons, recommendationComponents:match.componentScores});
  }
  scored.sort((a,b) => (b.recommendationScore-a.recommendationScore) || String(b.updatedAt||'').localeCompare(String(a.updatedAt||'')));
  if (user) await recordAnalyticsEvent({eventName:'recommendation_served',platform:'UNKNOWN',properties:{count:Math.min(50,scored.length), personalized:applications.length>0}}, user.id, `recommendation_served:${user.id}:${new Date().toISOString().slice(0,13)}`).catch(()=>{});
  return sendJson(res, 200, scored.slice(0, 50));
}

export function createServer() { return http.createServer(handle); }
