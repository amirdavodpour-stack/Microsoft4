export function createAdminRoutes({ authUser, requireAdmin, readBody, sendJson, HttpError, enumField, repo, db, config, now, createAudit, findUser, getJob, notifyApplicationCandidate, URL, processPaymentRefundNow, processPaymentReleaseNow, refundJournal, releaseJournal, payoutJournal }) {
  return async function adminRoutes(req,res,parts){
    const me=requireAdmin(await authUser(req));
    if(req.method==='GET' && parts[0]==='admin' && parts[1]==='finance' && parts.length===3 && parts[2]==='summary'){
      if(process.env.DATABASE_URL){ return sendJson(res,200,await repo.getAdminFinancialSummary()); }
      const payments=db.collection.payments, refunds=db.collection.refunds, settlements=db.collection.settlements, ledger=db.collection.ledgerEntries;
      return sendJson(res,200,{payments:payments.length,pending:payments.filter(p=>['HOLD_PENDING','REFUND_PENDING','RELEASE_PENDING'].includes(p.status)).length,held:payments.filter(p=>p.status==='HELD').length,released:payments.filter(p=>p.status==='RELEASED').length,refunded:payments.filter(p=>p.status==='REFUNDED').length,platformFees:payments.reduce((s,p)=>s+Number(p.platformFee||0),0),employerCharges:payments.reduce((s,p)=>s+Number(p.employerCharge||p.amount||0),0),providerPayouts:payments.reduce((s,p)=>s+Number(p.providerPayout||p.amount||0),0),refunds:refunds.length,settlements:settlements.length,ledgerEntries:ledger.length,currency:config.paymentCurrency});
    }
    if(req.method==='GET' && parts[0]==='admin' && parts[1]==='summary'){
      if(process.env.DATABASE_URL){ return sendJson(res,200,await repo.getAdminSummary()); }
      const users=db.collection.users, jobs=db.collection.jobs, apps=db.collection.jobApplications;
      return sendJson(res,200,{users:users.length,admins:users.filter(u=>u.role==='ADMIN').length,active_users:users.filter(u=>u.role==='USER'&&u.status==='ACTIVE').length,suspended_users:users.filter(u=>u.status!=='ACTIVE').length,opportunities:jobs.length,published_opportunities:jobs.filter(j=>j.status==='PUBLISHED').length,draft_opportunities:jobs.filter(j=>j.status==='DRAFT').length,missions:jobs.filter(j=>j.kind==='MISSION').length,jobs:jobs.filter(j=>j.kind==='JOB').length,applications:apps.length,pending_applications:apps.filter(a=>['PENDING','SHORTLISTED'].includes(a.status)).length,audit_events:db.collection.audit.length});
    }
    if(req.method==='GET' && parts[0]==='admin' && parts[1]==='users'){
      const u=process.env.DATABASE_URL?await repo.listAdminUsers():db.collection.users.slice().sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));
      return sendJson(res,200,u.map(x=>({id:x.id,email:x.email,displayName:x.displayName,role:x.role,status:x.status,createdAt:x.createdAt})));
    }
    if(req.method==='POST' && parts[0]==='admin' && parts[1]==='users' && parts[3]==='status'){
      const id=parts[2]; const body=await readBody(req); const status=enumField(body?.status,new Set(['ACTIVE','SUSPENDED']),'status'); if(id===me.id && status==='SUSPENDED') throw new HttpError(400,'SELF_SUSPEND_FORBIDDEN','An admin cannot suspend their own account');
      const updated=process.env.DATABASE_URL?await repo.setUserStatus(id,status):(()=>{const u=db.collection.users.find(x=>x.id===id); if(!u)return null; u.status=status; u.sessionVersion=Number(u.sessionVersion||0)+1; db.touch('users'); return u;})(); if(!updated) throw new HttpError(404,'USER_NOT_FOUND','User not found'); if(!process.env.DATABASE_URL) await db.save(); await createAudit('ADMIN_USER_STATUS',me.id,'user',id,{status}); return sendJson(res,200,{id,status:updated.status});
    }
    if(req.method==='GET' && parts[0]==='admin' && parts[1]==='provider-verifications'){
      const status=req.url?new URL(req.url,'http://localhost').searchParams.get('status'):null;
      const verifications=process.env.DATABASE_URL?await repo.listProviderVerifications(status):db.collection.providerVerifications.filter(v=>!status||v.status===status).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt))).map(v=>({...v,providerName:findUser(v.providerUserId)?.displayName||null}));
      return sendJson(res,200,verifications);
    }
    if(req.method==='POST' && parts[0]==='admin' && parts[1]==='provider-verifications' && parts[3]==='status'){
      const id=parts[2]; const body=await readBody(req); const status=enumField(body?.status,new Set(['APPROVED','REJECTED']),'status'); const note=String(body?.reviewNote||'').trim().slice(0,2000);
      const updated=process.env.DATABASE_URL?await repo.updateProviderVerification(id,status,me.id,note):(()=>{const v=db.collection.providerVerifications.find(x=>x.id===id); if(!v)return null; v.status=status; v.reviewedBy=me.id; v.reviewNote=note; v.reviewedAt=now(); v.updatedAt=now(); const p=db.collection.providers.find(x=>x.userId===v.providerUserId); if(p){p.verificationStatus=status==='APPROVED'?'VERIFIED':'REJECTED';p.updatedAt=now();db.touch('providers');} db.touch('providerVerifications'); return v;})();
      if(!updated) throw new HttpError(404,'VERIFICATION_NOT_FOUND','Provider verification request not found'); if(!process.env.DATABASE_URL) await db.save(); await createAudit('PROVIDER_VERIFICATION_STATUS',me.id,'provider_verification',id,{status}); return sendJson(res,200,updated);
    }
    if(req.method==='GET' && parts[0]==='admin' && parts[1]==='disputes'){
      const status=req.url?new URL(req.url,'http://localhost').searchParams.get('status'):null;
      const disputes=process.env.DATABASE_URL?await repo.listJobDisputes(status):db.collection.jobDisputes.filter(d=>!status||d.status===status).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));
      return sendJson(res,200,disputes);
    }
    if(req.method==='POST' && parts[0]==='admin' && parts[1]==='disputes' && parts[3]==='resolve'){
      const id=parts[2]; const body=await readBody(req); const resolutionType=enumField(body?.resolutionType,new Set(['NO_ACTION','REFUND_OWNER','RELEASE_PROVIDER','SPLIT']),'resolutionType'); const note=String(body?.resolutionNote||'').trim().slice(0,2000);
      if(resolutionType==='SPLIT') throw new HttpError(422,'PARTIAL_REFUND_UNSUPPORTED','Split settlement is not enabled until partial-refund accounting is implemented');
      let result;
      if(process.env.DATABASE_URL){
        try { result=await repo.resolveDisputeFinancialAtomic({disputeId:id,adminId:me.id,resolutionType,resolutionNote:note,nowIso:now()}); }
        catch(e){
          if(e?.code==='DISPUTE_NOT_FOUND') throw new HttpError(404,'DISPUTE_NOT_FOUND','Dispute not found');
          if(e?.code==='DISPUTE_NOT_ACTIONABLE') throw new HttpError(409,'DISPUTE_NOT_ACTIONABLE','This dispute is not ready for financial resolution');
          if(e?.code==='PAYMENT_REQUIRED') throw new HttpError(409,'PAYMENT_REQUIRED','A payment is required for this financial resolution');
          if(e?.code==='INVALID_PAYMENT_STATE') throw new HttpError(409,'INVALID_PAYMENT_STATE','The payment is not in a held state');
          throw e;
        }
        if(result?.financialAction?.type==='REFUND_OWNER') { try{ await processPaymentRefundNow(); } catch(e){ console.warn('[admin] refund worker trigger failed:',e.message); } }
        if(result?.financialAction?.type==='RELEASE_PROVIDER') { try{ await processPaymentReleaseNow(); } catch(e){ console.warn('[admin] release worker trigger failed:',e.message); } }
        const refreshed=await repo.listJobDisputes();
        const updated=refreshed.find(d=>d.id===id) || result.dispute;
        await createAudit('JOB_DISPUTE_RESOLVE',me.id,'job_dispute',id,{status:updated.status,resolutionType});
        return sendJson(res,200,{...updated,financialAction:result.financialAction});
      }
      const dispute=db.collection.jobDisputes.find(x=>x.id===id);
      if(!dispute) throw new HttpError(404,'DISPUTE_NOT_FOUND','Dispute not found');
      if(!['OPEN','REVIEWING'].includes(dispute.status)) throw new HttpError(409,'DISPUTE_NOT_ACTIONABLE','This dispute is not ready for financial resolution');
      if(resolutionType==='NO_ACTION') { dispute.status='RESOLVED'; dispute.resolutionType=resolutionType; dispute.resolutionNote=note; dispute.resolvedBy=me.id; dispute.resolvedAt=now(); dispute.updatedAt=now(); db.touch('jobDisputes'); await db.save(); await createAudit('JOB_DISPUTE_RESOLVE',me.id,'job_dispute',id,{status:dispute.status,resolutionType}); return sendJson(res,200,dispute); }
      const job=db.collection.jobs.find(x=>x.id===dispute.jobId); const payment=job&&db.collection.payments.find(x=>x.jobId===job.id); if(!payment) throw new HttpError(409,'PAYMENT_REQUIRED','A payment is required for this financial resolution');
      if(payment.status!=='HELD') throw new HttpError(409,'INVALID_PAYMENT_STATE','The payment is not in a held state');
      const b={baseAmount:payment.baseAmount||payment.amount,employerFee:payment.employerFee||0,workerFee:payment.workerFee||0,platformFee:payment.platformFee||0,employerCharge:payment.employerCharge||payment.amount,providerPayout:payment.providerPayout||payment.amount,currency:payment.currency||config.paymentCurrency};
      if(resolutionType==='REFUND_OWNER') { payment.status='REFUNDED'; payment.updatedAt=now(); const refund={id:db.id(),paymentId:payment.id,amount:payment.amount,status:'REFUNDED',providerRef:`LOCAL-DISPUTE-REF-${id}`,idempotencyKey:`dispute-refund:${id}`,createdAt:now(),updatedAt:now()}; db.insert('refunds',refund); job.status=job.providerId?'ASSIGNED':'PUBLISHED'; job.updatedAt=now(); const jid=db.id(); for(const e of refundJournal(b)) db.insert('ledgerEntries',{id:db.id(),journalId:jid,referenceType:'PAYMENT_REFUND',referenceId:payment.id,account:e.account,debit:e.debit,credit:e.credit,currency:b.currency,createdAt:now()}); dispute.status='RESOLVED';
      } else {
        payment.status='RELEASED'; payment.updatedAt=now(); job.status='SETTLED'; job.updatedAt=now(); for(const journal of [releaseJournal(b),payoutJournal(b)]) { const jid=db.id(); for(const e of journal) db.insert('ledgerEntries',{id:db.id(),journalId:jid,referenceType:'PAYMENT_DISPUTE_RELEASE',referenceId:payment.id,account:e.account,debit:e.debit,credit:e.credit,currency:b.currency,createdAt:now()}); } db.insert('settlements',{id:db.id(),paymentId:payment.id,providerRef:payment.providerRef,amount:b.providerPayout,currency:b.currency,status:'RELEASED',createdAt:now(),updatedAt:now()}); dispute.status='RESOLVED';
      }
      dispute.resolutionType=resolutionType; dispute.resolutionNote=note; dispute.resolvedBy=me.id; dispute.resolvedAt=now(); dispute.updatedAt=now(); db.touch('payments','jobs','refunds','ledgerEntries','settlements','jobDisputes'); await db.save(); await createAudit('JOB_DISPUTE_RESOLVE',me.id,'job_dispute',id,{status:dispute.status,resolutionType}); return sendJson(res,200,{...dispute,financialAction:{type:resolutionType,alreadyDone:true}});
    }
    if(req.method==='GET' && parts[0]==='admin' && parts[1]==='trust-reports'){
      const status=req.url?new URL(req.url,'http://localhost').searchParams.get('status'):null;
      const reports=process.env.DATABASE_URL?await repo.listTrustReports(status):db.collection.trustReports.filter(r=>!status||r.status===status).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)));
      return sendJson(res,200,reports.map(r=>({...r,reporterName:r.reporterName||findUser(r.reporterId)?.displayName||null})));
    }
    if(req.method==='POST' && parts[0]==='admin' && parts[1]==='trust-reports' && parts[3]==='status'){
      const id=parts[2]; const body=await readBody(req); const status=enumField(body?.status,new Set(['OPEN','REVIEWING','RESOLVED','DISMISSED']),'status');
      const updated=process.env.DATABASE_URL?await repo.updateTrustReportStatus(id,status):(()=>{const r=db.collection.trustReports.find(x=>x.id===id); if(!r)return null; r.status=status; r.updatedAt=now(); db.touch('trustReports'); return r;})();
      if(!updated) throw new HttpError(404,'REPORT_NOT_FOUND','Trust report not found'); if(!process.env.DATABASE_URL) await db.save();
      await createAudit('TRUST_REPORT_STATUS',me.id,'trust_report',id,{status}); return sendJson(res,200,{id,status:updated.status});
    }
    if(req.method==='GET' && parts[0]==='admin' && parts[1]==='audit'){
      const logs=process.env.DATABASE_URL?await repo.listAdminAudit():db.collection.audit.slice().sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt))).map(a=>({...a,actorName:findUser(a.actorId)?.displayName||null}));
      return sendJson(res,200,logs);
    }
    if(req.method==='GET' && parts[0]==='admin' && parts[1]==='jobs'){ const jobs=process.env.DATABASE_URL?await repo.listAdminJobs():db.collection.jobs.slice().sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt))); return sendJson(res,200,jobs); }
    if(req.method==='POST' && parts[0]==='admin' && parts[1]==='jobs' && parts[3]==='moderate'){
      const id=parts[2]; const body=await readBody(req); const status=enumField(body?.status,new Set(['DRAFT','PUBLISHED','CANCELLED']),'status');
      const job=await getJob(id); if(!job) throw new HttpError(404,'JOB_NOT_FOUND','Job not found');
      try { const updated=process.env.DATABASE_URL?await repo.moderateJob(id,status):(()=>{const j=db.collection.jobs.find(x=>x.id===id); if(!j)return null; if(['COMPLETED','ASSIGNED','FUNDED','IN_PROGRESS','DELIVERED','UNDER_REVIEW'].includes(j.status)){const e=new Error('JOB_LOCKED'); e.code='JOB_LOCKED'; throw e;} j.status=status; j.updatedAt=now(); if(status==='PUBLISHED'&&!j.publishedAt) j.publishedAt=now(); db.touch('jobs'); return j;})(); if(!updated) throw new HttpError(404,'JOB_NOT_FOUND','Job not found'); if(!process.env.DATABASE_URL) await db.save(); await createAudit('ADMIN_JOB_MODERATE',me.id,'job',id,{status}); return sendJson(res,200,updated); } catch(e){ if(e?.code==='JOB_LOCKED') throw new HttpError(409,'JOB_LOCKED','This opportunity is already in a protected lifecycle state'); throw e; }
    }
    if(req.method==='DELETE' && parts[0]==='admin' && parts[1]==='jobs' && parts[2]){
      const id=parts[2]; const job=await getJob(id); if(!job) throw new HttpError(404,'JOB_NOT_FOUND','Job not found');
      if(!['DRAFT','PUBLISHED'].includes(job.status)) throw new HttpError(409,'JOB_NOT_DELETABLE','Only draft or published opportunities can be deleted by admins');
      if(process.env.DATABASE_URL) await repo.deleteJob(id);
      else { db.collection.jobs=db.collection.jobs.filter(j=>j.id!==id); db.collection.offers=db.collection.offers.filter(o=>o.jobId!==id); db.collection.jobApplications=db.collection.jobApplications.filter(a=>a.jobId!==id); db.collection.payments=db.collection.payments.filter(p=>p.jobId!==id); db.collection.evidence=db.collection.evidence.filter(e=>e.jobId!==id); db.touch('jobs','offers','jobApplications','payments','evidence'); await db.save(); }
      await createAudit('ADMIN_JOB_DELETE',me.id,'job',id); return sendJson(res,200,{deleted:true,id});
    }
    if(req.method==='GET' && parts[0]==='admin' && parts[1]==='applications'){ const apps=process.env.DATABASE_URL?await repo.listAdminApplications():db.collection.jobApplications.slice().sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt))).map(a=>{const j=db.collection.jobs.find(x=>x.id===a.jobId); const u=findUser(a.candidateId); return {...a,jobTitle:j?.title||'—',candidateName:u?.displayName||'—'};}); return sendJson(res,200,apps); }
    if(req.method==='POST' && parts[0]==='admin' && parts[1]==='applications' && parts[3]==='shortlist'){ const id=parts[2]; const changed=process.env.DATABASE_URL?await repo.transitionJobApplication(id,'PENDING','SHORTLISTED'):(()=>{const a=db.collection.jobApplications.find(x=>x.id===id&&x.status==='PENDING'); if(!a)return null; a.status='SHORTLISTED'; a.updatedAt=now(); db.touch('jobApplications'); return a;})(); if(!changed) throw new HttpError(409,'INVALID_APPLICATION_STATE','Application is not pending'); if(!process.env.DATABASE_URL) await db.save(); await notifyApplicationCandidate(id, 'APPLICATION_SHORTLISTED', 'درخواست شما وارد فهرست کوتاه شد', 'درخواست شما برای بررسی بیشتر انتخاب شده است.'); await createAudit('ADMIN_APPLICATION_SHORTLIST',me.id,'job_application',id); return sendJson(res,200,{id,status:changed.status}); }
    if(req.method==='POST' && parts[0]==='admin' && parts[1]==='applications' && parts[3]==='select'){ const id=parts[2]; const changed=process.env.DATABASE_URL?await repo.selectJobApplication(id):(()=>{const a=db.collection.jobApplications.find(x=>x.id===id&&['PENDING','SHORTLISTED'].includes(x.status)); if(!a)return null; a.status='FORWARDED'; a.updatedAt=now(); db.touch('jobApplications'); return a;})(); if(!changed) throw new HttpError(409,'INVALID_APPLICATION_STATE','Application cannot be forwarded'); if(!process.env.DATABASE_URL) await db.save(); await notifyApplicationCandidate(id, 'APPLICATION_FORWARDED', 'درخواست شما برای کارفرما ارسال شد', 'رزومه و اطلاعات حرفه‌ای شما برای بررسی کارفرما ارسال شده است.'); await createAudit('ADMIN_APPLICATION_FORWARD',me.id,'job_application',id); return sendJson(res,200,{id,status:changed.status}); }
    if(req.method==='POST' && parts[0]==='admin' && parts[1]==='applications' && parts[3]==='reject'){ const id=parts[2]; const changed=process.env.DATABASE_URL?await repo.transitionJobApplication(id,['PENDING','SHORTLISTED'],'REJECTED'):(()=>{const a=db.collection.jobApplications.find(x=>x.id===id&&['PENDING','SHORTLISTED'].includes(x.status)); if(!a)return null; a.status='REJECTED'; a.updatedAt=now(); db.touch('jobApplications'); return a;})(); if(!changed) throw new HttpError(409,'INVALID_APPLICATION_STATE','Application cannot be rejected from its current state'); if(!process.env.DATABASE_URL) await db.save(); await notifyApplicationCandidate(id, 'APPLICATION_REJECTED', 'درخواست شما پذیرفته نشد', 'درخواست شما برای این شغل در این مرحله ادامه پیدا نکرد.'); await createAudit('ADMIN_APPLICATION_REJECT',me.id,'job_application',id); return sendJson(res,200,{id,status:changed.status}); }
    throw new HttpError(404,'NOT_FOUND','Admin route not found');
  };
}
