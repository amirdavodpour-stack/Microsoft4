# Applying the final repair

1. Replace `.github/workflows/hope-full-audit.yml` with `hope-full-audit-final.yml` from this package.
2. Upload `HOPE-MARKETPLACE-3.8.0-V6-REPAIRED-FINAL.zip` to the repository, preserving the filename expected by the workflow, or replace the existing `HOPE-MARKETPLACE-3.8.0-V6-REPAIRED.zip` with the final repaired archive.
3. Run `HOPE Full Audit` manually once.
4. The workflow will also repair/format the extracted source and persist the repaired source ZIP automatically.

Do not put real production signing secrets or production environment values into the ZIP. Keep them in protected GitHub Actions secrets/environment configuration.
