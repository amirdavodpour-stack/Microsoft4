## Change Intent

- What changed and why?
- Which product/security/reliability requirement does it satisfy?

## Verification

- [ ] Unit/contract tests updated or existing coverage identified
- [ ] Security/privacy impact reviewed
- [ ] Threat model updated when trust boundaries or sensitive flows changed
- [ ] Migrations are backward-compatible or have an explicit rollout plan
- [ ] Observability added for new failure modes
- [ ] Release evidence requirements updated when applicable

## Operational Safety

- [ ] No secrets, credentials, tokens, or private keys added
- [ ] No production `continue-on-error` or weakened gate
- [ ] Rollback/recovery path is known
- [ ] Documentation/ADR updated when architectural behavior changes
