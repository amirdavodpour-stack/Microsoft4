import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from './config.js';
import { toDbRow, fromDbRow, tableColumns } from './db/serialization.js';
import { createSchema } from './db/schema.js';

const pg = config.databaseUrl ? await import('pg') : null;
const Pool = pg?.default?.Pool || pg?.Pool || null;
const collections = ['users','providers','refreshTokens','resetTokens','categories','jobs','offers','jobApplications','payments','ledgerEntries','settlements','refunds','paymentWebhooks','evidence','uploads','uploadIntents','audit','notifications','notificationPreferences','notificationDevices','notificationDeliveries','analyticsEvents','crashReports','trustReports','jobReviews','jobDisputes','jobReworkRequests','providerVerifications'];
const tableMap = {
  users: 'users', providers: 'providers', refreshTokens: 'refresh_tokens', resetTokens: 'reset_tokens',
  categories: 'categories', jobs: 'jobs', offers: 'offers', jobApplications: 'job_applications', payments: 'payments', evidence: 'evidence',
  uploads: 'uploads', uploadIntents: 'upload_intents', audit: 'audit_logs', ledgerEntries: 'ledger_entries', settlements: 'settlements', refunds: 'refunds', paymentWebhooks: 'payment_webhook_events',
  notifications: 'notifications', notificationPreferences: 'notification_preferences', notificationDevices: 'notification_devices', notificationDeliveries: 'notification_deliveries',
  analyticsEvents: 'analytics_events', crashReports: 'crash_reports', trustReports: 'trust_reports', jobReviews: 'job_reviews', jobDisputes: 'job_disputes', jobReworkRequests: 'job_rework_requests', providerVerifications: 'provider_verifications',
};
const empty = Object.fromEntries(collections.map((name) => [name, []]));
fs.mkdirSync(config.storageDir, { recursive: true });
const pool = config.databaseUrl ? new Pool({ connectionString: config.databaseUrl, max: Number(config.pgPoolMax || 10), idleTimeoutMillis: 30000, connectionTimeoutMillis: Math.min(Number(config.requestTimeoutMs || 15000), 5000), statement_timeout: Math.min(Number(config.requestTimeoutMs || 30000), 120000), lock_timeout: 5000, maxUses: 10000 }) : null;
let state = structuredClone(empty);
let initialized = false;
let flushChain = Promise.resolve();
let txDepth = 0;
let dirty = new Set();
let transactionChain = Promise.resolve();

import { legacyLoad } from './db/legacy.js';

async function loadAll(client) {
  const next = structuredClone(empty);
  for (const collection of collections) {
    const table = tableMap[collection];
    const { rows } = await client.query(`SELECT * FROM ${table} ORDER BY created_at NULLS FIRST, id`);
    next[collection] = rows.map((r) => fromDbRow(collection, r));
  }
  return next;
}

async function upsertCollection(client, collection) {
  const table = tableMap[collection];
  for (const row of state[collection]) {
    const values = toDbRow(collection, row);
    const cols = tableColumns[table];
    const placeholders = cols.map((_, i) => `$${i + 2}`);
    await client.query(
      `INSERT INTO ${table}(id,${cols.join(',')}) VALUES($1,${placeholders.join(',')}) ON CONFLICT(id) DO UPDATE SET ${cols.map((c) => `${c}=EXCLUDED.${c}`).join(',')}`,
      values
    );
  }
}

async function flushInTx(client, collectionsToWrite) {
  for (const collection of collectionsToWrite) await upsertCollection(client, collection);
  await client.query("INSERT INTO hope_meta(key,value) VALUES('schema_version','\"2-relational\"'::jsonb) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value,updated_at=NOW()");
}

async function persistCollections(collectionsToWrite) {
  if (!pool || collectionsToWrite.size === 0) return;
  const client = await pool.connect();
  try { await client.query('BEGIN'); await flushInTx(client, collectionsToWrite); await client.query('COMMIT'); }
  catch (e) { await client.query('ROLLBACK'); throw e; }
  finally { client.release(); }
}

export async function initDatabase() {
  if (initialized) return;
  if (!pool) { state = legacyLoad({ dataFile: config.dataFile, empty }); initialized = true; return; }
  const client = await pool.connect();
  try {
    await createSchema(client);
    const loadedAt = process.hrtime.bigint();
    const loaded = await loadAll(client);
    const bootstrapRows = Object.values(loaded).reduce((sum, items) => sum + items.length, 0);
    const bootstrapMs = Number(process.hrtime.bigint() - loadedAt) / 1e6;
    if (bootstrapRows > 50000 || bootstrapMs > 10000) {
      console.warn(`[db] postgres bootstrap loaded ${bootstrapRows} rows in ${bootstrapMs.toFixed(0)}ms; consider operationally reducing in-memory compatibility state`);
    }
    const hasData = Object.values(loaded).some((items) => items.length > 0);
    if (hasData) state = loaded;
    else {
      state = legacyLoad({ dataFile: config.dataFile, empty });
      const hasLegacy = Object.values(state).some((items) => items.length > 0);
      if (hasLegacy) { dirty = new Set(collections); await flushInTx(client, dirty); dirty.clear(); }
    }
    await ensureDefaultCategoriesSql(client);
    initialized = true;
    console.log('[db] PostgreSQL relational schema initialized; multi-writer safe repository mode active');
  } catch (e) { throw e; }
  finally { client.release(); }
}

async function persistLegacyFile() {
  if (pool || !config.dataFile) return;
  const dir = path.dirname(config.dataFile);
  await fs.promises.mkdir(dir, { recursive: true });
  const temp = `${config.dataFile}.${process.pid}.${crypto.randomUUID()}.tmp`;
  await fs.promises.writeFile(temp, JSON.stringify(state, null, 2), 'utf8');
  await fs.promises.rename(temp, config.dataFile);
}

function scheduleFlush() {
  const toFlush = new Set(dirty);
  dirty.clear();
  if (!toFlush.size) return;
  if (pool) flushChain = flushChain.then(() => persistCollections(toFlush));
  else flushChain = flushChain.then(() => persistLegacyFile());
}

function markDirty(collection) {
  dirty.add(collection);
  if (txDepth === 0) scheduleFlush();
}

export async function withTransaction(fn) {
  if (!pool) {
    const snapshot = structuredClone(state);
    const dirtyBefore = new Set(dirty);
    txDepth += 1;
    try {
      const result = await fn();
      txDepth -= 1;
      scheduleFlush();
      return result;
    } catch (e) {
      state = snapshot;
      dirty = dirtyBefore;
      txDepth -= 1;
      throw e;
    }
  }
  let resolveQueue;
  const previous = transactionChain;
  transactionChain = new Promise((resolve) => { resolveQueue = resolve; });
  await previous;
  const client = await pool.connect();
  txDepth += 1;
  try {
    await client.query('BEGIN');
    const result = await fn();
    const toFlush = new Set(dirty);
    await flushInTx(client, toFlush);
    await client.query('COMMIT');
    dirty.clear();
    return result;
  } catch (e) { await client.query('ROLLBACK'); throw e; }
  finally { txDepth -= 1; client.release(); resolveQueue(); }
}


export function getPool() { return pool; }
export async function withSqlTransaction(fn) {
  if (!pool) return fn(null);
  const client = await pool.connect();
  try { await client.query('BEGIN'); const result = await fn(client); await client.query('COMMIT'); return result; }
  catch (e) { await client.query('ROLLBACK'); throw e; }
  finally { client.release(); }
}

export async function databaseHealth() {
  if (!pool) return { mode:'file', status:'ok' };
  const started = process.hrtime.bigint();
  try {
    const r = await pool.query({ text: 'SELECT current_database() AS database', values: [], query_timeout: 2000 });
    const latencyMs = Number(process.hrtime.bigint() - started) / 1e6;
    return { mode:'postgres', status:'ok', database:r.rows[0].database, latencyMs:Number(latencyMs.toFixed(2)) };
  } catch (error) {
    const latencyMs = Number(process.hrtime.bigint() - started) / 1e6;
    return { mode:'postgres', status:'down', latencyMs:Number(latencyMs.toFixed(2)), errorCode:error?.code || 'DB_UNAVAILABLE' };
  }
}

export const db = {
  get collection() { return state; },
  touch(...collectionsToWrite) {
    for (const collection of collectionsToWrite.flat()) {
      if (!collections.includes(collection)) throw new Error(`Unknown collection: ${collection}`);
      dirty.add(collection);
    }
    if (txDepth === 0) scheduleFlush();
  },
  save() {
    if (txDepth > 0) return Promise.resolve();
    scheduleFlush();
    return flushChain;
  },
  async flush() { await flushChain; },
  async close() { await flushChain; if (pool) await pool.end(); },
  reset() { state = structuredClone(empty); dirty = new Set(collections); if (txDepth === 0) this.save(); return state; },
  id() { return crypto.randomUUID(); },
  insert(collection,row) { state[collection].push(row); markDirty(collection); return row; },
  update(collection,id,patch) { const item=state[collection].find((x)=>x.id===id); if(!item) return null; Object.assign(item,patch); markDirty(collection); return item; },
};

const CATEGORY_CATALOG = [
  {slug:'technology', name:'فناوری', nameEn:'Technology', description:'توسعه نرم‌افزار، داده، هوش مصنوعی و زیرساخت.', order:10},
  {slug:'software-development', name:'توسعه نرم‌افزار', nameEn:'Software Development', parent:'technology', order:11},
  {slug:'frontend', name:'توسعه فرانت‌اند', nameEn:'Frontend Development', parent:'software-development', order:12},
  {slug:'backend', name:'توسعه بک‌اند', nameEn:'Backend Development', parent:'software-development', order:13},
  {slug:'mobile', name:'توسعه موبایل', nameEn:'Mobile Development', parent:'software-development', order:14},
  {slug:'fullstack', name:'توسعه فول‌استک', nameEn:'Full-stack Development', parent:'software-development', order:15},
  {slug:'devops', name:'DevOps و زیرساخت', nameEn:'DevOps & Infrastructure', parent:'technology', order:16},
  {slug:'ai-data', name:'هوش مصنوعی و داده', nameEn:'AI & Data', parent:'technology', order:17},
  {slug:'design', name:'طراحی', nameEn:'Design', description:'طراحی محصول، تجربه کاربری و محتوای بصری.', order:20},
  {slug:'uiux', name:'UI/UX', nameEn:'UI/UX Design', parent:'design', order:21},
  {slug:'graphic', name:'طراحی گرافیک', nameEn:'Graphic Design', parent:'design', order:22},
  {slug:'motion', name:'موشن و ویدئو', nameEn:'Motion & Video', parent:'design', order:23},
  {slug:'content', name:'محتوا و ترجمه', nameEn:'Content & Translation', description:'نویسندگی، ویراستاری، تولید محتوا و ترجمه.', order:30},
  {slug:'writing', name:'نویسندگی', nameEn:'Writing', parent:'content', order:31},
  {slug:'translation', name:'ترجمه', nameEn:'Translation', parent:'content', order:32},
  {slug:'marketing', name:'بازاریابی', nameEn:'Marketing', description:'دیجیتال مارکتینگ، رشد، برند و شبکه‌های اجتماعی.', order:40},
  {slug:'sales', name:'فروش', nameEn:'Sales', order:50},
  {slug:'finance', name:'مالی و حسابداری', nameEn:'Finance & Accounting', order:60},
  {slug:'education', name:'آموزش', nameEn:'Education', order:70},
  {slug:'research', name:'پژوهش', nameEn:'Research', order:80},
  {slug:'services', name:'خدمات', nameEn:'Services', order:90},
  {slug:'healthcare', name:'پزشکی و سلامت', nameEn:'Healthcare', parent:'services', order:91},
  {slug:'transport', name:'حمل‌ونقل', nameEn:'Transport', parent:'services', order:92},
];

function upsertFileCategory(spec, bySlug, now) {
  let row = state.categories.find((c)=>c.slug===spec.slug);
  if (!row) {
    row = {id:db.id(), slug:spec.slug, name:spec.name, nameEn:spec.nameEn, description:spec.description||'', parentId:null, sortOrder:spec.order, isActive:true, createdAt:now};
    state.categories.push(row);
  } else {
    row.name = spec.name; row.nameEn = spec.nameEn; row.description = spec.description || row.description || ''; row.sortOrder = spec.order; row.isActive = row.isActive !== false;
  }
  bySlug.set(spec.slug,row);
  return row;
}

export function seedBaseData() {
  const now = new Date().toISOString();
  const bySlug = new Map();
  for (const c of state.categories) bySlug.set(c.slug,c);
  // Upgrade legacy flat categories in place.
  const legacyMap = {development:'software-development', writing:'writing', design:'design', research:'research', education:'education'};
  for (const c of state.categories) {
    c.nameEn ??= '';
    c.description ??= '';
    c.sortOrder ??= 0;
    c.isActive ??= true;
    if (c.parentId === undefined) c.parentId = null;
    if (legacyMap[c.slug] && c.slug !== legacyMap[c.slug]) c.slug = legacyMap[c.slug];
  }
  for (const spec of CATEGORY_CATALOG) upsertFileCategory(spec,bySlug,now);
  for (const spec of CATEGORY_CATALOG) {
    const row = bySlug.get(spec.slug);
    row.parentId = spec.parent ? bySlug.get(spec.parent)?.id || null : null;
  }
  db.touch('categories');
}

async function ensureDefaultCategoriesSql(client) {
  const now = new Date().toISOString();
  // Preserve existing IDs/slugs and upgrade legacy rows without destructive changes.
  for (const spec of CATEGORY_CATALOG) {
    await client.query(
      `INSERT INTO categories(id,slug,name,name_en,description,sort_order,is_active,created_at)\n       VALUES(gen_random_uuid(),$1,$2,$3,$4,$5,TRUE,$6)\n       ON CONFLICT(slug) DO UPDATE SET name=EXCLUDED.name,name_en=EXCLUDED.name_en,description=EXCLUDED.description,sort_order=EXCLUDED.sort_order,is_active=TRUE`,
      [spec.slug,spec.name,spec.nameEn,spec.description||'',spec.order,now]
    );
  }
  for (const spec of CATEGORY_CATALOG) {
    if (!spec.parent) continue;
    await client.query(`UPDATE categories child SET parent_id=parent.id FROM categories parent WHERE child.slug=$1 AND parent.slug=$2`, [spec.slug,spec.parent]);
  }
  await client.query(`UPDATE categories SET parent_id=NULL WHERE parent_id=id`);
}
