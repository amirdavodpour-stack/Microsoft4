import { createServer } from './app.js';
import { config } from './config.js';
import { db } from './db.js';
import { startOutboxWorker } from './outbox_worker.js';
import { metricsSnapshot, logEvent } from './observability.js';
import { dispatchOperationalAlerts } from './alerting.js';

const server = createServer();
server.requestTimeout = config.requestTimeoutMs;
server.headersTimeout = Math.min(config.headersTimeoutMs, config.requestTimeoutMs);
server.keepAliveTimeout = config.keepAliveTimeoutMs;
server.maxRequestsPerSocket = 1000;
server.on('error', (error) => {
  logEvent({ level:'error', action:'SERVER_ERROR', code:error?.code || 'SERVER_ERROR', message:error?.message || String(error) });
  process.exitCode = 1;
});
server.on('clientError', (error, socket) => {
  logEvent({ level:'warn', action:'CLIENT_ERROR', code:error?.code || 'CLIENT_ERROR', message:error?.message || String(error) });
  if (socket.writable) socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n');
});
const outboxWorker = startOutboxWorker();
const alertTimer = setInterval(() => { dispatchOperationalAlerts(metricsSnapshot()).catch((error) => console.error('[alerting] error:', error.message)); }, 30000);
alertTimer.unref();
server.listen(config.port, config.host, () => {
  logEvent({ level:'info', action:'SERVER_LISTENING', host:config.host, port:config.port, version:process.env.HOPE_VERSION });
});

let shuttingDown = false;
const shutdown = () => {
  if (shuttingDown) return;
  shuttingDown = true;
  const timer = setTimeout(() => process.exit(1), 10000);
  timer.unref();
  server.close(async () => {
    try { clearInterval(alertTimer); outboxWorker.stop(); await db.close(); process.exitCode = 0; }
    catch (error) { logEvent({ level:'error', action:'SHUTDOWN_ERROR', message:error?.message || String(error) }); process.exitCode = 1; }
    finally { process.exit(); }
  });
};

process.on('unhandledRejection', (reason) => {
  logEvent({ level:'error', action:'UNHANDLED_REJECTION', message: reason?.message || String(reason) });
  shutdown();
});
process.on('uncaughtException', (error) => {
  logEvent({ level:'error', action:'UNCAUGHT_EXCEPTION', message: error?.message || String(error) });
  shutdown();
});

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
