import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';

const root = path.resolve(new URL('..', import.meta.url).pathname, '..');
const apkPath = path.resolve(root, process.env.APK_PATH || 'build/app/outputs/flutter-apk/app-release.apk');
const outPath = path.resolve(root, process.env.RELEASE_MANIFEST_PATH || 'release-manifest.json');

function sha256(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}

function gitSha() {
  if (process.env.GITHUB_SHA) return process.env.GITHUB_SHA;
  try { return execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim(); }
  catch { return 'UNKNOWN'; }
}

function required(name, value) {
  if (!value) throw new Error(`requires ${name}`);
  return value;
}

const isProduction = process.env.BUILD_PROFILE === 'production';
if (!fs.existsSync(apkPath)) throw new Error(`APK not found: ${apkPath}`);

if (isProduction) {
  required('PASS staging certification', process.env.STAGING_CERTIFICATION_STATUS === 'PASS' ? 'PASS' : '');
  required('staging certification run id', process.env.STAGING_CERTIFICATION_RUN_ID);
  const stagingSha = required('staging certification SHA', process.env.STAGING_CERTIFICATION_SHA);
  if (stagingSha !== gitSha()) throw new Error('certification SHA must match the release SHA');
  const attempt = Number(required('a numeric staging certification attempt', process.env.STAGING_CERTIFICATION_ATTEMPT));
  if (!Number.isInteger(attempt) || attempt < 1) throw new Error('requires a numeric staging certification attempt');
}

const stat = fs.statSync(apkPath);
const manifest = {
  schemaVersion: 1,
  artifact: {
    name: path.basename(apkPath),
    path: path.relative(root, apkPath),
    bytes: stat.size,
    sha256: sha256(apkPath),
  },
  source: {
    gitSha: gitSha(),
    ref: process.env.GITHUB_REF || 'LOCAL',
    workflowRunId: process.env.GITHUB_RUN_ID || 'LOCAL',
    workflowAttempt: process.env.GITHUB_RUN_ATTEMPT ? Number(process.env.GITHUB_RUN_ATTEMPT) : null,
  },
  build: {
    profile: process.env.BUILD_PROFILE || 'unknown',
    node: process.version,
    flutter: process.env.FLUTTER_VERSION || 'unknown',
    java: process.env.JAVA_VERSION || '17',
    gradle: process.env.GRADLE_VERSION || '8.13',
    androidGradlePlugin: process.env.AGP_VERSION || '8.11.1',
    kotlin: process.env.KOTLIN_VERSION || '2.2.20',
  },
  stagingCertification: {
    status: process.env.STAGING_CERTIFICATION_STATUS || null,
    runId: process.env.STAGING_CERTIFICATION_RUN_ID || null,
    sha: process.env.STAGING_CERTIFICATION_SHA || null,
    attempt: process.env.STAGING_CERTIFICATION_ATTEMPT ? Number(process.env.STAGING_CERTIFICATION_ATTEMPT) : null,
  },
};

fs.mkdirSync(path.dirname(outPath), { recursive: true });
fs.writeFileSync(outPath, `${JSON.stringify(manifest, null, 2)}\n`);
console.log(outPath);
