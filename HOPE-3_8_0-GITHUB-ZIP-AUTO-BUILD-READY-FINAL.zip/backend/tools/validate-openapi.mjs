import { spawnSync } from 'node:child_process';
import path from 'node:path';

const script = path.join(process.cwd(), 'tools', 'validate-openapi-local.rb');
const target = path.join(process.cwd(), 'openapi', 'openapi.yaml');
const result = spawnSync('ruby', [script, target], { stdio: 'inherit' });
if (result.error) {
  console.error(`OpenAPI validator could not start: ${result.error.message}`);
  process.exit(1);
}
process.exit(result.status ?? 1);
