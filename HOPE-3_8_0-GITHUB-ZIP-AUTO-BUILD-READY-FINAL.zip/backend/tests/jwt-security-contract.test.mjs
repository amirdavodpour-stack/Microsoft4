import test from 'node:test';
import assert from 'node:assert/strict';
import { signAccessToken, verifyAccessToken } from '../src/security.js';

const secret = 'x'.repeat(48);
const nowPayload = { sub: '00000000-0000-0000-0000-000000000001', role: 'USER', sv: 0 };

test('JWT rejects algorithm confusion and malformed headers', () => {
  const token = signAccessToken(nowPayload, secret, 60);
  const [h, p, s] = token.split('.');
  const badHeader = Buffer.from(JSON.stringify({ alg: 'none', typ: 'JWT' })).toString('base64url');
  assert.throws(() => verifyAccessToken(`${badHeader}.${p}.${s}`, secret));
});

test('JWT rejects future-issued tokens and wrong audience', () => {
  const token = signAccessToken(nowPayload, secret, 60, { audience: 'hope-mobile' });
  assert.throws(() => verifyAccessToken(token, secret, { audience: 'other-client' }));
});
