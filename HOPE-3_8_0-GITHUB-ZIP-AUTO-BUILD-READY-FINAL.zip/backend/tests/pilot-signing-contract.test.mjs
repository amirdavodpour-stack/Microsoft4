import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');

test('pilot build is explicitly separated from production signing', () => {
  const workflow = read('.github/workflows/main.yml');
  const gradle = read('android/app/build.gradle.kts');
  assert.match(workflow, /BUILD_PROFILE:\s*pilot/);
  assert.match(workflow, /apksigner verify --verbose --print-certs/);
  assert.match(workflow, /EXPECTED_FP/);
  assert.match(workflow, /ACTUAL_FP/);
  assert.match(workflow, /Pilot certificate mismatch/);
  assert.match(gradle, /"pilot"/);
  assert.match(gradle, /signingConfigs\.getByName\("debug"\)/);
  assert.match(gradle, /Production builds require ANDROID_RELEASE_STORE_FILE/);
});
