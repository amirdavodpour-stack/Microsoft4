import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(new URL('..', import.meta.url).pathname, '..');

test('mobile app uses build-time API configuration and never ships the placeholder API host', () => {
  const main = fs.readFileSync(path.join(root, 'lib/main.dart'), 'utf8');
  const client = fs.readFileSync(path.join(root, 'lib/core/network/api_client.dart'), 'utf8');
  assert.match(main, /ApiClient\(store\)/);
  assert.doesNotMatch(main, /api\.hope\.example\.invalid/);
  assert.match(client, /String\.fromEnvironment\('API_BASE_URL'\)/);
});

test('Android manifest requests location permissions needed by the settings flow', () => {
  const manifest = fs.readFileSync(path.join(root, 'android/app/src/main/AndroidManifest.xml'), 'utf8');
  assert.match(manifest, /ACCESS_COARSE_LOCATION/);
  assert.match(manifest, /ACCESS_FINE_LOCATION/);
});


test('mobile crash telemetry redacts secrets and preserves uncaught platform errors', () => {
  const telemetry = fs.readFileSync(path.join(root, 'lib/core/telemetry/telemetry_service.dart'), 'utf8');
  const main = fs.readFileSync(path.join(root, 'lib/main.dart'), 'utf8');
  assert.match(telemetry, /_sensitiveKeys/);
  assert.match(telemetry, /bearer\\s/);
  assert.match(telemetry, /accesstoken/);
  assert.match(telemetry, /_safeText\(error\.toString\(\), 2000\)/);
  assert.match(main, /PlatformDispatcher\.instance\.onError/);
  assert.match(main, /return false;/);
});
