import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(new URL('../..', import.meta.url).pathname);
const text = fs.readFileSync(path.join(root, 'lib/features/transactions/trust_panel.dart'), 'utf8');

test('mobile trust panel exposes review, dispute and rework actions', () => {
  assert.match(text, /\/reviews/);
  assert.match(text, /\/dispute/);
  assert.match(text, /\/rework/);
  assert.match(text, /copy_trust_resolution_title/);
  assert.match(text, /copy_active_dispute/);
  assert.match(text, /copy_request_rework/);
});
