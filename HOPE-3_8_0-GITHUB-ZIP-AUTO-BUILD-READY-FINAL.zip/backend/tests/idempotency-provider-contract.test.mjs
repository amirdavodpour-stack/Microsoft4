import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const payment = fs.readFileSync(new URL('../src/payment_provider.js', import.meta.url), 'utf8');
const notification = fs.readFileSync(new URL('../src/notification_provider.js', import.meta.url), 'utf8');
test('provider boundaries require explicit idempotency keys', () => {
  assert.match(payment, /PAYMENT_PROVIDER_IDEMPOTENCY_KEY_REQUIRED/);
  assert.match(notification, /NOTIFICATION_PROVIDER_IDEMPOTENCY_KEY_REQUIRED/);
});
