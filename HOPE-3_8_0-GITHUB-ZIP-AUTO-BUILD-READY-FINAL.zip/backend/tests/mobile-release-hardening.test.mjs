import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const manifest = fs.readFileSync(new URL('../../android/app/src/main/AndroidManifest.xml', import.meta.url), 'utf8');
const staging = fs.readFileSync(new URL('../../.github/workflows/staging-certification.yml', import.meta.url), 'utf8');
const production = fs.readFileSync(new URL('../../.github/workflows/production-release.yml', import.meta.url), 'utf8');

test('Android declares the runtime notification permission for API 33+', () => {
  assert.match(manifest, /android\.permission\.POST_NOTIFICATIONS/);
});

test('staging and production capture Flutter coverage as release evidence', () => {
  assert.match(staging, /flutter test --coverage/);
  assert.match(production, /flutter test --coverage/);
  assert.match(production, /coverage\/lcov\.info/);
});
