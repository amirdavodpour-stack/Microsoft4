import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '../..');
const read = (rel) => fs.readFileSync(path.join(root, rel), 'utf8');

test('multipart parser returns the extracted file path and removes the temp body', () => {
  const src = read('backend/src/http.js');
  assert.match(src, /await fs\.promises\.writeFile\(filePath, content, \{ flag: 'wx' \}\)/);
  assert.match(src, /await fs\.promises\.unlink\(tempPath\);\s*return \{ key, filename: safeName, contentType, size: content\.length, path: filePath \}/s);
});

test('job application UI snapshots controllers before disposal', () => {
  const src = read('lib/features/marketplace/job_detail_page.dart');
  assert.match(src, /final submittedResume = resume\.text\.trim\(\);/);
  assert.match(src, /final submittedSkills = skills\.text\.trim\(\);/);
  assert.match(src, /resume\.dispose\(\);\s*skills\.dispose\(\);\s*\n\s*if \(ok != true\)/s);
  assert.match(src, /'resumeText': submittedResume/);
  assert.match(src, /'skills': submittedSkills/);
});

test('database job category values are canonical IDs', () => {
  const repo = read('backend/src/repository/core.js');
  const jobs = read('backend/src/routes/job_handlers.js');
  assert.match(repo, /export async function findCategoryByIdOrSlug/);
  assert.match(jobs, /categoryId: categoryExists\.id/);
});

test('pending offer repository helpers exist', () => {
  const src = read('backend/src/repository/core.js');
  assert.match(src, /export async function listOffersForJob/);
  assert.match(src, /export async function findPendingOffer/);
  assert.match(src, /status='PENDING'/);
});

test('application lookup blocks duplicate active lifecycle states in both storage modes', () => {
  const routes = read('backend/src/routes/application_routes.js');
  assert.match(routes, /\['PENDING','SHORTLISTED','FORWARDED','INTERVIEW','OFFERED','ACCEPTED'\]/);

  const core = read('backend/src/repository/core.js');
  assert.match(core, /status IN \('PENDING','SHORTLISTED','FORWARDED','INTERVIEW','OFFERED','ACCEPTED'\)/);
});

test('active application uniqueness covers the full active lifecycle', () => {
  const schema = read('backend/src/db/schema.js');
  assert.match(schema, /job_applications_active_uq/);
  for (const status of ['PENDING','SHORTLISTED','FORWARDED','INTERVIEW','OFFERED','ACCEPTED']) {
    assert.match(schema, new RegExp(`['"]${status}['"]`));
  }
  assert.match(schema, /DROP INDEX IF EXISTS job_applications_pending_uq/);
});

test('payment mapper preserves all financial fields and view aliases', () => {
  const mapper = read('backend/src/repository/mappers.js');
  const views = read('backend/src/repository/views.js');
  for (const field of ['baseAmount','employerFee','workerFee','platformFee','employerCharge','providerPayout','feePolicyVersion','currency']) {
    assert.match(mapper, new RegExp(field));
  }
  for (const col of ['payment_base_amount','payment_employer_fee','payment_worker_fee','payment_platform_fee','payment_employer_charge','payment_provider_payout','payment_fee_policy_version','payment_currency']) {
    assert.match(views, new RegExp(col));
  }
});

test('outbox terminal failure selects payload and event type before recovery', () => {
  const src = read('backend/src/repository/outbox.js');
  assert.match(src, /SELECT attempts, lease_token, event_type, payload FROM outbox_events WHERE id=\$1 FOR UPDATE/);
  assert.match(src, /Financial release failed; retry required\./);
  assert.match(src, /Financial refund failed; retry required\./);
});

test('release profile must always be explicit and production must not fall back from CI', () => {
  const gradle = read('android/app/build.gradle.kts');
  assert.match(gradle, /BUILD_PROFILE/);
  assert.match(gradle, /BUILD_PROFILE must be explicitly set to production or pilot/);
  assert.doesNotMatch(gradle, /System\.getenv\("CI"\)/);
  assert.match(gradle, /\"production\"/);
  assert.match(gradle, /\"pilot\"/);
});

test('OPTIONS handler initializes URL before response instrumentation uses it', () => {
  const src = read('backend/src/app.js');
  const handle = src.slice(src.indexOf('export async function handle'), src.indexOf('async function categoryRoutes')); 
  const urlIndex = handle.indexOf('const url = new URL');
  const finishIndex = handle.indexOf('const finishRecord');
  assert.ok(urlIndex >= 0 && finishIndex >= 0 && urlIndex < finishIndex);
  assert.equal((handle.match(/const url = new URL/g) || []).length, 1);
});

test('password reset route does not double-bump the session version', () => {
  const src = read('backend/src/routes/auth_routes.js');
  const segment = src.slice(src.indexOf("route === 'password-reset/confirm'"), src.indexOf("route === 'password-reset/request'"));
  assert.match(segment, /consumeResetTokenAndChangePassword/);
  assert.doesNotMatch(segment, /bumpUserSessionVersion\(candidate\.user\.id\)/);
});

test('staging provider simulator uses the generated cert paths and releaseRef', () => {
  const src = read('backend/staging/providers/provider-simulator.mjs');
  assert.match(src, /process\.env\.CERT_FILE \|\| '\/certs\/provider\.crt'/);
  assert.match(src, /process\.env\.KEY_FILE \|\| '\/certs\/provider\.key'/);
  assert.match(src, /status:'RELEASED', releaseRef:`sim-release-\$\{idem\}`/);
});

test('staging smoke scripts normalize wrapper payloads and use /live', () => {
  const smoke = read('tools/staging-smoke.sh');
  assert.match(smoke, /\/live/);
  assert.match(smoke, /root\.get\('data', root\)/);
  const product = read('tools/staging-product-smoke.mjs');
  assert.match(product, /function apiPath\(path\)/);
  assert.match(product, /value\.startsWith\('\/api\/v1\/'\)/);
});

test('production compose keeps notifications optional while validator enforces HTTPS when configured', () => {
  const compose = read('backend/docker-compose.yml');
  const validator = read('backend/scripts/validate-production-env.sh');
  assert.match(compose, /NOTIFICATION_PUSH_URL: \$\{NOTIFICATION_PUSH_URL:-\}/);
  assert.match(compose, /NOTIFICATION_EMAIL_URL: \$\{NOTIFICATION_EMAIL_URL:-\}/);
  assert.match(validator, /NOTIFICATION_PROVIDER_TOKEN must be set/);
});

test('integration smoke bootstraps the same providers as the real app', () => {
  const src = read('integration_test/app_smoke_test.dart');
  for (const needle of ['MultiProvider(', 'HopeSettingsController()', 'ThemeController(settings)', 'AuthController(api, store)', 'await auth.restoreSession()']) {
    assert.match(src, new RegExp(needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
  }
});

test('OpenAPI documents the repaired high-risk routes', () => {
  const spec = read('backend/openapi/openapi.yaml');
  for (const route of ['/account/export:','/account/delete:','/analytics/events:','/analytics/crashes:','/analytics/admin/crashes:','/providers/{id}/reputation:','/providers/me/verification:','/jobs/{id}/reviews:','/jobs/{id}/dispute:','/jobs/{id}/rework:','/jobs/{id}/cancel:','/jobs/{id}/candidates/{applicationId}/compare:','/admin/disputes:','/admin/provider-verifications:','/payments/financials/{jobId}:','/payments/refund/{jobId}:']) {
    assert.match(spec, new RegExp(route.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
  }
});

test('multipart parser stores exact file bytes and removes temp input', async () => {
  const { Readable } = await import('node:stream');
  const { readMultipartSingleFile } = await import('../src/http.js');
  const storageDir = path.join(root, 'backend', 'storage');
  await fs.promises.mkdir(storageDir, { recursive: true });
  const boundary = '----hope-regression-boundary';
  const fileBytes = Buffer.from('%PDF-1.7\nHOPE-REGRESSION\n%%EOF\n', 'utf8');
  const payload = Buffer.concat([
    Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="proof.pdf"\r\nContent-Type: application/pdf\r\n\r\n`, 'utf8'),
    fileBytes,
    Buffer.from(`\r\n--${boundary}--\r\n`, 'utf8'),
  ]);
  const req = Readable.from([payload]);
  req.headers = {
    'content-type': `multipart/form-data; boundary=${boundary}`,
    'content-length': String(payload.length),
  };

  const result = await readMultipartSingleFile(req);
  try {
    assert.equal(result.contentType, 'application/pdf');
    assert.equal(result.size, fileBytes.length);
    assert.deepEqual(await fs.promises.readFile(result.path), fileBytes);
    const remaining = (await fs.promises.readdir(storageDir)).filter((name) => name.startsWith('.incoming-'));
    assert.equal(remaining.length, 0);
  } finally {
    try { await fs.promises.unlink(result.path); } catch {}
  }
});
