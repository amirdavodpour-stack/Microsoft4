import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'hope-trust-'));
process.env.DATA_FILE = path.join(tmp, 'hope.json');
process.env.STORAGE_DIR = path.join(tmp, 'storage');
process.env.NODE_ENV = 'test';
process.env.AUTH_RATE_LIMIT_MAX = '1000';
process.env.GENERAL_RATE_LIMIT_MAX = '5000';

const { createServer } = await import('../src/app.js');
const { db } = await import('../src/db.js');
const server = createServer();
await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
const base = `http://127.0.0.1:${server.address().port}/api/v1`;
const json = (url, options = {}) => fetch(base + url, { ...options, headers: {'Content-Type':'application/json', ...(options.headers || {})} }).then(async (r) => ({status:r.status, body:await r.json()}));

async function register(email, displayName) {
  const r = await json('/auth/register', {method:'POST', body:JSON.stringify({email,password:'pass12345',displayName})});
  assert.equal(r.status, 201);
  return r.body.data;
}

let scenario = 0;
async function readyTransaction() {
  scenario += 1;
  const owner = await register(`trust-owner-${scenario}@example.com`, `Trust Owner ${scenario}`);
  const provider = await register(`trust-provider-${scenario}@example.com`, `Trust Provider ${scenario}`);
  const categories = await json('/categories');
  const jobR = await json('/jobs', {method:'POST',headers:{Authorization:`Bearer ${owner.accessToken}`},body:JSON.stringify({title:'Trust test mission',description:'A mission used to verify transaction trust controls.',categoryId:categories.body.data[0].id,jobType:'FIXED',budgetType:'FIXED',budgetMin:100000,budgetMax:100000,duration:2,acceptanceCriteria:'Complete the requested task.',kind:'MISSION',visibility:'PUBLIC'})});
  assert.equal(jobR.status,201);
  const job = jobR.body.data;
  assert.equal((await json(`/jobs/${job.id}/publish`,{method:'POST',headers:{Authorization:`Bearer ${owner.accessToken}`}})).status,200);
  const offer = await json('/offers',{method:'POST',headers:{Authorization:`Bearer ${provider.accessToken}`},body:JSON.stringify({jobId:job.id,price:100000,message:'Ready to deliver'} )});
  assert.equal(offer.status,201);
  assert.equal((await json(`/offers/${offer.body.data.id}/accept`,{method:'POST',headers:{Authorization:`Bearer ${owner.accessToken}`}})).status,200);
  assert.equal((await json(`/payments/fund/${job.id}`,{method:'POST',headers:{Authorization:`Bearer ${owner.accessToken}`,'Idempotency-Key':'trust-fund'},body:'{}'})).status,201);
  assert.equal((await json(`/jobs/${job.id}/start`,{method:'POST',headers:{Authorization:`Bearer ${provider.accessToken}`}})).status,200);
  return {owner, provider, job};
}

test('settled transactions support one review per participant and reputation aggregation', async () => {
  const {owner, provider, job} = await readyTransaction();
  assert.equal((await json(`/jobs/${job.id}/evidence`,{method:'POST',headers:{Authorization:`Bearer ${provider.accessToken}`},body:JSON.stringify({uri:'https://example.com/delivery'})})).status,201);
  assert.equal((await json(`/jobs/${job.id}/deliver`,{method:'POST',headers:{Authorization:`Bearer ${provider.accessToken}`}})).status,200);
  assert.equal((await json(`/jobs/${job.id}/accept`,{method:'POST',headers:{Authorization:`Bearer ${owner.accessToken}`}})).status,200);
  assert.equal((await json(`/payments/release/${job.id}`,{method:'POST',headers:{Authorization:`Bearer ${owner.accessToken}`}})).status,200);

  const first = await json(`/jobs/${job.id}/reviews`,{method:'POST',headers:{Authorization:`Bearer ${owner.accessToken}`},body:JSON.stringify({rating:5,comment:'Excellent delivery.'})});
  assert.equal(first.status,201);
  const duplicate = await json(`/jobs/${job.id}/reviews`,{method:'POST',headers:{Authorization:`Bearer ${owner.accessToken}`},body:JSON.stringify({rating:4,comment:'Second review should fail.'})});
  assert.equal(duplicate.status,409);
  assert.equal(duplicate.body.error.code,'REVIEW_ALREADY_EXISTS');

  const second = await json(`/jobs/${job.id}/reviews`,{method:'POST',headers:{Authorization:`Bearer ${provider.accessToken}`},body:JSON.stringify({rating:4,comment:'Clear requirements and smooth payment.'})});
  assert.equal(second.status,201);
  const list = await json(`/jobs/${job.id}/reviews`);
  assert.equal(list.status,200);
  assert.equal(list.body.data.summary.count,2);
  assert.equal(list.body.data.summary.average,4.5);
  assert.equal(list.body.data.reviews[0].reviewerId,undefined);

  const reputation = await json(`/providers/${provider.user.id}/reputation`);
  assert.equal(reputation.status,200);
  assert.equal(reputation.body.data.count,1);
  assert.equal(reputation.body.data.average,5);
});

test('owner can request rework after delivery and provider must use that request for another evidence submission', async () => {
  const {owner, provider, job} = await readyTransaction();
  assert.equal((await json(`/jobs/${job.id}/evidence`,{method:'POST',headers:{Authorization:`Bearer ${provider.accessToken}`},body:JSON.stringify({uri:'https://example.com/first'})})).status,201);
  assert.equal((await json(`/jobs/${job.id}/deliver`,{method:'POST',headers:{Authorization:`Bearer ${provider.accessToken}`}})).status,200);
  const rework = await json(`/jobs/${job.id}/rework`,{method:'POST',headers:{Authorization:`Bearer ${owner.accessToken}`},body:JSON.stringify({reason:'Please correct two acceptance criteria items.'})});
  assert.equal(rework.status,201);
  assert.equal(rework.body.data.status,'OPEN');
  const noReq = await json(`/jobs/${job.id}/rework`,{headers:{Authorization:`Bearer ${provider.accessToken}`} });
  assert.equal(noReq.status,200);
  const evidence = await json(`/jobs/${job.id}/evidence`,{method:'POST',headers:{Authorization:`Bearer ${provider.accessToken}`},body:JSON.stringify({uri:'https://example.com/reworked'})});
  assert.equal(evidence.status,201);
  const open = await json(`/jobs/${job.id}/rework`,{headers:{Authorization:`Bearer ${owner.accessToken}`} });
  assert.equal(open.status,200);
  assert.equal(open.body.data,null);
});

test('late cancellation is blocked and a dispute becomes the review path', async () => {
  const {owner, provider, job} = await readyTransaction();
  const cancel = await json(`/jobs/${job.id}/cancel`,{method:'POST',headers:{Authorization:`Bearer ${owner.accessToken}`},body:JSON.stringify({reason:'Owner changed scope after funding'})});
  assert.equal(cancel.status,409);
  assert.equal(cancel.body.error.code,'CANCELLATION_REQUIRES_REVIEW');
  const dispute = await json(`/jobs/${job.id}/dispute`,{method:'POST',headers:{Authorization:`Bearer ${owner.accessToken}`},body:JSON.stringify({reason:'Scope changed after funding',details:'Need an operations decision before money moves.'})});
  assert.equal(dispute.status,201);
  assert.equal(dispute.body.data.status,'OPEN');
  const second = await json(`/jobs/${job.id}/dispute`,{method:'POST',headers:{Authorization:`Bearer ${provider.accessToken}`},body:JSON.stringify({reason:'Duplicate dispute'})});
  assert.equal(second.status,409);
  assert.equal(second.body.error.code,'ACTIVE_DISPUTE_EXISTS');
  assert.equal(db.collection.jobs.find((j) => j.id === job.id).status,'IN_PROGRESS');
});


test('active disputes freeze delivery and can be closed by an admin without silently moving money', async () => {
  const {owner, provider, job} = await readyTransaction();
  const dispute = await json(`/jobs/${job.id}/dispute`,{method:'POST',headers:{Authorization:`Bearer ${owner.accessToken}`},body:JSON.stringify({reason:'Quality concern'})});
  assert.equal(dispute.status,201);
  const deliver = await json(`/jobs/${job.id}/deliver`,{method:'POST',headers:{Authorization:`Bearer ${provider.accessToken}`}});
  assert.equal(deliver.status,409);
  assert.equal(deliver.body.error.code,'ACTIVE_DISPUTE');
  const admin = await register('trust-admin@example.com','Trust Admin');
  db.collection.users.find((u) => u.id === admin.user.id).role = 'ADMIN';
  const resolved = await json(`/admin/disputes/${dispute.body.data.id}/resolve`,{method:'POST',headers:{Authorization:`Bearer ${admin.accessToken}`},body:JSON.stringify({resolutionType:'NO_ACTION',resolutionNote:'Reviewed and dismissed; no financial intervention required.'})});
  assert.equal(resolved.status,200);
  assert.equal(resolved.body.data.status,'RESOLVED');
  assert.equal(resolved.body.data.resolutionType,'NO_ACTION');
  assert.equal(db.collection.payments.find((p) => p.jobId===job.id).status,'HELD');
  const deliverAfter = await json(`/jobs/${job.id}/deliver`,{method:'POST',headers:{Authorization:`Bearer ${provider.accessToken}`}});
  assert.equal(deliverAfter.status,200);
});


test('provider verification uses user-owned storage references and an admin-controlled status transition', async () => {
  const user = await register('verification-provider@example.com', 'Verification Provider');
  const now = new Date().toISOString();
  const upload = db.insert('uploads', {id:crypto.randomUUID(), storageKey:`verification/${user.user.id}/document.pdf`, uploadedBy:user.user.id, contentType:'application/pdf', size:1024, createdAt:now});
  db.touch('uploads'); await db.save();
  const submitted = await json('/providers/me/verification',{method:'POST',headers:{Authorization:`Bearer ${user.accessToken}`},body:JSON.stringify({documentType:'IDENTITY',evidenceUri:`storage://${upload.storageKey}`})});
  assert.equal(submitted.status,201);
  assert.equal(db.collection.providers.find(p=>p.userId===user.user.id).verificationStatus,'PENDING');
  const admin = await register('verification-admin@example.com','Verification Admin');
  db.collection.users.find(u=>u.id===admin.user.id).role='ADMIN';
  const approved = await json(`/admin/provider-verifications/${submitted.body.data.id}/status`,{method:'POST',headers:{Authorization:`Bearer ${admin.accessToken}`},body:JSON.stringify({status:'APPROVED',reviewNote:'Evidence reviewed by operations.'})});
  assert.equal(approved.status,200);
  assert.equal(db.collection.providers.find(p=>p.userId===user.user.id).verificationStatus,'VERIFIED');
});

test('admin dispute resolution applies full refund atomically and records a balanced ledger journal', async () => {
  const {owner, provider, job} = await readyTransaction();
  const dispute = await json(`/jobs/${job.id}/dispute`,{method:'POST',headers:{Authorization:`Bearer ${owner.accessToken}`},body:JSON.stringify({reason:'Cancellation for material mismatch'})});
  assert.equal(dispute.status,201);
  const admin = await register(`refund-admin-${scenario}@example.com`,'Refund Admin');
  db.collection.users.find((u) => u.id === admin.user.id).role='ADMIN';
  const resolved = await json(`/admin/disputes/${dispute.body.data.id}/resolve`,{method:'POST',headers:{Authorization:`Bearer ${admin.accessToken}`},body:JSON.stringify({resolutionType:'REFUND_OWNER',resolutionNote:'Owner refund approved after dispute review.'})});
  assert.equal(resolved.status,200);
  assert.equal(resolved.body.data.status,'RESOLVED');
  assert.equal(resolved.body.data.resolutionType,'REFUND_OWNER');
  const payment = db.collection.payments.find((p)=>p.jobId===job.id);
  assert.equal(payment.status,'REFUNDED');
  assert.equal(db.collection.jobs.find((j)=>j.id===job.id).status,'ASSIGNED');
  const refund = db.collection.refunds.find((r)=>r.paymentId===payment.id);
  assert.equal(refund.status,'REFUNDED');
  const entries = db.collection.ledgerEntries.filter((e)=>e.referenceId===payment.id);
  assert.equal(entries.length >= 3,true);
  assert.equal(entries.reduce((s,e)=>s+Number(e.debit||0),0), entries.reduce((s,e)=>s+Number(e.credit||0),0));
  assert.equal((await json(`/admin/disputes/${dispute.body.data.id}/resolve`,{method:'POST',headers:{Authorization:`Bearer ${admin.accessToken}`},body:JSON.stringify({resolutionType:'SPLIT'})})).status,422);
});

test('admin dispute resolution can release provider funds without bypassing the settlement ledger', async () => {
  const {owner, provider, job} = await readyTransaction();
  const dispute = await json(`/jobs/${job.id}/dispute`,{method:'POST',headers:{Authorization:`Bearer ${provider.accessToken}`},body:JSON.stringify({reason:'Provider requests arbitration before release'})});
  assert.equal(dispute.status,201);
  const admin = await register(`release-admin-${scenario}@example.com`,'Release Admin');
  db.collection.users.find((u) => u.id === admin.user.id).role='ADMIN';
  const resolved = await json(`/admin/disputes/${dispute.body.data.id}/resolve`,{method:'POST',headers:{Authorization:`Bearer ${admin.accessToken}`},body:JSON.stringify({resolutionType:'RELEASE_PROVIDER',resolutionNote:'Delivery evidence supports provider settlement.'})});
  assert.equal(resolved.status,200);
  assert.equal(resolved.body.data.status,'RESOLVED');
  const payment = db.collection.payments.find((p)=>p.jobId===job.id);
  assert.equal(payment.status,'RELEASED');
  assert.equal(db.collection.jobs.find((j)=>j.id===job.id).status,'SETTLED');
  const settlement = db.collection.settlements.find((r)=>r.paymentId===payment.id);
  assert.equal(settlement.status,'RELEASED');
  const entries = db.collection.ledgerEntries.filter((e)=>e.referenceId===payment.id);
  assert.equal(entries.reduce((s,e)=>s+Number(e.debit||0),0), entries.reduce((s,e)=>s+Number(e.credit||0),0));
});


after(async () => { await db.close(); await new Promise((resolve) => server.close(resolve)); fs.rmSync(tmp,{recursive:true,force:true}); });
