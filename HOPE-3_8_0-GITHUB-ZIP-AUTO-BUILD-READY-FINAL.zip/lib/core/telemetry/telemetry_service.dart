import 'dart:convert';
import 'dart:math';
import 'dart:ui';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import '../storage/secure_store.dart';

class TelemetryService {
  TelemetryService(this.store, {required this.baseUrl});
  final SecureStore store;
  final String baseUrl;
  static const _anonKey = 'hope.telemetry.anonymous_id';
  static const _consentKey = 'hope.telemetry.consent';
  static const _version = String.fromEnvironment('HOPE_VERSION', defaultValue: '3.8.0');

  Future<String> _anonymousId() async {
    final prefs = await SharedPreferences.getInstance();
    final existing = prefs.getString(_anonKey);
    if (existing != null && existing.isNotEmpty) return existing;
    final random = Random.secure();
    final bytes = List<int>.generate(24, (_) => random.nextInt(256));
    final value = base64Url.encode(bytes).replaceAll('=', '');
    await prefs.setString(_anonKey, value);
    return value;
  }

  String get _platform {
    if (kIsWeb) return 'WEB';
    switch (defaultTargetPlatform) {
      case TargetPlatform.android: return 'ANDROID';
      case TargetPlatform.iOS: return 'IOS';
      default: return 'UNKNOWN';
    }
  }

  Future<bool> get telemetryConsent async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_consentKey) ?? false;
  }

  Future<void> setTelemetryConsent(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_consentKey, enabled);
    if (!enabled) await prefs.remove(_anonKey);
  }

  Future<void> track(String eventName, {Map<String, Object?> properties = const {}, String? sessionId}) async {
    try {
      if (!await telemetryConsent) return;
      final token = await store.accessToken;
      final body = <String, dynamic>{
        'eventName': eventName,
        'anonymousId': await _anonymousId(),
        'sessionId': sessionId == null ? null : _safeText(sessionId, 200),
        'appVersion': _version,
        'platform': _platform,
        'properties': _sanitizeMap(properties),
        'occurredAt': DateTime.now().toUtc().toIso8601String(),
      };
      await http.post(Uri.parse('$baseUrl/analytics/events'), headers: {
        'Content-Type': 'application/json', 'Accept': 'application/json',
        if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
      }, body: jsonEncode(body)).timeout(const Duration(seconds: 4));
    } catch (_) {
      // Telemetry must never affect the product request path.
    }
  }

  Future<void> recordError(Object error, StackTrace stack, {String? fingerprint, Map<String, Object?> context = const {}}) async {
    try {
      if (!await telemetryConsent) return;
      final token = await store.accessToken;
      final body = <String, dynamic>{
        'anonymousId': await _anonymousId(), 'appVersion': _version, 'platform': _platform,
        'releaseChannel': kReleaseMode ? 'production' : 'debug', 'fingerprint': fingerprint ?? _fingerprint(error),
        'message': _safeText(error.toString(), 2000), 'stack': _safeText(stack.toString(), 12000), 'context': _sanitizeMap(context),
        'occurredAt': DateTime.now().toUtc().toIso8601String(),
      };
      await http.post(Uri.parse('$baseUrl/analytics/crashes'), headers: {
        'Content-Type': 'application/json', 'Accept': 'application/json',
        if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
      }, body: jsonEncode(body)).timeout(const Duration(seconds: 4));
    } catch (_) {}
  }


  static const Set<String> _sensitiveKeys = {
    'authorization', 'accesstoken', 'refreshtoken', 'token', 'password',
    'secret', 'apikey', 'cookie', 'set-cookie', 'paymentprovidertoken',
  };

  dynamic _sanitizeValue(String key, Object? value) {
    if (_sensitiveKeys.contains(key.toLowerCase())) return '[REDACTED]';
    if (value is Map) return _sanitizeMap(Map<String, Object?>.fromEntries(
      value.entries.map((entry) => MapEntry(entry.key.toString(), entry.value)),
    ));
    if (value is Iterable) return value.take(50).map((e) => _sanitizeValue('', e)).toList();
    if (value is String) return _safeText(value, 1000);
    return value;
  }

  Map<String, Object?> _sanitizeMap(Map<String, Object?> input) {
    final result = <String, Object?>{};
    for (final entry in input.entries.take(50)) {
      result[entry.key] = _sanitizeValue(entry.key, entry.value);
    }
    return result;
  }

  String _safeText(String value, int maxLength) {
    final scrubbed = value
        .replaceAll(RegExp(r'(?i)bearer\s+[A-Za-z0-9._~+/=-]+'), 'Bearer [REDACTED]')
        .replaceAll(RegExp(r'(?i)(password|token|secret|api[-_]?key|authorization|cookie)=([^&\s]+)'), r'\1=[REDACTED]')
        .replaceAll(RegExp(r'(?i)(\"(?:password|token|secret|api[-_]?key|authorization|cookie)\"\s*:\s*\")[^\"]*(\")'), r'\1[REDACTED]\2')
        .replaceAll(RegExp(r'(?i)https?://[^\s/?#]+[^\s]*'), '[URL_REDACTED]')
        .replaceAll(RegExp(r'\b[+]?\d[\d .()\-]{7,}\d\b'), '[PHONE_REDACTED]')
        .replaceAll(RegExp(r'\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b', caseSensitive: false), '[EMAIL_REDACTED]');
    if (scrubbed.length <= maxLength) return scrubbed;
    return '${scrubbed.substring(0, maxLength)}…';
  }

  String _fingerprint(Object error) {
    final raw = error.runtimeType.toString();
    return raw.length >= 8 ? raw : '${raw}_error';
  }
}
