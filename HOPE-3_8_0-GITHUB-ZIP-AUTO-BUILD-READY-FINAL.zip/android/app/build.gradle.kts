import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("dev.flutter.flutter-gradle-plugin")
}


kotlin {
    compilerOptions {
        jvmTarget = JvmTarget.fromTarget("17")
    }
}

android {
    namespace = "com.hope.marketplace"
    compileSdk = 36
    ndkVersion = "28.2.13676358"

    defaultConfig {
        applicationId = "com.hope.marketplace"
        minSdk = 30
        targetSdk = 36
        versionCode = 11
        versionName = "3.8.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    signingConfigs {
        create("release") {
            val storeFilePath = System.getenv("ANDROID_RELEASE_STORE_FILE")
            if (!storeFilePath.isNullOrBlank()) {
                storeFile = file(storeFilePath)
                storePassword = System.getenv("ANDROID_RELEASE_STORE_PASSWORD")
                keyAlias = System.getenv("ANDROID_RELEASE_KEY_ALIAS")
                keyPassword = System.getenv("ANDROID_RELEASE_KEY_PASSWORD")
            }
        }
    }

    lint {
        abortOnError = true
        checkReleaseBuilds = true
    }

    buildTypes {
        release {
            // Every release build must declare its intent explicitly. There is no
            // CI/environment fallback: production remains fail-closed and pilot is
            // intentionally non-production.
            val profile = System.getenv("BUILD_PROFILE")?.lowercase()
                ?: error("BUILD_PROFILE must be explicitly set to production or pilot")
            when (profile) {
                "production" -> {
                    // Production must always use the explicitly injected release keystore.
                    val releaseStore = System.getenv("ANDROID_RELEASE_STORE_FILE")
                    if (releaseStore.isNullOrBlank()) {
                        error("Production builds require ANDROID_RELEASE_STORE_FILE and signing credentials")
                    }
                    signingConfig = signingConfigs.getByName("release")
                }
                "pilot" -> {
                    // Pilot artifacts are non-production test builds. They may use the
                    // Android debug keystore so CI can build without handling production
                    // signing material. The release workflow never uses this profile.
                    signingConfig = signingConfigs.getByName("debug")
                }
                else -> error("Unsupported BUILD_PROFILE: $profile")
            }
            isMinifyEnabled = profile == "production"
            isShrinkResources = profile == "production"
        }
    }
}

flutter {
    source = "../.."
}
