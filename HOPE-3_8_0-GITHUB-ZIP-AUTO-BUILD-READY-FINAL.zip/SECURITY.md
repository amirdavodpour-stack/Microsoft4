# HOPE Security Policy

## Security baseline

HOPE follows a defense-in-depth baseline informed by OWASP ASVS 5.0.0 for the API, OWASP MASVS for the Android client, NIST SP 800-218 SSDF for secure development, and SLSA v1.2 provenance practices for release integrity.

## Vulnerability handling

Security-sensitive reports must never be committed as ordinary issues containing credentials, tokens, private keys, or exploit details. Reproduce safely, minimize sensitive data, and use a private security-reporting channel configured by the repository owner.

## Release blockers

A release is blocked by any known critical/high vulnerability, exposed secret, unverifiable release provenance, unsigned release artifact, failed security gate, or unresolved P0/P1 defect.

## Secret handling

Secrets belong in the CI/environment secret store. They must not be placed in source, fixtures, artifacts, logs, crash reports, telemetry, or generated reports.

## Dependency security

Backend dependencies are governed by `backend/package-lock.json`. Flutter applications must commit a real `pubspec.lock` before release certification. GitHub Actions are reviewed and kept pinned/updated.
