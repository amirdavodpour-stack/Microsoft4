# HOPE — ZIP-only GitHub bootstrap

GitHub stores a ZIP uploaded to a repository as a normal binary file; it does not execute workflow files from inside that ZIP. Therefore the repository needs the small `zip-bootstrap.yml` workflow once.

## One-time setup

1. Upload `HOPE-3_8_0-GITHUB-READY.zip` to the repository root.
2. Upload/create `.github/workflows/zip-bootstrap.yml` using the matching file supplied with this release.
3. In GitHub: **Actions → HOPE ZIP Bootstrap → Run workflow**.

The bootstrap:

- auto-detects the uploaded ZIP when no filename is supplied;
- safely rejects Zip-Slip/absolute archive paths;
- discovers the real Flutter project root even when the ZIP contains an outer folder;
- replaces the repository payload with the project contents;
- removes the uploaded ZIP;
- creates/validates `pubspec.lock` using Flutter 3.47.0;
- commits the normalized project and lockfile;
- pushes once, which automatically starts the build workflow.

The build workflow then collects the full local-test error list, performs Flutter/Android/Gradle checks, builds debug and pilot-release APKs independently of test failures, and uploads reports/logs/APK even when the job ultimately fails. The bootstrap also waits for that build run to finish, downloads its installable APK artifact, and publishes a direct `HOPE-FINAL-APK-*` artifact from the bootstrap run.

Set repository secret `API_BASE_URL_STAGING` to a real HTTPS staging endpoint to run against live staging. Without it, the pilot APK uses the non-production placeholder `https://ci.invalid/api/v1`.
