# HOPE SLO / SLI Baseline

## Availability
- API availability target: >= 99.9% monthly in production.
- Readiness failures must exclude intentionally drained instances.

## Latency
- p95 general API: <= 750 ms under agreed steady-state load.
- p99 general API: <= 1500 ms.
- Authentication p95: <= 1000 ms excluding password-hash saturation.

## Correctness
- 5xx rate: < 0.5% over 15-minute window.
- payment duplicate side effects: 0.
- notification duplicate side effects: 0 for a single dedupe key.

## Reliability
- graceful shutdown budget: <= 10 seconds.
- provider calls have explicit deadlines.
- outbox leases must not exceed configured lease duration.

## Recovery
- define and verify RPO/RTO for PostgreSQL before production launch.
- release is NO-GO if restore integrity cannot be demonstrated.

These are release gates only after staging measurements exist; they are not fabricated runtime evidence.
