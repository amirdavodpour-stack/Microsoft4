#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

log(){ printf '\n[%s] %s\n' "$(date -u +%H:%M:%S)" "$*"; }
run(){ local name="$1"; shift; log "$name"; "$@"; }

run 'Node deep syntax' bash tools/check_node_syntax.sh
run 'Security hygiene' bash tools/security_hygiene.sh
run 'Backend core contracts' bash -lc 'cd backend && npm run check && npm run test:fast && npm run test:contract && npm run test:product'
run 'OpenAPI validation' bash -lc 'cd backend && npm run openapi:validate'
run 'SBOM contract' bash -lc 'cd backend && npm run sbom && node --test tests/sbom-contract.test.mjs'
run 'Release evidence contract' bash -lc 'cd backend && npm run test:release-evidence'
run 'Release hardening contracts' bash -lc 'cd backend && node --test tests/release-hardening-contract.test.mjs tests/release-manifest-contract.test.mjs tests/release-validation-script.test.mjs tests/release-supply-chain-contract.test.mjs'
run 'Localization/static UX gates' bash tools/check_localization_wave9.sh
run 'UX static gate' bash tools/check_ux_wave8.sh

printf '\nProduct Grade gate result: STATIC_CERTIFIED\n'
printf 'Runtime certification remains mandatory: Flutter/Android, PostgreSQL, S3, payment provider, notification provider, staging performance, DR.\n'
