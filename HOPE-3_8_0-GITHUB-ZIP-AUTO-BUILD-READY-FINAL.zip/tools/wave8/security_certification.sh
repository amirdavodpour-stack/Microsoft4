#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; cd "$ROOT"
bash tools/security_hygiene.sh
FILES=$(find lib backend/src android/app .github/workflows -type f \( -name '*.js' -o -name '*.mjs' -o -name '*.dart' -o -name '*.kt' -o -name '*.kts' -o -name '*.yml' -o -name '*.yaml' \) -print)
if [[ -n "$FILES" ]] && printf '%s\n' "$FILES" | xargs grep -InE 'NODE_TLS_REJECT_UNAUTHORIZED[[:space:]]*=[[:space:]]*0|rejectUnauthorized[[:space:]]*:[[:space:]]*false|curl[[:space:]].*-[kK][[:space:]]|(^|[[:space:]\"'"'"'])http://[^[:space:]\"'"'"']+' 2>/dev/null | grep -Ev 'localhost|127\.0\.0\.1|ci\.invalid|schemas.android.com'; then
  echo 'Potential insecure TLS/HTTP configuration detected.' >&2
  exit 1
fi
tools/wave8/require_node24.sh
if [[ -d backend/node_modules ]]; then
  (cd backend && npm audit --audit-level=high)
else
  echo 'node_modules absent; dependency audit will run after npm ci in the Node 24 CI job' >&2
  exit 200
fi
