#!/usr/bin/env python3
import json, os, sys, hashlib
from datetime import datetime, timezone
BASE_ARG=sys.argv[1] if len(sys.argv)>1 else os.path.join(os.getcwd(),'artifacts','wave8')
candidate=os.path.abspath(BASE_ARG)
base=candidate if os.path.isdir(os.path.join(candidate,'gates')) else os.path.join(candidate,'artifacts','wave8')
GATES=[f'GATE-{i:02d}' for i in range(1,19)]
required=set(GATES)
results={}
for g in GATES:
    p=os.path.join(base,'gates',g+'.json')
    if os.path.isfile(p):
        try:
            obj=json.load(open(p, encoding='utf-8'))
            expected=os.environ.get('GITHUB_SHA')
            required={'schemaVersion','gate','status','exitCode','startedAt','finishedAt','durationSeconds','toolchain','metrics','artifacts','errors','warnings','commitSha'}
            missing=required-set(obj)
            if missing:
                raise ValueError(f'MISSING_GATE_FIELDS:{sorted(missing)}')
            if obj.get('commitSha') != expected:
                obj={'gate':g,'status':'ERROR','errors':[{'type':'STALE_CHECKPOINT','message':f'checkpoint commit {obj.get("commitSha")} != expected {expected}'}]}
            elif obj.get('gate') != g:
                obj={'gate':g,'status':'ERROR','errors':[{'type':'GATE_MISMATCH','message':f'checkpoint gate {obj.get("gate")} != expected {g}'}]}
            else:
                for a in obj.get('artifacts', []):
                    if not isinstance(a, str) or os.path.isabs(a) or a.startswith('../') or '\\' in a:
                        raise ValueError(f'UNSAFE_ARTIFACT_PATH:{a!r}')
            results[g]=obj
        except Exception as e:
            results[g]={"gate":g,"status":"ERROR","errors":[{"type":"INVALID_GATE_RESULT","message":str(e)}]}
    else:
        results[g]={"gate":g,"status":"ERROR","errors":[{"type":"MISSING_RESULT","message":"Mandatory gate result missing."}]}
counts={s:0 for s in ['PASS','FAIL','TIMEOUT','BLOCKED_TOOLCHAIN','BLOCKED_INFRA','SKIPPED_DEPENDENCY','ERROR']}
for obj in results.values(): counts[obj.get('status','ERROR')]=counts.get(obj.get('status','ERROR'),0)+1
missing_artifact=[]
for g,obj in results.items():
    if obj.get('status')=='PASS':
        for a in obj.get('artifacts',[]):
            if isinstance(a,str) and not os.path.exists(a):
                missing_artifact.append({'gate':g,'artifact':a})
all_pass=all(results[g].get('status')=='PASS' for g in GATES)
no_missing=not missing_artifact
score_path=os.path.join(base,'summary','PRODUCT-GRADE-SCORECARD.json')
score={}
if os.path.isfile(score_path):
    try: score=json.load(open(score_path))
    except Exception: score={}
min_score=score.get('minScore')
go='GO' if all_pass and no_missing and isinstance(min_score,(int,float)) and min_score>=90 and not score.get('p0p1KnownDefects') else 'NO-GO'
now=datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
summary={
  'schemaVersion':1,'generatedAt':now,'commitSha':os.environ.get('GITHUB_SHA','UNKNOWN'),'workflowRunId':os.environ.get('GITHUB_RUN_ID','LOCAL'),
  'totalGates':len(GATES),'counts':counts,'missingEvidence':missing_artifact,'goNoGo':go,'gates':results,
  'score':score,
}
os.makedirs(os.path.join(base,'summary'),exist_ok=True)
json.dump(summary,open(os.path.join(base,'summary','WAVE8-CERTIFICATION.json'),'w'),indent=2); open(os.path.join(base,'summary','WAVE8-CERTIFICATION.json'),'a').write('\n')
json.dump({'decision':go,'generatedAt':now,'commitSha':summary['commitSha'],'minScore':min_score,'requiredAllPass':all_pass,'missingEvidence':missing_artifact},open(os.path.join(base,'summary','RELEASE-GO-NOGO.json'),'w'),indent=2); open(os.path.join(base,'summary','RELEASE-GO-NOGO.json'),'a').write('\n')
lines=['# HOPE 3.8.0 — Product Grade Certification','',f'- Decision: **{go}**',f'- Commit: `{summary["commitSha"]}`',f'- Generated: `{now}`','', '## Gate Matrix','', '| Gate | Status | Duration | Evidence |','|---|---|---:|---|']
for g in GATES:
    r=results[g]; ev='; '.join(os.path.basename(x) for x in r.get('artifacts',[])[:3]) or 'none'
    lines.append(f'| {g} | {r.get("status")} | {r.get("durationSeconds","-")}s | {ev} |')
lines += ['', '## Executive Summary','',f'Mandatory gates: {len(GATES)}',f'Completed PASS gates: {counts.get("PASS",0)}',f'FAIL={counts.get("FAIL",0)} TIMEOUT={counts.get("TIMEOUT",0)} BLOCKED_TOOLCHAIN={counts.get("BLOCKED_TOOLCHAIN",0)} BLOCKED_INFRA={counts.get("BLOCKED_INFRA",0)} SKIPPED={counts.get("SKIPPED_DEPENDENCY",0)} ERROR={counts.get("ERROR",0)}','', '## Runtime Certification','', 'GATE-04 Backend fast tests; GATE-05 contracts; GATE-06 product tests; GATE-11 performance.','', '## Security Certification','', 'GATE-03 source/dependency security evidence.','', '## Performance Certification','', 'GATE-11 bounded workload only; budgets are evaluated by the project performance tool.','', '## Resilience Certification','', 'GATE-12 failure injection; GATE-13 PostgreSQL/DR; GATE-14 storage; GATE-15 payment; GATE-16 notification.','', '## Mobile Certification','', 'GATE-07 mobile static; GATE-08 Flutter tests; GATE-09 Android build; GATE-10 emulator smoke.','', '## Release Integrity','', 'GATE-17 release evidence and reproducibility; SHA-256/checksums when build evidence exists.','', '## Known Limitations','', f'Missing evidence: {len(missing_artifact)}; stale/missing gate results are fail-closed.','', '## Remaining Blockers','', '; '.join(f'{g}:{results[g].get("status")}' for g in GATES if results[g].get("status")!='PASS') or 'None','', '## Product Grade Score','',f'Minimum score: **{min_score if min_score is not None else "UNPROVEN"}**','', '## GO / NO-GO','',f'**{go}**','', '## Artifact Manifest','', 'See artifacts/wave8/gates, logs, metrics, reports and release.']
open(os.path.join(base,'summary','WAVE8-CERTIFICATION.md'),'w').write('\n'.join(lines)+'\n')
open(os.path.join(base,'summary','SUMMARY.md'),'w').write('\n'.join(lines)+'\n')

# Publish a self-contained evidence bundle independent of the CI workspace.
bundle=os.path.join(os.path.dirname(base),'..','wave8-certification') if os.path.basename(base)=='wave8' else os.path.join(base,'wave8-certification')
bundle=os.path.abspath(bundle)
import shutil
if os.path.exists(bundle): shutil.rmtree(bundle)
os.makedirs(bundle,exist_ok=True)
for name in ['gates','logs','metrics','reports','screenshots','release']:
    src=os.path.join(base,name)
    if os.path.isdir(src): shutil.copytree(src,os.path.join(bundle,name))
for name in ['SUMMARY.md','WAVE8-CERTIFICATION.json','WAVE8-CERTIFICATION.md','PRODUCT-GRADE-SCORECARD.json','RELEASE-GO-NOGO.json']:
    src=os.path.join(base,'summary',name)
    if os.path.isfile(src): shutil.copy2(src,os.path.join(bundle,name))
# Immutable manifest over every bundled evidence file.
manifest=[]
for root,dirs,files in os.walk(bundle):
    for fn in sorted(files):
        fp=os.path.join(root,fn)
        if os.path.basename(fp)=='ARTIFACT-MANIFEST.sha256': continue
        h=hashlib.sha256(open(fp,'rb').read()).hexdigest()
        manifest.append(f'{h}  {os.path.relpath(fp,bundle)}')
open(os.path.join(bundle,'ARTIFACT-MANIFEST.sha256'),'w').write('\n'.join(manifest)+'\n')
print(json.dumps({'decision':go,'counts':counts,'minScore':min_score},indent=2))
if go!='GO': sys.exit(2)
