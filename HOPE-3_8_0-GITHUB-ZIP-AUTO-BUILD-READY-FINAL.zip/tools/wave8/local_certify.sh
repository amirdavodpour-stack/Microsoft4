#!/usr/bin/env bash
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; cd "$ROOT"
rm -rf artifacts/wave8
mkdir -p artifacts/wave8/{gates,summary,logs,metrics,reports,screenshots,release}
run() { local gate="$1" cmd="$2" secs="$3"; echo "== $gate =="; ./tools/wave8/run_gate.sh "$gate" "$cmd" "$secs" >/dev/null 2>&1; rc=$?; echo "$gate rc=$rc"; return 0; }
run GATE-01 'tools/wave8/repository_integrity.sh' 300
run GATE-02 'tools/wave8/static_certification.sh' 300
run GATE-03 'tools/wave8/security_certification.sh' 300
run GATE-04 'tools/wave8/require_node24.sh && cd backend && npm ci --ignore-scripts && npm run test:fast' 300
run GATE-05 'tools/wave8/require_node24.sh && cd backend && npm ci --ignore-scripts && npm run test:contract && npm run test:release-evidence' 300
run GATE-06 'tools/wave8/require_node24.sh && cd backend && npm ci --ignore-scripts && npm run test:product' 300
run GATE-07 'tools/wave8/mobile_static.sh' 300
run GATE-08 'tools/wave8/flutter_tests.sh' 300
run GATE-09 'tools/wave8/android_build.sh' 300
run GATE-10 'tools/wave8/infra_or_block.sh emulator' 300
run GATE-11 'tools/wave8/infra_or_block.sh performance' 300
run GATE-12 'tools/wave8/require_node24.sh && cd backend && npm ci --ignore-scripts && npm run test:failure-injection' 300
run GATE-13 'tools/wave8/infra_or_block.sh postgres' 300
run GATE-14 'tools/wave8/infra_or_block.sh storage' 300
run GATE-15 'tools/wave8/infra_or_block.sh payment' 300
run GATE-16 'tools/wave8/infra_or_block.sh notification' 300
run GATE-17 'tools/wave8/require_node24.sh' 300
python3 tools/wave8/score_from_evidence.py . >/dev/null 2>&1 || true
run GATE-18 'python3 tools/wave8/score_from_evidence.py .' 300
python3 tools/wave8/final_aggregator.py artifacts/wave8 >/dev/null 2>&1 || true
echo "LOCAL_WAVE8_COMPLETE"
