#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; cd "$ROOT"
if ! command -v flutter >/dev/null 2>&1 || ! command -v java >/dev/null 2>&1; then echo 'Flutter or Java toolchain unavailable' >&2; exit 200; fi
bash tools/wave8/ensure_android_sdk_baseline.sh
bash tools/verify-pubspec-lock-fresh.sh
BUILD_PROFILE="${BUILD_PROFILE:-pilot}" ./tools/build_apk_release.sh
APK=build/app/outputs/flutter-apk/app-release.apk
test -s "$APK"
mkdir -p artifacts/wave8/release
cp "$APK" artifacts/wave8/release/HOPE-release.apk
sha256sum "$APK" > artifacts/wave8/release/apk.sha256
stat -c '%n %s bytes' "$APK" > artifacts/wave8/release/apk-size.txt
if command -v apksigner >/dev/null 2>&1; then apksigner verify --verbose --print-certs "$APK" > artifacts/wave8/release/apk-signature.txt; else echo 'apksigner unavailable' >&2; exit 200; fi
