#!/usr/bin/env bash
set -uo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"
GATE="${1:?gate id required}"
CMD="${2:?command required}"
TIMEOUT_SEC="${3:-600}"
ARTIFACT_ROOT="${ARTIFACT_ROOT:-$ROOT/artifacts/wave8}"
WORK_DIR="$ARTIFACT_ROOT/gates/$GATE"
LOG_DIR="$ARTIFACT_ROOT/logs/$GATE"
METRIC_DIR="$ARTIFACT_ROOT/metrics/$GATE"
mkdir -p "$WORK_DIR" "$LOG_DIR" "$METRIC_DIR"

START_EPOCH=$(date +%s)
STARTED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)
SHA="${GITHUB_SHA:-$(git -C "$ROOT" rev-parse HEAD 2>/dev/null || echo UNKNOWN)}"
RUN_ID="${GITHUB_RUN_ID:-LOCAL}"
TOOLCHAIN_JSON="$METRIC_DIR/toolchain.json"
LOG_FILE="$LOG_DIR/run.log"
STDOUT_FILE="$LOG_DIR/stdout.log"
STDERR_FILE="$LOG_DIR/stderr.log"
COMMAND_FILE="$LOG_DIR/command.txt"
DIAG_FILE="$LOG_DIR/diagnostics.txt"
RESULT="$ARTIFACT_ROOT/gates/$GATE.json"

command -v timeout >/dev/null 2>&1 || { echo "timeout command is required" >&2; exit 2; }

printf '%s\n' "$CMD" > "$COMMAND_FILE"
python3 - "$TOOLCHAIN_JSON" "$SHA" "$RUN_ID" <<'PY'
import json,sys,subprocess
out,sha,run_id=sys.argv[1:]
def sh(cmd):
 try: return subprocess.check_output(f'timeout 2s bash -lc {cmd!r}',shell=True,text=True,stderr=subprocess.STDOUT).strip().splitlines()[0]
 except Exception: return 'unavailable'
import os
def optional(cmd, probe):
 return sh(cmd) if os.system(probe) == 0 else 'unavailable'
obj={
  'bash':os.environ.get('BASH_VERSION','unknown'),
  'node':optional('node --version','command -v node >/dev/null 2>&1'),
  'npm':optional('npm --version','command -v npm >/dev/null 2>&1'),
  'flutter':optional('flutter --version','command -v flutter >/dev/null 2>&1'),
  'dart':optional('dart --version 2>&1','command -v dart >/dev/null 2>&1'),
  'java':optional('java -version 2>&1','command -v java >/dev/null 2>&1'),
  'gradle':'wrapper-pinned-8.13',
  'gradleWrapperSha256':sh('sha256sum android/gradle/wrapper/gradle-wrapper.jar 2>/dev/null | cut -d" " -f1') if os.path.exists('android/gradle/wrapper/gradle-wrapper.jar') else 'unavailable',
  'python':optional('python3 --version','command -v python3 >/dev/null 2>&1'), 'gitSha':sha, 'runId':run_id}
json.dump(obj,open(out,'w'),indent=2); open(out,'a').write('\n')
PY

run_cmd() {
  timeout --signal=TERM --kill-after=20s "${TIMEOUT_SEC}s" bash -lc "$CMD" > >(tee "$STDOUT_FILE") 2> >(tee "$STDERR_FILE" >&2)
}

status="PASS"
exit_code=0
set +e
run_cmd
exit_code=$?
set -e
case "$exit_code" in
  0) status="PASS" ;;
  124|137) status="TIMEOUT" ;;
  200) status="BLOCKED_TOOLCHAIN" ;;
  201) status="BLOCKED_INFRA" ;;
  202) status="SKIPPED_DEPENDENCY" ;;
  126|127) status="ERROR" ;;
  *) status="FAIL" ;;
esac

FINISHED_AT=$(date -u +%Y-%m-%dT%H:%M:%SZ)
END_EPOCH=$(date +%s)
DURATION=$((END_EPOCH-START_EPOCH))

{
  echo "status=$status"
  echo "exit_code=$exit_code"
  echo "duration_seconds=$DURATION"
  echo "--- process ---"
  ps -eo pid,ppid,stat,etime,%cpu,%mem,cmd --sort=-%cpu | head -n 40 || true
  echo "--- memory ---"
  free -h || true
  echo "--- disk ---"
  df -h "$ROOT" || true
  echo "--- last logs ---"
  tail -n 300 "$STDOUT_FILE" 2>/dev/null || true
  tail -n 300 "$STDERR_FILE" 2>/dev/null || true
} > "$DIAG_FILE"

python3 - "$RESULT" "$GATE" "$status" "$exit_code" "$STARTED_AT" "$FINISHED_AT" "$DURATION" "$SHA" "$RUN_ID" "$TOOLCHAIN_JSON" "$STDOUT_FILE" "$STDERR_FILE" "$COMMAND_FILE" "$ROOT" <<'PY'
import json, os, sys
out, gate, status, code, start, finish, duration, sha, run_id, toolchain, stdout, stderr, command, root = sys.argv[1:]
def size(p):
    try: return os.path.getsize(p)
    except OSError: return 0
obj={
  "schemaVersion":1,
  "gate":gate,
  "status":status,
  "exitCode":int(code),
  "startedAt":start,
  "finishedAt":finish,
  "durationSeconds":int(duration),
  "commitSha":sha,
  "workflowRunId":run_id,
  "toolchain": json.load(open(toolchain)),
  "metrics":{"stdoutBytes":size(stdout),"stderrBytes":size(stderr)},
  "artifacts":[os.path.relpath(stdout, start=root), os.path.relpath(stderr, start=root), os.path.relpath(command, start=root)],
  "errors":[] if status=="PASS" else [{"type":status,"message":"Gate command exited non-zero or timed out."}],
  "warnings":[]
}
json.dump(obj, open(out,"w"), indent=2)
open(out,"a").write("\n")
PY

# Make result discoverable even if the shell command fails.
cp "$RESULT" "$WORK_DIR/result.json" 2>/dev/null || true

# Never mutate status to PASS after timeout/failure.
if [[ "$status" == "PASS" ]]; then exit 0; fi
if [[ "$status" == "BLOCKED_TOOLCHAIN" ]]; then exit 200; fi
if [[ "$status" == "BLOCKED_INFRA" ]]; then exit 201; fi
if [[ "$status" == "SKIPPED_DEPENDENCY" ]]; then exit 202; fi
exit "$exit_code"
