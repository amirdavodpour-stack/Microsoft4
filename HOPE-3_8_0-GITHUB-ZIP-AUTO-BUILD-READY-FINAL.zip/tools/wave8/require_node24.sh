#!/usr/bin/env bash
set -euo pipefail
major="$(node -p 'Number(process.versions.node.split(".")[0])' 2>/dev/null || echo 0)"
if (( major < 24 )); then echo "Node 24+ required; found $(node --version 2>/dev/null || echo unavailable)" >&2; exit 200; fi
