#!/usr/bin/env python3
import json, os, sys
from datetime import datetime, timezone
root=sys.argv[1] if len(sys.argv)>1 else os.getcwd(); base=os.path.join(root,'artifacts','wave8')
gates={}
for n in range(1,18):
 p=os.path.join(base,'gates',f'GATE-{n:02d}.json')
 if os.path.isfile(p):
  try: gates[f'GATE-{n:02d}']=json.load(open(p))
  except Exception: pass
passed=sum(1 for r in gates.values() if r.get('status')=='PASS'); total=17
score=round(100*passed/total,2)
p0p1=None
proof=os.path.join(base,'release','P0P1-KNOWN-DEFECTS.json')
if os.path.isfile(proof):
 try:
  d=json.load(open(proof)); p0p1=bool(d.get('knownDefects'))
 except Exception: p0p1=None
obj={'schemaVersion':1,'derivedAt':datetime.now(timezone.utc).isoformat().replace('+00:00','Z'),'commitSha':os.environ.get('GITHUB_SHA','UNKNOWN'),'method':'mandatory-gate pass ratio; no manual inflation','mandatoryGates':total,'passedGates':passed,'minScore':score,'allAtLeast90':score>=90,'p0p1KnownDefects':p0p1,'p0p1Evidence':proof if os.path.isfile(proof) else 'UNPROVEN','gates':{k:v.get('status') for k,v in gates.items()}}
os.makedirs(os.path.join(base,'summary'),exist_ok=True)
json.dump(obj,open(os.path.join(base,'summary','PRODUCT-GRADE-SCORECARD.json'),'w'),indent=2); open(os.path.join(base,'summary','PRODUCT-GRADE-SCORECARD.json'),'a').write('\n')
print(json.dumps(obj,indent=2))
sys.exit(0 if score>=90 and p0p1 is False else 2)
