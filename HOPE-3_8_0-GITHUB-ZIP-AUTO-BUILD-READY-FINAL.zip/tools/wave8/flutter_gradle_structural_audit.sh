#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"
fail(){ echo "ERROR: $*" >&2; exit 1; }

required=(pubspec.yaml analysis_options.yaml l10n.yaml android/settings.gradle.kts android/build.gradle.kts android/app/build.gradle.kts android/gradle/wrapper/gradle-wrapper.properties android/gradlew android/app/src/main/AndroidManifest.xml android/app/src/main/kotlin/com/hope/marketplace/MainActivity.kt android/app/src/main/res/xml/network_security_config.xml)
for f in "${required[@]}"; do test -f "$f" || fail "missing required file: $f"; done
test -x android/gradlew || fail 'android/gradlew is not executable'
test -s android/gradle/wrapper/gradle-wrapper.jar || fail 'Gradle wrapper JAR is missing/empty'

# Static version contracts.
grep -q "id(\"com.android.application\") version \"8.11.1\"" android/settings.gradle.kts || fail 'AGP 8.11.1 contract missing'
grep -q "id(\"org.jetbrains.kotlin.android\") version \"2.2.20\"" android/settings.gradle.kts || fail 'Kotlin 2.2.20 contract missing'
grep -q 'gradle-8.13-bin.zip' android/gradle/wrapper/gradle-wrapper.properties || fail 'Gradle 8.13 wrapper contract missing'
grep -q 'compileSdk = 36' android/app/build.gradle.kts || fail 'compileSdk 36 contract missing'
grep -q 'targetSdk = 36' android/app/build.gradle.kts || fail 'targetSdk 36 contract missing'
grep -q 'minSdk = 30' android/app/build.gradle.kts || fail 'minSdk 30 contract missing'
grep -q 'ndkVersion = "28.2.13676358"' android/app/build.gradle.kts || fail 'NDK 28.2 contract missing'
grep -q 'sourceCompatibility = JavaVersion.VERSION_17' android/app/build.gradle.kts || fail 'Java 17 source compatibility missing'
grep -q 'targetCompatibility = JavaVersion.VERSION_17' android/app/build.gradle.kts || fail 'Java 17 target compatibility missing'
grep -q 'jvmTarget = JvmTarget.fromTarget("17")' android/app/build.gradle.kts || fail 'Kotlin JVM target 17 compilerOptions contract missing'
! grep -q 'kotlinOptions' android/app/build.gradle.kts || fail 'deprecated kotlinOptions DSL detected'
grep -q 'applicationId = "com.hope.marketplace"' android/app/build.gradle.kts || fail 'applicationId drift'
# Generated localization imports package:intl, so intl must be a direct dependency.
grep -qE '^  intl: ' pubspec.yaml || fail 'intl must be declared directly because generated localization code imports package:intl'

# Fail fast on release misconfiguration patterns.
grep -q 'error("BUILD_PROFILE must be explicitly set' android/app/build.gradle.kts || fail 'release profile fail-closed guard missing'
grep -q 'usesCleartextTraffic="false"' android/app/src/main/AndroidManifest.xml || fail 'release cleartext policy missing'
grep -q 'cleartextTrafficPermitted="false"' android/app/src/main/res/xml/network_security_config.xml || fail 'release TLS policy missing'
! grep -RIn --exclude-dir=build --exclude-dir=.dart_tool --exclude='*.md' 'android:usesCleartextTraffic="true"' android/app/src/main || fail 'cleartext traffic enabled in main resources'

# Detect common generated/cache pollution.
for forbidden in android/.gradle build .dart_tool; do
  if git ls-files --error-unmatch "$forbidden" >/dev/null 2>&1; then
    fail "generated/cache path tracked: $forbidden"
  fi
done

# Check CI Java baseline consistency.
if grep -RInE "java-version: ['\"]21['\"]|Setup Java 21" .github/workflows >/dev/null 2>&1; then
  fail 'CI still requests Java 21; certified Android baseline is Java 17'
fi


# Reject legacy Android Gradle/Kotlin configuration patterns that commonly break modern Flutter builds.
! grep -RInE '^apply[[:space:]]+plugin:|ext\.kotlin_version|kotlin-android-extensions' android --include='*.gradle' --include='*.gradle.kts' >/dev/null 2>&1 || fail 'legacy Gradle/Kotlin plugin configuration detected'
# MainActivity package/path alignment is required for Android manifest resolution.
grep -q '^package com\.hope\.marketplace$' android/app/src/main/kotlin/com/hope/marketplace/MainActivity.kt || fail 'MainActivity package mismatch'
grep -q 'android:name="\.MainActivity"' android/app/src/main/AndroidManifest.xml || fail 'MainActivity manifest entry missing'
# Keep the release build deterministic and protected against slow CI distribution downloads.
grep -q '^networkTimeout=60000$' android/gradle/wrapper/gradle-wrapper.properties || fail 'Gradle wrapper network timeout must be 60s'
grep -q '^distributionSha256Sum=20f1b1176237254a6fc204d8434196fa11a4cfb387567519c61556e8710aed78$' android/gradle/wrapper/gradle-wrapper.properties || fail 'Gradle 8.13 distribution checksum pin missing'

echo 'FLUTTER_GRADLE_STRUCTURAL_AUDIT_PASS'

# Gradle 8.13 wrapper JAR must match the official checksum; refresh is allowed only through Gradle's official endpoint.
EXPECTED_WRAPPER_SHA='81a82aaea5abcc8ff68b3dfcb58b3c3c429378efd98e7433460610fecd7ae45f'
if [[ -f android/gradle/wrapper/gradle-wrapper.jar ]] && [[ "$(sha256sum android/gradle/wrapper/gradle-wrapper.jar | awk '{print $1}')" != "$EXPECTED_WRAPPER_SHA" ]]; then
  tools/wave8/ensure_gradle_wrapper.sh
fi
[[ "$(sha256sum android/gradle/wrapper/gradle-wrapper.jar | awk '{print $1}')" == "$EXPECTED_WRAPPER_SHA" ]] || fail 'gradle-wrapper.jar checksum does not match official Gradle 8.13 wrapper'
