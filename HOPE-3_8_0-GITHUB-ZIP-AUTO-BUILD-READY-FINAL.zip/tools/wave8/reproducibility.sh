#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; OUT="$ROOT/artifacts/wave8/release/TOOLCHAIN-MANIFEST.txt"
cd "$ROOT"

mkdir -p "$(dirname "$OUT")"
{
 echo "git_sha=${GITHUB_SHA:-$(git -C "$ROOT" rev-parse HEAD 2>/dev/null || echo UNKNOWN)}"
 echo "flutter=$(flutter --version 2>/dev/null | head -n1 || echo unavailable)"
 echo "dart=$(dart --version 2>&1 | head -n1 || echo unavailable)"
 echo "node=$(node --version 2>/dev/null || echo unavailable)"
 echo "java=$(java -version 2>&1 | head -n1 || echo unavailable)"
 echo "gradle_wrapper_version=8.13"
echo "gradle_wrapper_sha256=$(sha256sum "$ROOT/android/gradle/wrapper/gradle-wrapper.jar" 2>/dev/null | awk '{print $1}' || echo unavailable)"
 echo "android_sdk=${ANDROID_HOME:-${ANDROID_SDK_ROOT:-unavailable}}"
 echo "os=$(uname -a)"
 echo "npm_lock_sha256=$(sha256sum "$ROOT/backend/package-lock.json" | awk '{print $1}')"
 echo "pub_lock_sha256=$(sha256sum "$ROOT/pubspec.lock" | awk '{print $1}')"
} > "$OUT"
