#!/usr/bin/env python3
import re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
def read(path): return (ROOT/path).read_text(encoding='utf-8')

def fail(msg):
    print('TOOLCHAIN_ALIGNMENT_FAIL:', msg)
    sys.exit(1)

flutter = (ROOT/'.flutter-version').read_text().strip()
manifest = read('toolchain.yaml')
if f'flutter: {flutter}' not in manifest: fail('Flutter version mismatch')
workflow_text='\n'.join(p.read_text(encoding='utf-8') for p in (ROOT/'.github/workflows').glob('*.yml'))
for needle in ["java-version: '17'", "flutter-version: '3.47.0'", "node-version: '24'"]:
    if needle not in workflow_text: fail(f'missing CI pin: {needle}')
settings=read('android/settings.gradle.kts')
if '8.11.1' not in settings or '2.2.20' not in settings: fail('AGP/Kotlin mismatch')
wrapper=read('android/gradle/wrapper/gradle-wrapper.properties')
if 'gradle-8.13-bin.zip' not in wrapper: fail('Gradle wrapper mismatch')
app=read('android/app/build.gradle.kts')
for needle in ['compileSdk = 36','targetSdk = 36','minSdk = 30','ndkVersion = "28.2.13676358"','JvmTarget.fromTarget("17")']:
    if needle not in app: fail(f'missing Android pin: {needle}')
pub=read('pubspec.yaml')
if "flutter: '>=3.47.0'" not in pub: fail('pubspec Flutter minimum drift')
print('TOOLCHAIN_ALIGNMENT_PASS')
