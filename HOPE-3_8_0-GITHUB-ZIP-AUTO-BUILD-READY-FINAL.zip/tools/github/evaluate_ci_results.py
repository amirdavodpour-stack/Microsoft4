#!/usr/bin/env python3
import json, sys
from pathlib import Path
p = Path(sys.argv[1])
data = json.loads(p.read_text(encoding='utf-8'))
phases = data.get('phases', [])
failed = [x for x in phases if x.get('status') != 'PASS']
apk = Path('reports/apk/HOPE-3.8.0-pilot.apk')
release_code = Path('reports/flutter-release-build.exitcode')
if not apk.is_file() or apk.stat().st_size == 0:
    failed.append({'id':'apk_release_artifact','label':'Installable release APK','exitCode':int(release_code.read_text().strip()) if release_code.exists() else 1,'log':'logs/flutter-release-build.log'})
print(f"PHASES={len(phases)} PASS={len(phases)-len(failed)} FAIL={len(failed)}")
if failed:
    print('FAILED PHASES:')
    for x in failed:
        print(f"- {x['id']}: {x['label']} exit={x['exitCode']} log={x['log']}")
    sys.exit(1)
print('ALL LOCAL EXECUTABLE PHASES PASS')
