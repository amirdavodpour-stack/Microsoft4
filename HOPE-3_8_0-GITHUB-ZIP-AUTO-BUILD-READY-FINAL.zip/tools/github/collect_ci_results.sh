#!/usr/bin/env bash
set -u -o pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"
mkdir -p reports logs artifacts/diagnostics coverage
RESULTS="$ROOT/reports/results.json"
: > "$RESULTS"
printf '{"schemaVersion":1,"commit":"%s","runId":"%s","startedAt":"%s","phases":[' \
  "${GITHUB_SHA:-unknown}" "${GITHUB_RUN_ID:-unknown}" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$RESULTS"
first=1
failed=0
blocked=0
run_phase() {
  local id="$1" label="$2" command="$3"
  local log="logs/${id}.log" start end rc duration status
  start=$(date +%s)
  set +e
  timeout --signal=TERM --kill-after=30s 20m bash -lc "$command" >"$log" 2>&1
  rc=$?
  set -e
  end=$(date +%s)
  duration=$((end-start))
  if [ "$rc" -eq 0 ]; then status=PASS; else status=FAIL; failed=1; fi
  if [ "$first" -eq 0 ]; then printf ',' >> "$RESULTS"; fi
  first=0
  python3 - "$RESULTS" "$id" "$label" "$command" "$log" "$status" "$rc" "$duration" <<'PY'
import json,sys
path,id,label,cmd,log,status,rc,dur=sys.argv[1:]
with open(path,'a',encoding='utf-8') as f:
    json.dump({"id":id,"label":label,"command":cmd,"log":log,"status":status,"exitCode":int(rc),"durationSeconds":int(dur)},f,separators=(',',':'))
PY
}

run_phase backend_syntax 'Backend syntax' 'cd backend && npm run check'
run_phase openapi 'OpenAPI validation' 'cd backend && npm run openapi:validate'
run_phase backend_fast 'Backend fast tests' 'cd backend && npm run test:fast'
run_phase backend_contract 'Backend contract tests' 'cd backend && npm run test:contract'
run_phase backend_product 'Backend product tests' 'cd backend && npm run test:product'
run_phase backend_failure 'Failure injection tests' 'cd backend && npm run test:failure-injection'
run_phase backend_release 'Release evidence tests' 'cd backend && npm run test:release-evidence'
run_phase security_hygiene 'Security hygiene' 'bash tools/security_hygiene.sh'
run_phase enterprise_audit 'Enterprise static audit' 'node tools/enterprise_static_audit.mjs'
run_phase android_structural 'Flutter/Gradle structural audit' 'bash tools/wave8/flutter_gradle_structural_audit.sh'
run_phase localization 'Localization checks' 'bash tools/check_localization.sh'
run_phase flutter_analyze 'Flutter analyze' 'flutter analyze'
run_phase flutter_tests 'Flutter tests' 'flutter test --coverage'

printf '],"failed":%d,"finishedAt":"%s"}\n' "$failed" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$RESULTS"

python3 - "$RESULTS" <<'PY'
import json, pathlib
p=pathlib.Path('reports/results.json')
data=json.loads(p.read_text())
errs=[]
for phase in data['phases']:
    if phase['status']!='PASS':
        errs.append({"id":phase['id'],"label":phase['label'],"exitCode":phase['exitCode'],"log":phase['log']})
pathlib.Path('reports/ERRORS.json').write_text(json.dumps(errs,indent=2),encoding='utf-8')
with open('reports/ERRORS.md','w',encoding='utf-8') as f:
    f.write('# HOPE CI Error Report\n\n')
    if not errs:
        f.write('No phase failures were recorded.\n')
    else:
        for e in errs:
            f.write(f"- **{e['id']} — {e['label']}**: exit {e['exitCode']} — `{e['log']}`\n")
PY
exit 0
