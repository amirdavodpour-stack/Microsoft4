#!/usr/bin/env bash
set -u -o pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"
mkdir -p reports/apk
APK="build/app/outputs/flutter-apk/app-release.apk"
if [[ -s "$APK" ]]; then
  cp "$APK" reports/apk/HOPE-3.8.0-pilot.apk
  if command -v sha256sum >/dev/null 2>&1; then sha256sum reports/apk/HOPE-3.8.0-pilot.apk > reports/apk/HOPE-3.8.0-pilot.apk.sha256; fi
  if command -v apksigner >/dev/null 2>&1; then
    apksigner verify --verbose reports/apk/HOPE-3.8.0-pilot.apk > reports/apk/apksigner.txt 2>&1 || true
  fi
  if command -v aapt >/dev/null 2>&1; then
    aapt dump badging reports/apk/HOPE-3.8.0-pilot.apk > reports/apk/aapt-badging.txt 2>&1 || true
  fi
else
  echo 'Release APK was not produced.' > reports/apk/BUILD-MISSING.txt
fi

if [[ -f reports/flutter-release-build.exitcode ]] && [[ "$(cat reports/flutter-release-build.exitcode)" != 0 ]]; then
  echo "Release build exit code: $(cat reports/flutter-release-build.exitcode)" > reports/apk/BUILD-FAILED.txt
fi
